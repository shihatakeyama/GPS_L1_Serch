// **********************************************************************
// SP_Global.h
//
//
// **********************************************************************

#ifndef SP_GLOBAL_H
#define SP_GLOBAL_H


#include "stdafx.h"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
extern GLThread					gGLThread;

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �ʐM�֘A
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
extern LineDataSet				gGraphCsv;

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �v���Z�X�֘A�f�[�^
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
extern st_CsvParam				gCsvParam;


int32_t findStringListId(const CString &PurposeName ,const LPCTSTR NameList[]);



#endif // SP_GLOBAL_H


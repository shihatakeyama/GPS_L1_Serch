// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// ListCtrlComFormat.cpp
//
//  �V���A���t�H�[�}�b�g��p ���X�g�R���g���[��
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

#include "stdafx.h"
#include "SignalProcDlg.h"
#include "ComboInListCtrl.h"

#include "ListCtrlComFormat.h"


// CListCtrlOwner
// CListCtrlComFormat


IMPLEMENT_DYNAMIC(CListCtrlComFormat, CListCtrl)

CListCtrlComFormat::CListCtrlComFormat()
:m_Edit(1)
{}

CListCtrlComFormat::~CListCtrlComFormat()
{}


BEGIN_MESSAGE_MAP(CListCtrlComFormat, CListCtrl)
	ON_NOTIFY_REFLECT(NM_DBLCLK, &CListCtrlComFormat::OnNMDblclk)
	ON_NOTIFY_REFLECT(NM_CLICK, &CListCtrlComFormat::OnNMClick)
END_MESSAGE_MAP()



// CListCtrlComFormat ���b�Z�[�W �n���h���[

# if 1
void CListCtrlComFormat::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{

	CDC* pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
	CRect rcItem(lpDrawItemStruct->rcItem);
	int nItem = lpDrawItemStruct->itemID;

	LV_ITEM lvi;
	lvi.mask = LVIF_IMAGE | LVIF_STATE | LVIF_PARAM;	//   | LVIF_IMAGE �r�b�g�}�b�v
//--	lvi.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	lvi.iItem = nItem;
	lvi.iSubItem = 0;
	lvi.stateMask = 0xFFFF;
	GetItem(&lvi);

	//���s�̔w�i
	COLORREF clrTextSave;
	COLORREF clrBkSave;

	if (lvi.state & LVIS_SELECTED){
		clrBkSave = pDC->SetBkColor(::GetSysColor(COLOR_HIGHLIGHT));
		CBrush cb(::GetSysColor(COLOR_HIGHLIGHT));
		pDC->FillRect(rcItem, &cb);
	}else{
		if (nItem & 0x01)    //�Ȕn�͗l
		{
			CBrush cb(::GetSysColor(COLOR_WINDOW));
			pDC->FillRect(rcItem, &cb);
		}
		else
		{
			CBrush cb((COLORREF)0x00f0f0f0);
			pDC->FillRect(rcItem, &cb);
		}
	}

	//�r�b�g�}�b�v�̕`��
//	CImageList* pImageList = GetImageList(LVSIL_SMALL);
//	pImageList->Draw(pDC, lvi.iImage, rcItem.TopLeft(), ILD_TRANSPARENT);

	// �`�F�b�N�{�b�N�X
	rcItem.right = 20;
////    if(lpDrawItemStruct->itemState & ODS_CHECKED){
	if(GetCheck(nItem)){
        DrawFrameControl(*pDC, rcItem, DFC_BUTTON, DFCS_CHECKED);
	}else{
        DrawFrameControl(*pDC, rcItem, DFC_BUTTON, DFCS_INACTIVE);
	}


	CRect rectItem(0, 0, 0, 0);
	CRect rectText;

	for (int j = 0; j < 5; j++){
		if (j == 0){
			GetItemRect(nItem, rectItem, LVIR_LABEL);
		}else{
			rectItem.left = rectItem.right;
			rectItem.right += GetColumnWidth(j);
		}

		rectText = rectItem;
		if(j != 0){
			rectText.left += 4;
		}
		rectText.right -= 4;

		CString strData = GetItemText(nItem, j);

		if ((lvi.state & LVIS_SELECTED))
			clrTextSave = pDC->SetTextColor(::GetSysColor(COLOR_HIGHLIGHTTEXT));

		if (rectText.right >= rectText.left)
			pDC->DrawText(strData, rectText, DT_LEFT | DT_SINGLELINE | DT_NOPREFIX | DT_VCENTER);

		if ((lvi.state & LVIS_SELECTED))
			pDC->SetTextColor(clrTextSave);
	}

	if (lvi.state & LVIS_SELECTED){
		pDC->SetBkColor(clrBkSave);
	}
	//�t�H�[�J�X�̕`��
	if ((lvi.state & LVIS_FOCUSED) != 0 && GetFocus() == this){
		pDC->DrawFocusRect(&rcItem);
	}


}
#endif


BOOL CListCtrlComFormat::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: �����ɓ���ȃR�[�h��ǉ����邩�A�������͊��N���X���Ăяo���Ă��������B

	int DisplayMode = 1;// atoi(GetRegistry(DisplayMode));

	// 0:�A�C�R�� 1:�ꗗ 2:�ڍ�
	if (DisplayMode == 0)
		cs.style |= (LVS_ICON | LVS_SHOWSELALWAYS | LVS_OWNERDATA);//�A�C�R��

	if (DisplayMode == 1)
		cs.style |= (LVS_LIST | LVS_SHOWSELALWAYS | LVS_OWNERDATA);//�ꗗ

	if (DisplayMode == 2)
		cs.style |= (LVS_REPORT | LVS_SHOWSELALWAYS | LVS_OWNERDATA);//�ڍ�

	cs.dwExStyle |= (LVS_EX_TWOCLICKACTIVATE |
		LVS_EX_INFOTIP |
		LVSICF_NOINVALIDATEALL |
		LVSICF_NOSCROLL);

	return CListCtrl::PreCreateWindow(cs);
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// PreTranslateMessage()
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
BOOL CListCtrlComFormat::PreTranslateMessage(MSG* pMsg)
{

	switch (pMsg->message){
		case WM_KEYDOWN:
			switch( pMsg->wParam )
			{
				case VK_RETURN:
//--					m_Edit.OnKillFocus_a(&m_Edit);
//--					::SetFocus(m_hWnd);
					break;
				case VK_ESCAPE:
					return FALSE;
				default:
					if(pMsg->wParam>=0x60 && pMsg->wParam<=0x69){
						if(pMsg->hwnd == m_Edit.m_hWnd){
//--							return FALSE;
						}
					}
					break;
			}
									TRACE("%X,%X ,%X ,%X\n",pMsg->wParam ,pMsg->lParam ,m_Edit.m_hWnd ,pMsg->hwnd);
			break;
	}

	return CListCtrl::PreTranslateMessage(pMsg);
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// ���X�g���N���b�N���ꂽ�B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void CListCtrlComFormat::OnNMClick(NMHDR *pNMHDR, LRESULT *pResult)
{
	BOOL chk;
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);

//--	pNMItemActivate->iItem;

	// �`�F�b�N�{�b�N�X �`�F�b�N�L��
	if(pNMItemActivate->iSubItem == 0){
		chk = !GetCheck(pNMItemActivate->iItem);
		SetCheck(pNMItemActivate->iItem ,chk);
	}

#if 0
	if(pNMItemActivate->iSubItem == 2){
		BeginEdit(pNMItemActivate->iItem, pNMItemActivate->iSubItem);
	}
#endif

	*pResult = 0;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// ���X�g���_�u���N���b�N���ꂽ�B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void CListCtrlComFormat::OnNMDblclk(NMHDR *pNMHDR, LRESULT *pResult)
{
	LV_HITTESTINFO lvinfo;
//	TCHAR buf[256];
    LVITEM item;
//	LPNMLISTVIEW	lp;

	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);


    GetCursorPos((LPPOINT)&lvinfo.pt);
    ScreenToClient(&lvinfo.pt);	// ((LPNMLISTVIEW)pNMItemActivate->lParam)->hdr.hwndFrom, 
	SubItemHitTest(&lvinfo);

#if 1
	// 
	if(pNMItemActivate->iSubItem == 1){
		BeginEdit(pNMItemActivate->iItem, pNMItemActivate->iSubItem);
	}
#endif

#if 1
	// �ϐ��^�C�v�ύX
	if(pNMItemActivate->iSubItem == 2){
		BeginCombo(pNMItemActivate->iItem, pNMItemActivate->iSubItem);
	}
#endif

	*pResult = 0;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �Z���ҏW �J�n  �Z�O�����g�ʒu
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void CListCtrlComFormat::BeginEdit(int iItem, int iSubItem)
{
	CRect ColumnRect;
    
    if (iSubItem == 0)
        GetSubItemRect(iItem, iSubItem, LVIR_LABEL, ColumnRect);
    else
        GetSubItemRect(iItem, iSubItem, LVIR_BOUNDS, ColumnRect);

    ColumnRect.DeflateRect(1,1);

    m_Edit.Create(WS_VISIBLE | ES_AUTOHSCROLL | ES_LEFT, ColumnRect,  this, IDC_EDIT_SUB_ITEM);
    CFont* pFont = GetFont();
    m_Edit.SetFont(pFont);
    m_Edit.m_row = iItem;
    m_Edit.m_col = iSubItem;
    m_Edit.SetWindowText(GetItemText(iItem, iSubItem));
    m_Edit.SetFocus();
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �Z���ҏW �J�n
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void CListCtrlComFormat::BeginCombo(int iItem, int iSubItem)
{
    CRect ColumnRect;
    
    if (iSubItem == 0)
        GetSubItemRect(iItem, iSubItem, LVIR_LABEL, ColumnRect);
    else
        GetSubItemRect(iItem, iSubItem, LVIR_BOUNDS, ColumnRect);

///--    ColumnRect.DeflateRect(1,1);
	ColumnRect.bottom = 20;
 // m_Edit.Create(WS_VISIBLE | ES_AUTOHSCROLL | ES_LEFT, ColumnRect,  this, IDC_EDIT_SUB_ITEM);	// �e�L�X�g�G�f�B�g�̏ꍇ
	m_Combo.Create(WS_CHILD | WS_VISIBLE | WS_VSCROLL | CBS_DROPDOWNLIST, ColumnRect, this, IDC_EDIT_SUB_ITEM);

    CFont* pFont = GetFont();
/*
	if(m_Edit.m_Font == nullptr){
		m_Edit.m_Font = new CFont(20, _T("�l�r �o�S�V�b�N") );
	}
	m_XAxisLabelFont.CreatePointFont(20, _T("�l�r �o�S�V�b�N") );
	*/

	m_Combo.InsertString(-1,g_ValTypeList[0]);
	m_Combo.InsertString(-1,g_ValTypeList[1]);
	m_Combo.InsertString(-1,g_ValTypeList[2]);

	CString orgtxt = GetItemText(iItem,iSubItem);
	int32_t index = findStringListId(orgtxt ,g_ValTypeList);
	if(index < 0)	index = 0;
	m_Combo.SetCurSel(index);

    m_Combo.SetFont(pFont);	// pFont
    m_Combo.m_row = iItem;
    m_Combo.m_col = iSubItem;
    m_Combo.SetWindowText(GetItemText(iItem, iSubItem));
    m_Combo.SetFocus();

	m_Combo.ShowDropDown();
}



void CListCtrlComFormat::DoDataExchange(CDataExchange* pDX)
{
	CListCtrl::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_EDIT_SUB_ITEM, m_StatiN);
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  CudaMem.cpp
//
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

#include "stdafx.h"

// System includes
#include <stdio.h>
#include <assert.h>

// CUDA runtime
#include <cuda_runtime.h>

// helper functions and utilities to work with CUDA
#include <helper_functions.h>
#include <helper_cuda.h>

#include <stdint.h>

#include "CudaMem.h"


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//#include "CudaMem.h"
//__align__(4) 
int8_t *gIfDump = nullptr;
size_t gIfDumpLen = 0;

CudaMemInt8 gIfData;	// A/D����IF�f�[�^

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
__host__ int loadIfDump(const CString &FilePath)
{
    cudaError_t cudaStatus;
	int	ack=0;

	//*Data	= nullptr;

	std::ifstream ifs(FilePath, ios::in | ios::binary );	// �o�C�i�����[�h�łɂ��Ȃ��ƁA�ǂݍ��񂾃t�@�C���T�C�Y������Ȃ��Ȃ�B
    if (ifs.fail()){
        return -3;
    }
    int begin = static_cast<int>(ifs.tellg());
    ifs.seekg(0, ifs.end);
    // �ꉞ�͈̓`�F�b�N���ׂ������ǁc�c
    int end = static_cast<int>(ifs.tellg());
    int size = end - begin;
    ifs.clear();		 // ������clear����EOF�t���O������
    ifs.seekg(0, ifs.beg);
    char *str = new char[size];	// +1
    ifs.read(str, size);
//    str[size] = '\0';	 // �O�̂��ߖ�����NULL������

	if(gIfDump!=nullptr)	cudaFree(gIfDump);

	cudaStatus = cudaMalloc((void**)&gIfDump, size * sizeof(uint8_t));
	if (cudaStatus != cudaSuccess) {
		ack = -4;
		goto Error;
	}

	// �f�[�^�R�s�[
	cudaStatus = cudaMemcpy((void*)gIfDump ,(void*)str ,size * sizeof(uint8_t) ,cudaMemcpyHostToDevice);
	if (cudaStatus != cudaSuccess) {
		ack = -5;
		goto Error;
	}

	gIfDumpLen = size;

Error:
	delete str;

	return ack;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
__host__ void freeIfDump()
{
	if(gIfDump != nullptr)	cudaFree(gIfDump);
	gIfDump = nullptr;
	gIfDumpLen = 0;
}



CudaMemInt8::CudaMemInt8()
:m_Data(nullptr),m_Len(0)
{}

CudaMemInt8::~CudaMemInt8()
{
	memFree();
}

cudaError_t CudaMemInt8::memalloc(size_t Len){
	cudaError_t cudaStatus;
	memFree();
	cudaStatus = cudaMalloc((void**)&m_Data, Len * sizeof(uint8_t));
	m_Len = Len;
	return cudaStatus;
}

void CudaMemInt8::memFree()
{
	if(m_Data!=nullptr)	cudaFree(m_Data);
	m_Data	= nullptr;
	m_Len	= 0;	
}
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �N���X�̊O��cuda�֐����g���悤�ɂ���̂��߂�ǂ������̂ŁB
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
cudaError_t CudaMemInt8::putMemCopy(size_t CudaOffset ,const int8_t *SrcData ,size_t Len)
{
	return cudaMemcpy(m_Data + CudaOffset ,SrcData ,Len ,cudaMemcpyHostToDevice);
}
cudaError_t CudaMemInt8::getMemCopy(size_t CudaOffset ,int8_t *DstData ,size_t Len) const
{
	return cudaMemcpy(DstData ,m_Data + CudaOffset ,Len ,cudaMemcpyDeviceToHost);
}

CudaMemInt8::operator int8_t*(){
	return m_Data;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t cudaLoad(CudaMemInt8 &CudaMem ,const std::wstring &FilePath)
{
	cudaError_t cudaStatus;
	int	ack=0;

	//*Data	= nullptr;

	std::ifstream ifs(FilePath, ios::in | ios::binary );	// �o�C�i�����[�h�łɂ��Ȃ��ƁA�ǂݍ��񂾃t�@�C���T�C�Y������Ȃ��Ȃ�B
    if (ifs.fail()){
        return -3;
    }
    int begin = static_cast<int>(ifs.tellg());
    ifs.seekg(0, ifs.end);
    // �ꉞ�͈̓`�F�b�N���ׂ������ǁc�c
    int end = static_cast<int>(ifs.tellg());
    int size = end - begin;
    ifs.clear();		 // ������clear����EOF�t���O������
    ifs.seekg(0, ifs.beg);
    char *str = new char[size];	// +1
    ifs.read(str, size);
//    str[size] = '\0';	 // �O�̂��ߖ�����NULL������

	CudaMem.memalloc(size);

	CudaMem.putMemCopy(0 ,reinterpret_cast<int8_t*>(str) ,size);

	delete str;
}
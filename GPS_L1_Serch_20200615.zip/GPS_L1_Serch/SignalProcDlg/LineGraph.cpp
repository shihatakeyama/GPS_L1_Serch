// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Graph.cpp
//
//  Draw a line graph
// 
//  dependent : Win32,MFC
//  
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *



#include "stdafx.h"


const CString CLineGraph::m_BaseFormat = (_T("%%%d.%df"));
const float	CLineGraph::m_minstep	= 1.0e-6;	// �l�͎b��


CLineGraph::CLineGraph()	//-- const CWnd *Wind ,int nID
:	m_XMin(0),m_XMax(100),
m_YMin(0),m_YMax(100),
m_XGridSpacing(10),m_YGridSpacing(10),
m_XScale(1.0f),m_YScale(1.0f),
m_XAxisLabelFont(),m_YAxisLabelFont(),
m_XAxisLabelRgb(),m_YAxisLabelRgb(),
m_XDivNum(8), m_YDivNum(8),
m_XStringLength(5),m_XDecimalLength(1),
m_YStringLength(5),m_YDecimalLength(1),
m_ReDraw(1),
m_TextSize(100)
{
	m_XAxisLabelFont.CreatePointFont(m_TextSize, _T("�l�r �o�S�V�b�N") );
	m_LineColor[0]	= RGB(0  ,  0,255);		// ��
	m_LineColor[1]	= RGB(127,127,  0);		// �L
	m_LineColor[2]	= RGB(  0,165,  0);		// ��
	m_LineColor[3]	= RGB(255,  0,255);		// �}�[���^
	m_LineColor[4]	= RGB(255,105,180);		// 
	m_LineColor[5]	= RGB(128,128,  0);
	m_LineColor[6]	= RGB(  0,255,128);
	m_LineColor[7]	= RGB(128,  0,128);

	autoXGridSpacing();
	autoYGridSpacing();
}

CLineGraph::~CLineGraph(){
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �E�C���h�E�쐬���ɍ쐬�K���Ă��
// �E�C���h�E�N���X�̂̃R���X�g���N�^�ŏ����ĂԂƁA�G���[�ɂȂ�B
//
// @ nID �R���g���[��ID
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int CLineGraph::initDlgItem(const CWnd *Wind, int nID){
	
	m_pWnd = Wind->GetDlgItem(nID);

	//Add ToolTips
	if (!m_Tooltip.Create(m_pWnd))
		TRACE(_T("Unable to create tip window for CCurveCtrl."));
	else if (!m_Tooltip.AddTool(m_pWnd, _T("Control ToolTips")))
		TRACE(_T("Unable to add tip for the control window for CCurveCtrl."));
	else
		m_Tooltip.Activate(TRUE);

	return 0;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �}�E�X�|�C���^���W���G���A�ԍ��ɕϊ�����B
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t CLineGraph::pointToArea(CPoint point){
	int32_t ret = EGR_none;

	// �� �ʒu�𔻒肷��B
	if (point.x <= m_PlotArea.left){
		ret |= 0x01;
	}
	else if (point.x < m_PlotArea.right){
		ret |= 0x02;
	}
	else{
		ret |= 0x03;
	}

	// �c �ʒu�𔻒肷��
	if (point.y <= m_PlotArea.top){
		ret |= 0x04;
	}
	else if (point.y < m_PlotArea.bottom){
		ret |= 0x08;
	}
	else{
		ret |= 0x0C;
	}

	return ret;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// description  : static function, to calculate distance between two points
// in paramenter: pt1, pt2
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
float CLineGraph::toDistance(const CPoint& pt1, const CPoint& pt2)
{
	return (float)sqrt((float)((pt1.x - pt2.x) * (pt1.x - pt2.x) + (pt1.y - pt2.y) * (pt1.y - pt2.y)));
}
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Point �ߖT�̈ʒu��Ԃ��܂��B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
bool CLineGraph::isNearPoint(CPoint Point, const LineDataSet &DataSet, int &SeriesNo, int &EntNo, CPoint &NearPoint)
{
	int32_t	isel,ient;
	int32_t	endsel, endent;
	Float32	yval;
	CPoint	currpoint;
	Float32	fdist;

	endsel = DataSet.size();
	for (isel = 0; isel < endsel; isel++)
	{
		SeriesBase	&ser = *DataSet.getElement(isel);

		endent = ser.size();
		for (ient = 0; ient < endent; ient++){
			yval = ser.getEntryFloat32(ient);
			currpoint = toPoint(ient, yval);
			// �܂��r���ʒu����
			if (((Point.x - CURVE_NEAR_RANGE) <= currpoint.x) && ((Point.x + CURVE_NEAR_RANGE) >= currpoint.x)){
				fdist = toDistance(Point, currpoint);
				if (fdist <= CURVE_NEAR_RANGE){
					SeriesNo	= isel;
					EntNo		= ient;
					NearPoint	= currpoint;
					return TRUE;
				}
			}
		}
	}

	return FALSE;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �}�E�X�|�C���^�̕t�߂ɂ���G���g����\�����܂��B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t CLineGraph::shiwTooltip(CPoint Point, const LineDataSet &DataSet)
{
//--	int SeriesNo,EntNo;

	
//--	if (isNearPoint(Point, DataSet, SeriesNo, EntNo) == TRUE)
	{

	//	m_Tooltip

	}

	return 0;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �N���b�N
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int CLineGraph::PreTranslateMessage(const CWnd &pWind, MSG* pMsg, LineDataSet &DataSet)
{
	int32_t ret = EGR_none;
	int32_t mousearea;
	CPoint deltapoint;
	RECT carea;
	Float32 fx, fy;
	Float32	indix,indiy;
	CString str;

	int32_t	SeriesNo, EntNo;
	CPoint	nearpoint;

	m_pWnd->GetClientRect(&carea);

	CWnd* pWnd = pWind.WindowFromPoint(pMsg->pt);

	// ��ʔ���
	if ((pWnd != m_pWnd) && (m_ActionMode == EAM_none))	{ return 0; }

	// �s�N�`���R���g���[����̃}�E�X�|�C���^���W
	CPoint cpoint((int16_t)pMsg->lParam, (int16_t)(pMsg->lParam>>16));

	switch (pMsg->message){
	case WM_KEYDOWN:
		break;
	case WM_LBUTTONDOWN:
		mousearea = pointToArea(cpoint);
		switch (mousearea){
		case EGR_clk_left:
			break;
		case EGR_clk_bottom:
			break;
		case EGR_clk_center:
			switch (pMsg->wParam & ~MK_LBUTTON){
			case MK_SHIFT:
				m_ActionMode = EAM_shift;	// �㉺���E�V�t�g
				break;
			case MK_CONTROL:
				m_ActionMode = EAM_ctrl;
				break;
//--				case MK_ALT:
//--					m_ActionMode = EAM_alt;
				break;
			default:
				m_ActionMode = EAM_drag;
				break;
			}
			if (m_ActionMode != EAM_none){
				getWnd()->SetCapture();

				m_XMaxClk = m_XMax;
				m_XMinClk = m_XMin;
				m_YMaxClk =	m_YMax;
				m_YMinClk = m_YMin;
				m_XWideClk= m_XMax - m_XMin;
				m_YWideClk= m_YMax - m_YMin;
				m_PointClk = cpoint;
			}
		}
		break;
	case WM_LBUTTONDBLCLK:
		ret = EGR_dclk_center;
		break;
	case WM_RBUTTONDOWN:
		m_ActionMode = EAM_ctrl;
		if (m_ActionMode != EAM_none){
			getWnd()->SetCapture();

			m_XMaxClk = m_XMax;
			m_XMinClk = m_XMin;
			m_YMaxClk =	m_YMax;
			m_YMinClk = m_YMin;
			m_XWideClk= m_XMax - m_XMin;
			m_YWideClk= m_YMax - m_YMin;
			m_PointClk = cpoint;
		}
		break;
	case WM_MOUSEMOVE:
		deltapoint = cpoint - m_PointClk;
		switch (m_ActionMode){
		case EAM_shift:	// �O���t���c���ɃV�t�g
			fx	= deltapoint.x * m_XWideClk / m_PlotArea.right;
			fy	= deltapoint.y * m_YWideClk / m_PlotArea.bottom;
			m_XMax	= m_XMaxClk - fx,
			m_XMin	= m_XMinClk - fx,
			m_YMax	= m_YMaxClk + fy,
			m_YMin	= m_YMinClk + fy,
				
			ret = EGR_redraw;
			break;
		case EAM_ctrl:	// �O���t���g��/�k��
		{
			fx = pow(2.0f, (Float32)deltapoint.x * 0.01f);		// �g��/�k�����ݒ� (1.0��100%)
			fy = pow(2.0f, (Float32)deltapoint.y * 0.01f);

			RECT &rect = m_PlotArea;
			//			m_pWnd->GetClientRect(&rect);

			indix = (Float32)(m_PointClk.x - EPM_left) / (Float32)(rect.right - rect.left);	// �ǂ̈ʒu�ŃN���b�N���ꂽ�̂��H
			indiy = (Float32)(m_PointClk.y - EPM_top)  / (Float32)(rect.bottom - rect.top);

			m_XMax = m_XMaxClk - ((1.0f - fx) * m_XWideClk * (1.0f - indix));
			m_XMin = m_XMinClk + ((1.0f - fx) * m_XWideClk * indix);
			m_YMax = m_YMaxClk - ((1.0f - fy) * m_YWideClk * indiy);
			m_YMin = m_YMinClk + ((1.0f - fy) * m_YWideClk * (1.0f - indiy));
			ret = EGR_redraw;

			autoXGridSpacing();
			autoYGridSpacing();

			break;
		}
		case EAM_alt:
				break;
		case EAM_drag:
			// �h���b�O
//--			ret = EGR_redraw;
			break;
		default:

			// �}�E�X�|�C���^���G���g���̋߂��ɒB������A�c�[���`�b�v��\��
			if (isNearPoint(cpoint, DataSet, SeriesNo, EntNo, nearpoint) == TRUE){

				// use tooltip to show the values of key point nearby
				CString		strTip;

				if(!m_SeriesName.IsEmpty() && (m_SeriesName.GetSize() == m_Data.size())){
					strTip.Format(_T("%s, Entry %d, Val %s"), m_SeriesName[SeriesNo], EntNo, DataSet[SeriesNo].toString(EntNo));					
				}else{
					strTip.Format(_T("series %d, Entry %d, Val %s"), SeriesNo, EntNo, DataSet[SeriesNo].toString(EntNo));					
				}

				if (m_Tooltip.m_hWnd)
				{
					m_Tooltip.Activate(TRUE);
					m_Tooltip.UpdateTipText(strTip, this->m_pWnd);

					MSG msg;
					msg.hwnd = this->m_pWnd->m_hWnd;
					msg.message = WM_MOUSEMOVE;
					msg.wParam = pMsg->wParam;	// nFlags;
					msg.lParam = pMsg->wParam;	//	 MAKELPARAM(LOWORD(point.x), LOWORD(point.y));
					msg.time = 0;
					msg.pt.x = pMsg->pt.x;
					msg.pt.y = pMsg->pt.y;

					m_Tooltip.RelayEvent(&msg);
				}


			}

			break;
		}

		break;
	case WM_LBUTTONUP:
	case WM_RBUTTONUP:
		if (m_ActionMode != EAM_none){
			ReleaseCapture();
			m_ActionMode = EAM_none;
		}
		break;
	}

	return ret;
}
int CLineGraph::PreTranslateMessageSol(const CWnd &pWind, MSG* pMsg)
{
	int ack;

	ack = PreTranslateMessage(pWind, pMsg, m_Data);

	switch (ack){
		case CLineGraph::EGR_clk_left:
			break;
		case CLineGraph::EGR_clk_bottom:
			break;
		case CLineGraph::EGR_dclk_center:
			setViewAreaXEntrySize();
			setViewAreaY(m_Data);
			autoXGridSpacing();
			autoYGridSpacing();
			onPaint();
			break;
		case CLineGraph::EGR_redraw:
			onPaint();
			break;
	}

	return 0;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// ��؂�̗ǂ����l�ɒ����B���̒l�͖��Ή�
// 1.25 �� 1.5
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
Float32 CLineGraph::goodSeparation(Float32 Arg)
{
	int32_t i, j;
	Float32 digitmultip = 1.0f, ftemp, ftemp2;
	Float32 numlist[] = { 1.0f, 2.0f, 5.0f, 10.0f, 20.0f };

	ASSERT(Arg >= 0);		// �ϊ��s�\

	if (Arg >= 1.0f){
		// ������1.0�ȏ�
		for (i = 0; i<38; i++){
			// ������T��
			ftemp = digitmultip * 10.0f;
			if (Arg <= ftemp){
				// ��1�s���߂����̂�1�O�̒l���B�B
				for (j = 0; j < sizeof(numlist) / sizeof(Float_t); j++){
					ftemp2 = digitmultip * numlist[j];
					if (ftemp2 >= Arg){
						return ftemp2;
					}
				}
			}
			digitmultip = ftemp;
		}
	}
	else{
		// ������1.0����
		for (i = 0; i<38; i++){
			// ������T��
			ftemp = digitmultip * 0.1f;
			if (Arg >= ftemp){
				// 
				for (j = 0; j < sizeof(numlist) / sizeof(Float32); j++){
					ftemp2 = ftemp * numlist[j];
					if (ftemp2 >= Arg){
						return ftemp2;
					}
				}
			}
			digitmultip = ftemp;
		}
	}

	ASSERT(0);	// �ϊ��s�\

	return 1.0f;
}
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �\������܂����͈͂�ݒ� Min.Max���w��
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int CLineGraph::setViewAreaX(float XMin ,float XMax){

	m_XMax	= XMax;
	m_XMin	= XMin;
	setPlotArea();

	return 0;
}
int CLineGraph::setViewAreaY(float YMin ,float YMax){

	m_YMax	= YMax;
	m_YMin	= YMin;
	setPlotArea();

	return 0;
}
int CLineGraph::setViewAreaXEntrySize()
{
	if (m_Data.empty())	return 0;

	// �V���[�Y�ő���擾
	int32_t curr,max=0;
	int32_t i;
	int32_t end = m_Data.size();

	if (end == 0)	return 0;

	for (i = 0; i < end; i++){
		curr = m_Data.getElement(i)->size();
		max = MAX(max ,curr);
	}
	m_ReDraw = 1;

	return setViewAreaX(0.0f, static_cast<Float_t>(max));
}

int CLineGraph::setViewAreaXEntrySize(const SeriesBase &Ser){

	setViewAreaX(0.0f ,static_cast<Float32>(Ser.size()));
	m_ReDraw = 1;

	return 0;
}

int CLineGraph::setViewAreaY()
{
	return setViewAreaY(m_Data);
}

int CLineGraph::setViewAreaY(const SeriesBase &Ser){
	Float32 minv,maxv;

	if(Ser.minAndMaxFloat32(minv ,maxv)){
		if (minv == maxv){
			maxv += m_minstep;
		}

		setViewAreaY(minv,maxv);
	}
	return 0;
}
int CLineGraph::setViewAreaY(const LineDataSet &DataSet){
	Float32 minv,maxv;
	Float32 mint,maxt;

	if(DataSet.empty())	return -3;

	int32_t ssize = DataSet.getSeriesLen();

	SeriesBase *sb = DataSet.getElement(0);
	if(!sb->minAndMaxFloat32(minv ,maxv)){
		return -5;
	}
#if 0
	// 2�d���[�v�Ŕ�r���Ă��܂��Ă�B
	for (i = 1;i<ssize; i++){
		if(sb->minAndMaxFloat32(mint ,maxt)){
			minv = min(minv,mint);
			maxv = max(maxv,maxt);
		}
	}
#else
	sb->minAndMaxFloat32(minv ,maxv);
#endif
	if (minv == maxv){
		maxv += m_minstep;
	}

	setViewAreaY(minv,maxv);

	return 0;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �����x���̐��l�𕶎���ɕϊ����܂��B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
CString CLineGraph::toXLabelString(Float32 Val) const
{
	CString str;

	str.Format(m_XFormat ,Val);

	return str;
}
CString CLineGraph::toYLabelString(Float32 Val) const
{
	CString str;

	str.Format(m_YFormat ,Val);

	return str;
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �O���b�h�̊Ԋu��ݒ肷��
//  ????GridSpacing() ,????GridNum()�ǂ��炩��ݒ肵�Ă��������B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void CLineGraph::setXGridSpacing(float XGridSpacing){
	m_XGridSpacing = XGridSpacing;
	m_XDivNum = -1;
	m_ReDraw = 1;
}
void CLineGraph::setYGridSpacing(float YGridSpacing){
	m_YGridSpacing = YGridSpacing;
	m_YDivNum = -1;
	m_ReDraw = 1;
}

void CLineGraph::setXGridNum(int XGridNum){
	ASSERT(XGridNum >= 0);
	m_XDivNum = XGridNum;
	autoXGridSpacing();
}
void CLineGraph::setYGridNum(int YGridNum){
	ASSERT(YGridNum >= 0);
	m_YDivNum = YGridNum;
	autoYGridSpacing();
}


void CLineGraph::autoXGridSpacing()
{
	if (m_XDivNum < 0)	return;

	int32_t ack;
	Float32	saf, stepa;

	ASSERT(m_XMax >= m_XMin);

	saf = m_XMax - m_XMin;
	if (saf == 0.0f){
		saf = 0.000001f;
	}

	ASSERT(saf > 0);

	stepa = saf / m_XDivNum;
	m_XGridSpacing = goodSeparation(stepa);

	ack = goodTextFormat(m_XStringLength, m_XDecimalLength ,m_XGridSpacing);
	if(ack == 0){
		m_XFormat.Format(m_BaseFormat,m_XStringLength ,m_XDecimalLength);
	}
	m_ReDraw = 1;
}
void CLineGraph::autoYGridSpacing()
{
	if (m_YDivNum < 0)	return;

	int32_t ack;
	Float32	saf, stepa;

	ASSERT(m_YMax >= m_YMin);

	saf = m_YMax - m_YMin;
	if (saf == 0.0f){
		saf = 0.000001f;
	}

	ASSERT(saf > 0);

	stepa = saf / m_YDivNum;
	m_YGridSpacing = goodSeparation(stepa);

	ack = goodTextFormat(m_YStringLength, m_YDecimalLength ,m_YGridSpacing);
	if(ack == 0){
		m_YFormat.Format(m_BaseFormat,m_YStringLength ,m_YDecimalLength);
	}
	m_ReDraw = 1;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �e�L�X�g�̌���
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t CLineGraph::goodTextFormat(uint8_t &StringLength, uint8_t &DecimalLength ,Float32 Val)
{
	int8_t i;
	Float_t cfloat;

	StringLength	= 5;
	DecimalLength	= 1;

	// �����_�Z�o
	cfloat = Val;
	i = 0;
	while(1){
		if(i > FLOAT_INDEX){
			return -3;
		}
		if(cfloat >= 1.0f){
			DecimalLength	= i;
			break;
		}

		cfloat *= 10.0f;

		i++;
	}

	// �����_�Z�o
	cfloat = Val;
	i = 0;
	while(1){
		if(i > FLOAT_INDEX){
			return -3;
		}
		if(cfloat <= 1.0f){
			StringLength	= 1 + i + 1 + DecimalLength;
			break;
		}

		cfloat *= 0.1f;

		i++;
	}

//	str.Format(m_BaseFormat ,StringLength ,DecimalLength);

	return 0;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// ���̐F
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int CLineGraph::setLineColors(COLORREF Color, int SeriesNo)	{
	if ((SeriesNo < 0) || (SeriesNo >= MAX_Series))	return -1;
	m_LineColor[SeriesNo] = Color;

	return 0;
}
const COLORREF &CLineGraph::getColor(uint32_t SeriesNo){
	return m_LineColor[SeriesNo%MAX_Series];
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �|�C���g�ʒu���v���b�g�G���A���H
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
bool CLineGraph::isPlotAreaInside(const CPoint &Point) const{
	if((Point.x >= m_PlotArea.left) && (Point.x <= m_PlotArea.right) 
	&& (Point.y >= m_PlotArea.top) && (Point.y <= m_PlotArea.bottom)){
		return true;
	}
	return false;
}
bool CLineGraph::isXPlotAreaInside(const CPoint &Point) const{
	if ((Point.x >= m_PlotArea.left) && (Point.x <= m_PlotArea.right)){
		return true;
	}
	return false;
}
bool CLineGraph::isYPlotAreaInside(const CPoint &Point) const{
	if ((Point.y >= m_PlotArea.top) && (Point.y <= m_PlotArea.bottom)){
		return true;
	}
	return false;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// LineDataSet�� �`��
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int CLineGraph::draw(const LineDataSet &Data)
{
	int ack;

	if(Data.isAppend(m_Data) &&	(m_ReDraw == 0)){
		m_Data = Data;
		ack = drawAllSeries();
	}else{
		m_Data = Data;
		ack = onPaint();
	}

	return ack;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �O���b�h��`�悷��
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int CLineGraph::drawGrid(){
	int ixpt,iypt;
	float fvalx,fvaly;	// �f�[�^���l
	float endx,endy;
	const RECT &parea = m_PlotArea;
	RECT carea;
	CString str;
	CDC* pDC = m_pWnd->GetDC();

	m_pWnd->GetClientRect(&carea);

	setPlotArea();

	endx = m_XMax - m_XMin;
	if ((endx <= 0) || (m_XGridSpacing == 0))	{ return -3;	}

	endy = m_YMax - m_YMin;
	if((endy <= 0) || (m_YGridSpacing == 0))	{ return -3;	}

#if 0
	if (m_XDivNum > 0){
		m_XGridSpacing = endx / (m_XDivNum + 1);
	}
	if (m_YDivNum > 0){
		m_YGridSpacing = endy / (m_YDivNum + 1);
	}
#endif

	// �O�g��`�� X,Y
#if 1
	pDC->Rectangle(carea.left, carea.top, carea.right, carea.bottom);
	pDC->MoveTo(parea.left, parea.top);
	pDC->LineTo(parea.right, parea.top);
	pDC->MoveTo(parea.right, parea.top);
	pDC->LineTo(parea.right, parea.bottom);

	pDC->MoveTo(parea.right, parea.bottom);
	pDC->LineTo(parea.left, parea.bottom);
	pDC->MoveTo(parea.left, parea.bottom);
	pDC->LineTo(parea.left, parea.top);
#else
	pDC->Rectangle(parea.left, parea.top, parea.right, parea.bottom);
#endif

    CPen NewPen;
    NewPen.CreatePen(PS_DOT, 1, RGB(127,127,127));
	CPen* OldPen = pDC->SelectObject(&NewPen);

	pDC->SelectObject(m_XAxisLabelFont);
	pDC->SetTextColor(m_XAxisLabelRgb);

	// �����@�����x��
//--	str.Format(_T("%2.1f"),m_XMin);
	int xlabeloffset = 	m_TextSize * m_XStringLength / 40;
//		pDC->TextOut(parea.left - xlabeloffset, parea.bottom+2, str);

	// **** X�� �⏕�� ****
	// �c����`��
	fvalx = ((int)roundf(m_XMin/m_XGridSpacing))*m_XGridSpacing;
	fvalx -= m_XMin;
	if(fvalx <= 0)	fvalx+= m_XGridSpacing;
	endx = m_XMax - m_XMin;
	for(;fvalx<=endx;fvalx+=m_XGridSpacing){
		ixpt = parea.left + (int)(fvalx * m_XScale);
		//	�g���㏑������Ȃ��悤�ɁB �`��|�C���g�Ŕ�r
		if ((ixpt > parea.left) && (ixpt < parea.right)){	// (fvalx != m_XMin) && (fvalx != m_XMax)
			pDC->MoveTo(ixpt, parea.top);
			pDC->LineTo(ixpt, parea.bottom);
		}

//--		str.Format(_T("%2.1f"), fvalx + m_XMin);
		str = toXLabelString(fvalx + m_XMin);
		pDC->TextOut(ixpt - xlabeloffset, parea.bottom + 2, str);
	}
#if 0
	fpt = parea.left+(int)(fvalx*m_XScale);
	str.Format(_T("%2.1f") ,fvalx);
	pDC->TextOut(fpt - xlabeloffset, parea.bottom+2, str);
#endif

	// ������`��
//--		str.Format(_T("%2.1f"),m_YMax);
//--		xlabeloffset	= (m_TextSize * str.GetLength()) / 16;
	int ylabeloffset = 	m_TextSize / 16;
//		pDC->TextOut(parea.left -xlabeloffset ,fpt -ylabeloffset ,str);

	fvaly = ((int)roundf(m_YMin/m_YGridSpacing))*m_YGridSpacing;
	fvaly -= m_YMin;
	if (fvaly <= 0)	fvaly += m_YGridSpacing;
	endy = m_YMax - m_YMin;
	for(;fvaly<=endy;fvaly+=m_YGridSpacing){
		iypt = (parea.bottom - (int)(fvaly * m_YScale));
		//	�g���㏑������Ȃ��悤�ɁB �`��|�C���g�Ŕ�r
		if ((iypt > parea.top) && (iypt < parea.bottom)){	// (fvaly != m_YMin) && (fvaly != m_YMax)
			// �g�ƕ⏕���͓����̈�ɕ`�悳���Ȃ��B
			pDC->MoveTo(parea.left, iypt);
			pDC->LineTo(parea.right, iypt);
		}

//--		str.Format(_T("%2.1f"), fvaly + m_YMin);
		str	= toYLabelString(fvaly + m_YMin);
		xlabeloffset	= (m_TextSize * m_YStringLength) / 14;
		pDC->TextOut(parea.left - xlabeloffset, iypt - ylabeloffset, str);
	}
#if 0
	str.Format(_T("%2.1f") ,fvaly);
	xlabeloffset	= (m_TextSize * str.GetLength()) / 16;
	fpt = (parea.bottom-(int)(fvaly*m_YScale));
	pDC->TextOut(parea.left - xlabeloffset, fpt - ylabeloffset, str);
#endif
	pDC->SelectObject(OldPen);
    NewPen.DeleteObject();

	m_pWnd->ReleaseDC(pDC);

	return 0;
}
#if 0
int CLineGraph::drawLineint32_t(const int32_t *Data, int Len)
{
	RECT lprc;
	CPoint oldpoint, newpoint;
	bool oldinside_x, newinside_x;
	bool oldinside_y, newinside_y;
	int i;
	CDC* pDC = m_pWnd->GetDC();
	const RECT &parea = m_PlotArea;

	drawGrid();

	CPen NewPen;
	NewPen.CreatePen(PS_SOLID, 1, m_LineColor[0]);
	CPen* OldPen = pDC->SelectObject(&NewPen);

	oldpoint = toPoint(0, Data[0]);
	oldinside_x = isXPlotAreaInside(oldpoint);
	oldinside_y = isYPlotAreaInside(oldpoint);

	for (i = 1; i<Len; i++){
		newpoint = toPoint(i, Data[i]);
		newinside_x = isXPlotAreaInside(newpoint);
		newinside_y = isYPlotAreaInside(newpoint);

		//			if ((iypt > parea.top) && (iypt < parea.bottom)){
		//			if ((newpoint.x > parea.left) && (newpoint.x < parea.right))

		if (newinside_x & oldinside_x){
			if (newinside_y){
				if (oldinside_y){
					// oldpoint newpoint �����Ƃ��̈�͈͓�
					pDC->MoveTo(oldpoint);
					pDC->LineTo(newpoint);
				}
				else{
					drawOneOfOutside(pDC, newpoint, oldpoint);
				}
			}else{
				if (oldinside_y){
					drawOneOfOutside(pDC, oldpoint ,newpoint);
				}
				else{
					// oldpoint newpoint �����Ƃ��̈�͈͊O
					drawOneOfOutside2(pDC, oldpoint ,newpoint);
				}
			}
		
		}

		oldpoint = newpoint;
		oldinside_x = newinside_x;
		oldinside_y = newinside_y;
	}

	pDC->SelectObject(OldPen);
	NewPen.DeleteObject();

	m_pWnd->ReleaseDC(pDC);

	return 0;
}
#endif

#if 0
template<typename X>
int CLineGraph::drawLine(const X *Data, int Len)
{
	CPoint oldpoint, newpoint;
	bool oldinside_x, newinside_x;
	bool oldinside_y, newinside_y;
	int i;
	CDC* pDC = m_pWnd->GetDC();
	const RECT &parea = m_PlotArea;

	drawGrid();

	CPen NewPen;
	NewPen.CreatePen(PS_SOLID, 1, m_LineColor[0]);
	CPen* OldPen = pDC->SelectObject(&NewPen);

	oldpoint = toPoint(0.0f, static_cast<Float32>(Data[0]));
	oldinside_x = isXPlotAreaInside(oldpoint);
	oldinside_y = isYPlotAreaInside(oldpoint);

	for (i = 1; i<Len; i++){
		newpoint = toPoint(i, static_cast<Float32>(Data[i]));
		newinside_x = isXPlotAreaInside(newpoint);
		newinside_y = isYPlotAreaInside(newpoint);

		//			if ((iypt > parea.top) && (iypt < parea.bottom)){
		//			if ((newpoint.x > parea.left) && (newpoint.x < parea.right))

		if (newinside_x & oldinside_x){
			if (newinside_y){
				if (oldinside_y){
					// oldpoint newpoint �����Ƃ��̈�͈͓�
					pDC->MoveTo(oldpoint);
					pDC->LineTo(newpoint);
				}
				else{
					drawOneOfOutside(pDC, newpoint, oldpoint);
				}
			}
			else{
				if (oldinside_y){
					drawOneOfOutside(pDC, oldpoint, newpoint);
				}
				else{
					// oldpoint newpoint �����Ƃ��̈�͈͊O
					drawOneOfOutside2(pDC, oldpoint, newpoint);
				}
			}

		}

		oldpoint = newpoint;
		oldinside_x = newinside_x;
		oldinside_y = newinside_y;
	}

	pDC->SelectObject(OldPen);
	NewPen.DeleteObject();

	m_pWnd->ReleaseDC(pDC);

	return 0;
}
#endif

int32_t CLineGraph::draw1Series(SeriesBase &Ser, uint32_t SeriesNo)
{
	int32_t *pi;
	Float32 *pf;

	if (Ser.empty())	return -1;

	switch (Ser.getValTypeId()){
	case SeriesBase::ENE_int32_t:
		pi = Ser.getSeriesInt32Arrow();
		return draw1Series(pi, Ser.size(), SeriesNo);
	case SeriesBase::ENE_float32:
		pf = Ser.getSeriesFloat32Arrow();
		return draw1Series(pf, Ser.size(), SeriesNo);
	}

	return -1;
}
int32_t CLineGraph::drawAllSeries()
{
	int32_t	i,end;
	SeriesBase *sb;

	if (dataSet().empty())	{ return -3;	}

	end = dataSet().size();
	for (i = 0;i<end;i++){
		sb = dataSet().getElement(i);
		if (sb){
			draw1Series(*sb, i);
		}
	}
}
int32_t CLineGraph::onPaint()
{
	int32_t ack;

	drawGrid();
	ack = drawAllSeries();

	m_ReDraw = 0;

	return ack;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �Е��̃|�C���g���͂ݏo���Ă�ꍇ�A
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int CLineGraph::drawOneOfOutside(CDC* pDC, const CPoint &BasePoint, CPoint DestPoint){

	float a = (float)(DestPoint.x - BasePoint.x) / (float)(DestPoint.y - BasePoint.y);

	if (DestPoint.y < m_PlotArea.top){
		DestPoint.x += static_cast<int>((m_PlotArea.top - DestPoint.y) * a);
		DestPoint.y = m_PlotArea.top;

	}
	else if (DestPoint.y > m_PlotArea.bottom){
		DestPoint.x -= static_cast<int>((DestPoint.y - m_PlotArea.bottom) * a);
		DestPoint.y = m_PlotArea.bottom;
	}

	pDC->MoveTo(BasePoint);
	pDC->LineTo(DestPoint);

	return 0;
}
// �����̃|�C���g���͂ݏo���Ă�ꍇ
int CLineGraph::drawOneOfOutside2(CDC* pDC, CPoint BasePoint, CPoint DestPoint){

	float a = (float)(DestPoint.x - BasePoint.x) / (float)(DestPoint.y - BasePoint.y);

	if (BasePoint.y < m_PlotArea.top){
		BasePoint.x += static_cast<int>((m_PlotArea.top - BasePoint.y) * a);
		BasePoint.y = m_PlotArea.top;
	}
	else if (BasePoint.y > m_PlotArea.bottom){
		BasePoint.x -= static_cast<int>((BasePoint.y - m_PlotArea.bottom) * a);
		BasePoint.y = m_PlotArea.bottom;
	}
	
	if (DestPoint.y < m_PlotArea.top){
		DestPoint.x += static_cast<int>((m_PlotArea.top - DestPoint.y) * a);
		DestPoint.y = m_PlotArea.top;
	}
	else if (DestPoint.y > m_PlotArea.bottom){
		DestPoint.x -= static_cast<int>((DestPoint.y - m_PlotArea.bottom) * a);
		DestPoint.y = m_PlotArea.bottom;
	}

	pDC->MoveTo(BasePoint);
	pDC->LineTo(DestPoint);

	return 0;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// ���l�����W�ɕϊ����܂��B �̈�`�F�b�N���s���܂���
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
CPoint CLineGraph::toPoint(float x1, float y1){

	int point_x = m_PlotArea.left + (int)((x1 - m_XMin)*m_XScale);
	int point_y = m_PlotArea.bottom - (int)((y1 - m_YMin)*m_YScale);

	return CPoint(point_x, point_y);
}
CPoint CLineGraph::toPointi(int x1, int y1)
{
	return toPoint(static_cast<float>(x1) ,static_cast<float>(y1));
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �v���b�g�G���A�Ƒ��Ԋu��ݒ肵�܂��B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int CLineGraph::setPlotArea()
{
	RECT rect;
	float scale[2] = { m_XScale , m_YScale };
	RECT parea = m_PlotArea;

	m_pWnd->GetClientRect(&rect);

	m_PlotArea.top = rect.top + EPM_top;
	m_PlotArea.left = rect.left + EPM_left;
	m_PlotArea.right = rect.right - EPM_right;
	m_PlotArea.bottom = rect.bottom - EPM_bottom;

	m_XScale = (float)(m_PlotArea.right - m_PlotArea.left) / (m_XMax - m_XMin);
	m_YScale = (float)(m_PlotArea.bottom - m_PlotArea.top) / (m_YMax - m_YMin);

	if((m_PlotArea.top != parea.top)||(m_PlotArea.bottom != parea.bottom)||(m_PlotArea.left != parea.left)||(m_PlotArea.right != parea.right)  || (scale[0]!=m_XScale) || (scale[1]!=m_YScale)){
		m_ReDraw = 1;
	}

	return 0;
}

/*
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
template<typename X>
int CLineGraph::drawLine(const int *Data, int Len){
	RECT lprc;
	CPoint oldpoint, newpoint;
	bool oldinside, newinside;
	//		pWnd->GetClientRect(&lprc);
	//		lprc.top;
	int i;
	CDC* pDC = m_pWnd->GetDC();

	drawGrid();

	CPen NewPen;
	NewPen.CreatePen(PS_SOLID, 1, m_LineColor[0]);
	CPen* OldPen = pDC->SelectObject(&NewPen);

	oldpoint = toPoint(0, Data[0]);
	oldinside = isPlotAreaInside(oldpoint);

	for (i = 1; i<Len; i++){
		newpoint = toPoint(i, Data[i]);
		newinside = isPlotAreaInside(newpoint);

		// Y�����̈�I�[�o�[�`�F�b�N
		if (newinside){
			if (oldinside){
				pDC->MoveTo(oldpoint);
				pDC->LineTo(newpoint);
			}
			else{
				drawOneOfOutside(pDC, newpoint, oldpoint);
			}
		}
		else{
			if (oldinside){
				drawOneOfOutside(pDC, oldpoint, newpoint);
			}
			else{
			}
		}

		oldpoint = newpoint;
		oldinside = newinside;
	}

	pDC->SelectObject(OldPen);
	NewPen.DeleteObject();

	m_pWnd->ReleaseDC(pDC);

	return 0;
}
*/

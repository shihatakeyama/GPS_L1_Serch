// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// GTS_Global.h
//
//
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

#pragma once

#include "stdafx.h"

#include <vector>

#include "GnrlDefine.h"
#include "GnrlCharset.h"

#include "L1CaCode.h"

#include "L1Define.h "
#include "GPU_L1_FreqPhase.h"
#include "L1Tracking.h"


extern std::vector<L1CaCode>	gL1CaCode;
extern L1TrackingCh				gL1TrackingCh[32];

extern int32_t OutData[MAX_THREADS*64*40];
extern int32_t OutiData[MAX_THREADS*64*40];
extern int32_t OutqData[MAX_THREADS*64*40];


// RF�ݒ�
// �V�X�e���N���b�N
extern uint32_t gSysFreqRes;
// �L�����A���g��
extern uint32_t gL1CarrFreqRes;
// �R�[�h���g��(�n�[�t�`�b�v)
extern uint32_t gL1CodeFreqRes;


void L1makeCaCodelist();

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// GPU_L1_FreqPhase.hpp
// 
// �L�����A��CA�R�[�h�� ���g���ƈʑ����i�[����
// 
// DEVICE �F CUDA
//
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *



__device__ __host__ void GPU_L1_FreqPhase::getCodePhase(uint32_t &Chip ,uint32_t &Phase ,int32_t PhaseDistance) const
{
	uint64_t codephase = (((uint64_t)Base.CodeChip) << 32) + (uint64_t)Base.CodePhase;	//  + ((uint64_t)Delta.CodeChip*PhaseDistance)

	codephase += ((uint64_t)Delta.CodePhase * PhaseDistance);
	Phase = (uint32_t)codephase;
	Chip = ((uint32_t)(codephase>>32)) % 1023;
}

__device__ __host__ uint32_t GPU_L1_FreqPhase::getCarrPhase(int32_t PhaseDistance) const
{
	return Base.CarrPhase + (Delta.CarrPhase * PhaseDistance);
}

__device__ __host__ uint32_t GPU_L1_FreqPhase::getCodeFreq(int32_t FraqDistance) const
{
	return Base.CodeFreq + (Delta.CodeFreq * FraqDistance);
}

__device__ __host__ uint32_t GPU_L1_FreqPhase::getCarrFreq(int32_t FraqDistance) const
{
	return Base.CarrFreq + (Delta.CarrFreq * FraqDistance);
}



// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// 							  
// Source File Nmae : 
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *


#include "stdafx.h"

#include <stdint.h>

#include "L1PrnTap.h"

#include "SP_Define.h "
#include "L1Define.h "
#include "L1CaCode.h"
#include "GTS_Global.h"

//#include "fft.h"

#define MAX_TEST_AD		5714*4
// ���ւ�����ׂ̎����f�[�^
int8_t gTestAdData[MAX_TEST_AD];


const char i_table[] = {+1 ,+3 ,+3 ,+1 ,-1 ,-3 ,-3 ,-1};	// GP2010 �L�����A ���v���J
const char q_table[] = {+3 ,+1 ,-1 ,-3 ,-3 ,-1 ,+1 ,+3};

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// GPS�f�[�^���쐬
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t GTS_makeTestData(int8_t *OutData ,int32_t Len ,const int8_t *CaCode)
{
	int32_t itr;
	int8_t inca;	

	uint32_t code_chip;
	uint32_t code_phase,code_phase_old;
	uint32_t carr_phase;
	uint32_t code_freq,carr_freq;
	float32_t tp;

	code_chip = 0;
	code_phase_old = code_phase = 0;	// �����R�[�h�ʑ���ݒ肵�ĉ������B

	code_freq = clkFreq(gSysFreqRes ,(uint32_t)(CODE_FREQ_RES/2));

	carr_phase = 0;
	carr_freq = clkFreq(gSysFreqRes ,gL1CarrFreqRes);

	for(itr=0;itr<Len;itr++){
		
		inca = CaCode[code_chip];
//		inca = 1;
		inca *= i_table[carr_phase>>29];
//		tp = (carr_phase/4294967296.0f) * M_PI*2;
//		inca *= sin(tp) * 3.9f;

		OutData[itr] = inca;

		code_phase += code_freq;
		if(code_phase < code_phase_old)	{
			code_chip++;
			code_chip = code_chip % 1023;
		}
		code_phase_old = code_phase;
		carr_phase += carr_freq;
	}

	return 0;
}


int GPU_L1Search_gpu(const uint8_t *InData ,size_t DataLen ,const int8_t *CaCode);
int GPU_L1Search_gpu2(float32_t *line1, const uint8_t *InData ,size_t DataLen);
int32_t dftf(const float32_t *InData ,float32_t *ReData ,float32_t *ImData ,size_t Len);
int GPU_L1Accumlevel(const uint8_t *InData ,size_t DataLen ,float *Devout);
uint8_t gIndata[1024*1024];
float32_t gfRe[1024*1024];
float32_t gfIm[1024*1024];

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// GPS�f�[�^���T�[�`
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t GTS_CorrTest(LineDataSet &Lds)	// 
{
    int size = 5714*2+50;
	int procsize = 16.368e6*3/1024;
	L1makeCaCodelist();

	gSysFreqRes = 16.368e6;
	gL1CarrFreqRes = 4.092e6;

#if 1
//	CString adfilename = N_T("D:\\tmp\\gps_20111027_�A���e�i20cm������.dat");
//	CString adfilename = N_T("D:\\IF_Dump\\IFDump20120722_�ł��グ300��.dat");
	CString adfilename = N_T("D:\\IF_Dump\\gps8sm_max2769.dat");

	std::ifstream ifs(adfilename, ios::in | ios::binary );	// �o�C�i�����[�h�łɂ��Ȃ��ƁA�ǂݍ��񂾃t�@�C���T�C�Y������Ȃ��Ȃ�B
    if (ifs.fail()){
        std::cerr << "���s" << std::endl;
        return -1;
    }
    int begin = static_cast<int>(ifs.tellg());
    ifs.seekg(0, ifs.end);
    // �ꉞ�͈̓`�F�b�N���ׂ������ǁc�c
    int end = static_cast<int>(ifs.tellg());
    size = end - begin;
    ifs.clear();		 // ������clear����EOF�t���O������
    ifs.seekg(0, ifs.beg);
/*    char *str = new char[size + 1];
    str[size] = '\0';	 // �O�̂��ߖ�����NULL������
	*/
	size = MIN((uint32_t)size ,(uint32_t)sizeof(gIndata));
    ifs.read((char*)gIndata, size);

#else
	GTS_makeTestData((int8_t*)gIndata ,procsize ,&gL1CaCode[0][0]);
#endif

	Lds.addFloat32(2048);

//		GPU_L1Search_gpu((const uint8_t*)gTestAdData ,5714 ,(const int8_t*)(&gL1CaCode[0][0]));
//	GPU_L1Search_gpu2(Lds[0].getSeriesFloat32Arrow() ,(const uint8_t*)gIndata ,procsize);		// Lds ,
//	GPU_L1Accumlevel((const uint8_t*)gIndata ,procsize);

	return 0;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// GPS�f�[�^��FFT
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t GTS_FFT_Test(LineDataSet &Lds)
{
	int i;
	int size;
	int procsize = 1024*4;
	L1makeCaCodelist();
	LineDataSet din;
	size_t in_offset = 1024*1;

#if 0
//	CString adfilename = N_T("D:\\IF_Dump\\gps_20111027_�A���e�i20cm������.dat");
//	CString adfilename = N_T("D:\\IF_Dump\\IFDump20120722_�ł��グ300��.dat");
	CString adfilename = N_T("D:\\IF_Dump\\gps8sm_max2769.dat");

	std::ifstream ifs(adfilename, ios::in | ios::binary );	// �o�C�i�����[�h�łɂ��Ȃ��ƁA�ǂݍ��񂾃t�@�C���T�C�Y������Ȃ��Ȃ�B
    if (ifs.fail()){
        std::cerr << "���s" << std::endl;
        return -1;
    }
    int begin = static_cast<int>(ifs.tellg());
    ifs.seekg(0, ifs.end);
    // �ꉞ�͈̓`�F�b�N���ׂ������ǁc�c
    int end = static_cast<int>(ifs.tellg());
    size = end - begin;
    ifs.clear();		 // ������clear����EOF�t���O������
    ifs.seekg(0, ifs.beg);
/*    char *str = new char[size + 1];
    str[size] = '\0';	 // �O�̂��ߖ�����NULL������
	*/
	size = MIN((uint32_t)size ,(uint32_t)sizeof(gIndata));
    ifs.read((char*)gIndata, size);

#endif
#if 0
		GTS_makeTestData((int8_t*)gIndata ,32768 ,&gL1CaCode[0][0]);
#endif


#if 1
	loadIQData(din ,N_T("D:\\MyDocuments\\k_�J����������\\N15041_��n�ǎ�M���x����\\��MIQ\\-100dB20150612_145138_IQ-Data.csv"));
#endif

	for(i=0;i<procsize;i++){
		gfRe[i]	= static_cast<int8_t>(gIndata[i]);
		gfIm[i] = 0.0f;
	}

	LineDataSet ds;
	ds.addFloat32(procsize);
	ds.addFloat32(procsize);

//	numpy::hammingMulti(din[0].getSeriesFloat32Arrow()+1024*12 ,procsize);
//	numpy::hammingMulti(din[1].getSeriesFloat32Arrow()+1024*12 ,procsize);

//	fft.fft(gfRe ,gfIm ,ds[0].getSeriesFloat32Arrow(),ds[1].getSeriesFloat32Arrow());
//	memset(din[0].getSeriesFloat32Arrow()+(in_offset+procsize/8) ,0 ,(procsize-procsize/8)*sizeof(float32_t));
//	memset(din[1].getSeriesFloat32Arrow()+(in_offset+procsize/8) ,0 ,(procsize-procsize/8)*sizeof(float32_t));
//	fft.fft(din[0].getSeriesFloat32Arrow()+in_offset ,din[1].getSeriesFloat32Arrow()+in_offset ,ds[0].getSeriesFloat32Arrow(),ds[1].getSeriesFloat32Arrow());
//	dftf(din[0].getSeriesFloat32Arrow()+in_offset ,ds[0].getSeriesFloat32Arrow(),ds[1].getSeriesFloat32Arrow() ,procsize);

	Lds.addFloat32(procsize);
	Lds = ds.vector();

	return 0;
}

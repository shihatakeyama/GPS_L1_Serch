// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  DataSet.h
//
//
//  dependent : Win32,MFC
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

#include "stdafx.h"

//#include "DataSet.h"

#include <vector>
#include <algorithm>

#include "DataSet.h"

const SeriesBase::Seriesint32_t	SeriesBase::mErrint32_t;
const SeriesBase::SeriesFloat32 SeriesBase::mErrFloat32;

#if 0
template<typename X>
int toValType(X Arg)
{
	int ret;

	switch(typeid(X)){
	case typeid(Sint64):
		m_ValType = ENE_sint64;
		break;	
	case typeid(Uint32):
		m_ValType = ENE_uint32;
		break;
	case typeid(Uint64):
		m_ValType = ENE_uint64;
		break;
	case typeid(Float32):
		m_ValType = ENE_float32;
		break;
	case typeid(Float64):
		m_ValType = ENE_float64;
		break;
	default:
		m_ValType = ENE_int32_t;
		break;
	}
}
#endif

template<typename X>
GraphSeries1Ch<X>::GraphSeries1Ch()	// int32_t ValTypeId
{
//--	m_ValType = (enum E_ValType)ValTypeId;

	if(typeid(X) == typeid(int64_t)){
		m_ValType = ENE_sint64;
	}else if(typeid(X) == typeid(uint32_t)){
		m_ValType = ENE_uint32;
	}else if(typeid(X) == typeid(uint64_t)){
		m_ValType = ENE_uint64;
	}else if(typeid(X) == typeid(Float32)){
		m_ValType = ENE_float32;
	}else if(typeid(X) == typeid(Float64)){
		m_ValType = ENE_float64;
	}else{
		m_ValType = ENE_int32_t;
	}

//	m_ValType = toValType(X);
}

template<typename X>
GraphSeries1Ch<X>::GraphSeries1Ch(const GraphSeries1Ch<X> &Arg)
{
	m_ValType = Arg.m_ValType;
	m_Data = Arg.m_Data;
}

template<typename X>
GraphSeries1Ch<X>::~GraphSeries1Ch()
{}

template<typename X>
const SeriesBase & GraphSeries1Ch<X>::operator = (const SeriesBase &Arg)
{
	const GraphSeries1Ch<X> &myarg = dynamic_cast<const GraphSeries1Ch<X>&>(Arg);

	m_Data = myarg.m_Data;

	return (SeriesBase&)*this;
}

template<typename X>
const SeriesBase &GraphSeries1Ch<X>::operator = (const std::vector<int32_t> &Arg)
{
	m_Data.clear();
	m_Data.reserve(Arg.size());

	for(const auto &itr : Arg){
		m_Data.push_back(itr);
	}
	
	return *this;
}
template<typename X>
const SeriesBase &GraphSeries1Ch<X>::operator = (const std::vector<Float32> &Arg)
{
	m_Data.clear();
	m_Data.reserve(Arg.size());

	for(const auto &itr : Arg){
		m_Data.push_back(itr);
	}

	return *this;
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �ő�l�ƍŏ��l���擾
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
template<typename X>
bool GraphSeries1Ch<X>::minAndMaxFloat32(Float32 &Min, Float32 &Max) const
{
	Float32 min, max, itr;
	int32_t i, end;
	if (empty() == true)			{ return false; }

	min = max = static_cast<Float32>(m_Data[0]);

	end = m_Data.size();
	for (i = 1; i<end; i++){
		itr = (Float32)(m_Data[i]);
		if (min > itr){
			min = itr;
		}
		else if (max < itr){
			max = itr;
		}
	}
	Min = min;
	Max = max;

	return true;
}
template<typename X>
bool GraphSeries1Ch<X>::minAndMax(X &Min, X &Max) const{
	X min, max, itr;
	int32_t i, end;
	if (empty() == true)			{ return false; }

	min = max = m_Data[0];

	end = m_Data.size();
	for (i = 1; i<end; i++){
		itr = m_Data[i];
		if (min > itr){
			min = itr;
		}
		else if (max < itr){
			max = itr;
		}
	}
	Min = min;
	Max = max;

	return true;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �Â��G���g���[���폜
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
template<typename X>
int32_t	GraphSeries1Ch<X>::deleteOldEntry(size_t Len){

	if (empty() == true)				{ return -3; }
	if (Len <= 0)						{ return -4; }

	Len = MIN(Len, m_Data.size());

	m_Data.erase(m_Data.begin(), m_Data.begin() + Len);

	return 0;
}

// ----------------- GraphSeries1Ch / LineDataSet -------------------------------
LineDataSet::LineDataSet()
{
}
LineDataSet::LineDataSet(const LineDataSet &Arg)
{
	int32_t i,end;
	SeriesBase	*sb;

	if(this == &Arg)	return;
	if(Arg.empty())		return;

	end = Arg.size();
	for (i = 0; i < end; i++){
		add(Arg[i].clone());
	}
}

LineDataSet::~LineDataSet(){
	clear();
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �S�f�[�^���N���A���܂��B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void LineDataSet::clear()
{
	std::for_each(m_Data.begin() ,m_Data.end() ,[](SeriesBase *elem){
		delete elem;
	});

	m_Data.clear();	
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// ���
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
const LineDataSet &LineDataSet::operator = (const LineDataSet &Arg)
{
	int32_t i,end;
	SeriesBase	*sb;

	if(this == &Arg)	return *this;

	clear();

	if(Arg.empty())		return *this;

	end = Arg.size();
	for (i = 0; i < end; i++){
		add(Arg[i].clone());
	}

	return *this;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
bool LineDataSet::minAndMaxFloat32(Float32 &Min, Float32 &Max) const
{
	Float32 minv, maxv;
	int32_t i, end;
	bool ret = false;
	if (empty() == true)			{ return false; }

	end = size();
	for (i = 0; i<end; i++){
		if (m_Data[i]->minAndMaxFloat32(minv, maxv)){
			if (ret == false){
				ret = true,
					Min = minv,	// ���߂Ď擾�ł����V���[�Y
					Max = maxv;
			}
			else{
				Min = min(Min, minv),
					Max = max(Max, maxv);
			}
		}
	}
	return ret;
}

#if 0
class MaxSeriesLen {
public:
	MaxSeriesLen()
		:m_Max(0)
	{}

	void operator()(const SeriesBase* Arg) {
		m_Max = max(m_Max, Arg->size());
	}

	int32_t m_Max;
};
#endif

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �������̃V���[�Y�̒��̃G���g���[�����ł��傫���l��Ԃ��B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t LineDataSet::getSeriesLen() const
{
	size_t ret = 0, sizetmp;
	int32_t maxlen=0;

	if (empty() == true)			{ return 0; }

#if 0
	end = size();
	for (i = 0; i<end; i++){
		sizetmp = m_Data[i]->size();

		ret = max(ret, sizetmp);
	}
#else
	for(auto &itr :m_Data){
		ret = max(ret ,itr->size());
	}

#endif

	return ret;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �e�G���g���[�̌Â��f�[�^���폜���܂��B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t LineDataSet::deleteOldEntry(size_t Len)
{
	Float32	minv, maxv;
	size_t	i, end;

	if (empty() == true)			{ return false; }

	end = size();
	for (i = 0; i<end; i++){
		m_Data[i]->deleteOldEntry(Len);	 //
	}

	return 0;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �����̃N���[����Ԃ��܂��B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
SeriesBase *SeriesBase::clone() const
{
	SeriesBase *sb = NULL;

	switch(m_ValType){
	case ENE_int32_t:
		sb = new GraphSeries1Ch<int32_t>	(*(const Seriesint32_t*)this);
		break;
	case ENE_float32:
		sb = new GraphSeries1Ch<Float32>(*(const SeriesFloat32*)this);
		break;

	default:
		break;
	};

	return sb;
}

CString SeriesBase::toString(int32_t Ordinal/*, const CString Format*/) const
{
	CString str;

#if 0
	if (getValTypeId() == ENE_int32_t){
		int32_t val = operator[]<int32_t>(Ordinal);
		str.Format(N_T("%d") ,val);
	}else if(getValTypeId() == ENE_float32){
		Float32 val = operator[]<Float32>(Ordinal);
		str.Format(N_T("%f") ,val);
	}
#endif

	return str;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �V���[�Y��ǉ����܂��B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
SeriesBase::Seriesint32_t *SeriesBase::newSeriesSint32()
{
	return new GraphSeries1Ch<int32_t>();	//SeriesBase::ENE_int32_t
}
SeriesBase::SeriesFloat32 *SeriesBase::newSeriesFloat32()
{
	return new GraphSeries1Ch<Float32>();	//SeriesBase::ENE_float32
}

SeriesBase *SeriesBase::newSeries(enum E_ValType ValTypeId){
	SeriesBase *pseri = NULL;

	switch (ValTypeId){
	case SeriesBase::ENE_int32_t:
		pseri = new GraphSeries1Ch<int32_t>();	// ValTypeId
		break;
	case SeriesBase::ENE_sint64:
		pseri = new GraphSeries1Ch<int64_t>();
		break;
	case SeriesBase::ENE_uint32:
		pseri = new GraphSeries1Ch<uint32_t>();
		break;
	case SeriesBase::ENE_uint64:
		pseri = new GraphSeries1Ch<uint64_t>();
		break;
	case SeriesBase::ENE_float32:
		pseri = new GraphSeries1Ch<Float32>();
		break;
	case SeriesBase::ENE_float64:
		pseri = new GraphSeries1Ch<Float64>();
		break;
	}
	return pseri;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �����̓��e�����N���X�ɂ�����B
// �O���t�̍ĕ`��̕K�v���B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
bool LineDataSet::isAppend(const LineDataSet &Arg) const
{
	int32_t i=0;

	if(size() < Arg.size())	return FALSE;

	for(const auto &itr1 : Arg.m_Data){
		const SeriesBase *itr0 = getElement(i);
		if(!itr0->isAppend(*itr1)){
			return FALSE;
		}
		i++;
	}

	return TRUE;
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �G�������g���m��RMS���v�Z���܂��B
// �e�G�������g�̃T�C�Y�͓����ł���K�v������܂��B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
LineDataSet LineDataSet::vector() const{
		
	LineDataSet ret;
	if(empty())	return ret;
	int32_t seriess = size();
	int32_t i,ssize;
	int32_t valtype;


	ssize	= (*this)[0].size();
	valtype	= (*this)[0].getValTypeId();
	for(i=1;i<seriess;i++){
		if((*this)[i].size() != ssize){
			ASSERT(0);
			return ret;
		}
	}

//	ret.addSeries(&((*this)[0]));
	ret.addSeries((*this)[0].getValTypeId());


#if 1
//		TYPEFUNC_1TO1(ret[0] ,(*this)[0] ,vector1_func);
	TYPEFUNC_2TO1(ret[0] ,(*this)[0] ,(*this)[1] ,vector2_func);
#else
	switch ((*this)[0].getValTypeId()){			\
case SeriesBase::ENE_int32_t:	\
{								\
	const SeriesBase::Seriesint32_t *in_c = dynamic_cast<const SeriesBase::Seriesint32_t*>(&(*this)[0]);		\
	SeriesBase::Seriesint32_t *out_c = dynamic_cast<SeriesBase::Seriesint32_t*>(&ret[0]);	\
	vector_func<SeriesBase::Seriesint32_t>(*out_c ,*in_c);								\
	break;						\
}								\
case SeriesBase::ENE_float32:	\
{								\
	const SeriesBase::SeriesFloat32 *in_c = dynamic_cast<const SeriesBase::SeriesFloat32*>(&(*this)[0]);		\
	SeriesBase::SeriesFloat32 *out_c = dynamic_cast<SeriesBase::SeriesFloat32*>(&ret[0]);	\
	vector_func<SeriesBase::SeriesFloat32>(*out_c ,*in_c);							\
	break;						\
}								\
}
#endif

	return ret;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �V���[�Y��ǉ����܂��B
// @ ValTypeId : E_ValType
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
SeriesBase::Seriesint32_t *LineDataSet::addSeriesSint32()
{
	SeriesBase::Seriesint32_t *elem = SeriesBase::newSeriesSint32();
	m_Data.push_back(elem);
	return elem;
}
SeriesBase::SeriesFloat32 *LineDataSet::addSeriesFloat32()
{
	SeriesBase::SeriesFloat32 *elem = SeriesBase::newSeriesFloat32();
	m_Data.push_back(elem);
	return elem;
}
void LineDataSet::addSint32(size_t SeriesDataSize)
{
	SeriesBase::Seriesint32_t *elem = SeriesBase::newSeriesSint32();
	elem->resize(SeriesDataSize);
	m_Data.push_back(elem);
}

void LineDataSet::addFloat32(size_t SeriesDataSize)
{
	SeriesBase::SeriesFloat32 *elem = SeriesBase::newSeriesFloat32();
	elem->resize(SeriesDataSize);
	m_Data.push_back(elem);
}
void LineDataSet::add(SeriesBase *Series)
{
///	SeriesBase *elem = Series;//Series->clone();
	m_Data.push_back(Series);
}

/*SeriesBase *LineDataSet::addSeries(int32_t ValTypeId)
{
	SeriesBase *elem = SeriesBase::newSeries((enum SeriesBase::E_ValType)ValTypeId);
	m_Data.push_back(elem);
	return elem;
}*/
SeriesBase *LineDataSet::addSeries(int32_t ValTypeId ,int32_t Num)
{
	int32_t i;
	SeriesBase *elem=NULL;
		
	for(i=0;i<Num;i++){
		elem = SeriesBase::newSeries((enum SeriesBase::E_ValType)ValTypeId);
		m_Data.push_back(elem);
	}

	return elem;
}

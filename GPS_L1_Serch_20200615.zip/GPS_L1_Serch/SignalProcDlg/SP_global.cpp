// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// SP_Global.cpp
//
//
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

#include "stdafx.h"

#include <vector>

#include "GnrlDefine.h"
#include "GnrlCharset.h"

//--#include "Random.h"
//--#include "SP_define.h"


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
LineDataSet				gGraphTest01;
GLThread				gGLThread;

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �ʐM�֘A
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
LineDataSet				gGraphCsv;
//GnrlCom					gCom;
//ComRecvThread			gComRecvThread;

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �v���Z�X�֘A�f�[�^
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
st_CsvParam					gCsvParam;


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// PurposeName�ƈ�v���镶����� NameList[]�̒�����T���܂��B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t findStringListId(const char *PurposeName ,const char *NameList[] ,bool case_sensitive)
{
	int32_t itr = 0;
	std::size_t	purname_size = rapidxml::internal::measure(PurposeName);
	std::size_t	listname_size;

	while(*NameList){
		listname_size	= rapidxml::internal::measure(*NameList);
		if(rapidxml::internal::compare(*NameList, listname_size, PurposeName, purname_size, case_sensitive)){
			return itr;
		}

		NameList++;
		itr++;
	}

	return -1;
}


// **********************************************************************
// COM ����̃f�[�^��҂��󂯂�X���b�h
//
// ComRecvThread.cpp
// 
// 2013/06/31  Createed
// 2019/12/22  J�C��
// **********************************************************************

#include "stdafx.h"

#include "GnrlDefine.h"
#include "GnrlThread.h"

#include "ComRecvThread.h"


ComRecvThread::ComRecvThread()
: m_Wnd(NULL)
{};

void ComRecvThread::setWnd(CWnd *Wnd)
{
	m_Wnd = Wnd;
}

// Com��M���[�`��
int32_t ComRecvThread::run()
{


	return 0;
}


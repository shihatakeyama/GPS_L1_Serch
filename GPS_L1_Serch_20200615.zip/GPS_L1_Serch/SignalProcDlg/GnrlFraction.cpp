// *********************************************************************************
//  
//  GnrlFraction.cpp
//  
//  �����̒l�A����ьv�Z���\�b�h��ێ�����N���X�B�v�Z���\�b�h�𗘗p����Ǝ��M�̕����̒l�����������B
//  (�����̒l�͏��������܂���)
//  
//  2014/12/27  Createed
//  2019/12/27  
// *********************************************************************************

#include "stdafx.h"

#include "GnrlFraction.h"



RstrFraction::RstrFraction()
:Numerator(0), Denominator(1)
{}

RstrFraction::RstrFraction(int32_t Denominator_arg)
: Numerator(0), Denominator(Denominator_arg)
{}

RstrFraction::RstrFraction(int32_t Numerator_arg, int32_t Denominator_arg)
: Numerator(Numerator_arg), Denominator(Denominator_arg)
{}

RstrFraction::RstrFraction(const RstrFraction &Arg)
: Numerator(Arg.Numerator), Denominator(Arg.Denominator)
{}

RstrFraction::~RstrFraction()
{}

void RstrFraction::clear()
{
	Numerator = 0;
	Denominator = 1;
}

const RstrFraction &RstrFraction::operator=(const RstrFraction &Arg)
{
	Numerator = Arg.Numerator;
	Denominator = Arg.Denominator;

	return *this;
}

RstrFraction RstrFraction::operator *(int32_t Arg) const
{
	RstrFraction ret(Numerator * Arg, Denominator);

	ret.reduction();

	return ret;
}
RstrFraction RstrFraction::operator /(int32_t Arg) const
{
	RstrFraction ret(Numerator, Denominator * Arg);

	ret.reduction();

	return ret;
}

#if 0
Sint16 RstrFraction::operator *(Sint16 Arg) const
{
	return ((int32_t)Arg * Numerator) / Denominator;
}
int8_t RstrFraction::operator *(int8_t Arg) const
{
	return ((int32_t)Arg * Numerator) / Denominator;
}
Float32 RstrFraction::operator * (Float32 Arg) const
{
	return Arg * Numerator / Denominator;
}

const RstrFraction &RstrFraction::operator ++()
{
	Numerator++;

	return *this;
}

const RstrFraction &RstrFraction::operator --()
{
	Numerator--;

	return *this;
}
#endif
// *********************************************************************************
// �񕪂��s��
// *********************************************************************************
void RstrFraction::reduction() {
	int32_t gcdi0 = gcdi(Numerator, Denominator);
	Numerator = Numerator / gcdi0;
	Denominator = Denominator / gcdi0;
}

// *********************************************************************************
// �ő���񐔂����߂�
// *********************************************************************************
int32_t RstrFraction::gcdi(int32_t a, int32_t b) const {
	while (b > 0) {
		int32_t c = a;
		a = b;
		b = c % b;
	}
	return a;
}




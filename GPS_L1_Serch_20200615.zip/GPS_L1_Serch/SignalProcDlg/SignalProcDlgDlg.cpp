﻿// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//
// SignalProcDlgDlg.cpp : 実装ファイル
//
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

#include "stdafx.h"

#include <stdint.h>
#include "afxdialogex.h"
#include "SignalProcDlg.h"
#include "CudaInfoDlg.h"
#include "ComboInListCtrl.h"
#include "ListCtrlComFormat.h"
#include "ComFormatSetDlg.h"

#include "GnrlDefine.h"
#include "GnrlCharset.h"
#include "GnrlFilePath.h"

#include "SignalProcDlgDlg.h"

#include "SP_Define.h"

#include "L1CaCode.h"
#include "GTS_Global.h"


CComFormatDlg gComFormatDlg;

using namespace Gdiplus;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


int32_t saveCsvSet(st_CsvParam &CsvParam);
int32_t loadCsvSet(st_CsvParam &CsvParam);
static BOOL WritePrivateProfileInt(const LPCTSTR lpAppName, const LPCTSTR lpKeyName, int Val, const LPCTSTR lpFileName);

int32_t GTS_CorrTest(LineDataSet &Lds);
int32_t GTS_FFT_Test(LineDataSet &Lds);
void L1makeCaCodelist();


// アプリケーションのバージョン情報に使われる CAboutDlg ダイアログ

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// ダイアログ データ
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV サポート

// 実装
protected:
	DECLARE_MESSAGE_MAP()
public:
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
//	ON_WM_MOUSEMOVE()
//	ON_WM_KILLFOCUS()
END_MESSAGE_MAP()


CSignalProcDlgDlg::CSignalProcDlgDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CSignalProcDlgDlg::IDD, pParent)
	, m_hIcon(AfxGetApp()->LoadIcon(IDR_MAINFRAME))
	, m_DataStartLine(1)
	, m_Graph()
	, m_DataDirection(0)
	, mCaptureMode(FALSE)
	, m_InputFreq(1000)
	, m_CodeStepN(2048)
	, m_StatiBegin(-100)
{
//	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSignalProcDlgDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);

	DDX_Control(pDX, IDC_LIST2, m_listctrl);
	DDX_Text(pDX, IDC_EDIT_CODE_STEP_N, m_CodeStepN);
	DDV_MinMaxInt(pDX, m_StatiBegin, -1000000, 1000000);

}

BEGIN_MESSAGE_MAP(CSignalProcDlgDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_CHECK1, &CSignalProcDlgDlg::OnBnClickedCheck1)
	ON_BN_CLICKED(IDC_BUTTON_GEN, &CSignalProcDlgDlg::OnBnClickedButtonGen)
	ON_BN_CLICKED(IDC_BUTTON_CUDA_INFO, &CSignalProcDlgDlg::OnBnClickedButtonCudaInfo)
	ON_WM_DROPFILES()
	ON_BN_CLICKED(IDC_BUTTON2, &CSignalProcDlgDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDOK, &CSignalProcDlgDlg::OnBnClickedOk)
	ON_WM_LBUTTONDOWN()

	// 独自のメッセージ送信 追加
	ON_MESSAGE(WM_COM_RECV_DATA, OnRecvCom)

	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_DESTROY()
	ON_WM_SIZE()

	// 各種設定ダイアログ
	ON_COMMAND(ID_COM_FORMAT,			&CSignalProcDlgDlg::OnComFormatDlg)

	ON_BN_CLICKED(IDC_BUTTON_PROC_LIST_OPEN, &CSignalProcDlgDlg::OnBnClickedButtonProcListOpen)
	ON_BN_CLICKED(IDC_BUTTON_PROC_LIST_SAVE, &CSignalProcDlgDlg::OnBnClickedButtonProcListSave)
	ON_BN_CLICKED(IDC_BUTTON_GL, &CSignalProcDlgDlg::OnBnClickedButtonGl)
	ON_BN_CLICKED(IDC_EDIT_IFDUMP_FILEPATH, &CSignalProcDlgDlg::OnEnChangeEditIfdumpFilepath)	// ON_EN_CHANGE


END_MESSAGE_MAP()


// CSignalProcDlgDlg メッセージ ハンドラー

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// ステータスバー
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
static UINT indicators[] =
{
	ID_SEPARATOR,           // ステータス ライン インジケータ
	ID_INDICATOR_KANA,
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
	ID_INDICATOR_ORG,	//Stringリソースで作成したID
};
void setStatusBar(CSignalProcDlgDlg &Window)
{
	int nHeight = 19;
	CRect rectClient;
	// ステータスバー

	int nStatusHeight = 0;
	if (Window.m_StatusBar.GetSafeHwnd()){// コントロールの有効性をチェックします。

		CRect rectSt;
		Window.m_StatusBar.GetWindowRect(rectSt);
		// 現在のクライアントウィンドウのサイズを取得
		Window.GetClientRect(&rectClient);
		// 高さを維持しながらサイズを変更する
		int nBtm = nHeight;	//	rectSt.bottom - rectSt.top;
		rectSt.top = rectClient.bottom - nBtm;
		rectSt.bottom = rectSt.top + nBtm;
		rectSt.left = rectClient.left;
		rectSt.right = rectClient.right;
		Window.m_StatusBar.MoveWindow(rectSt);
		nStatusHeight = rectSt.Height();
	}
}

BOOL CSignalProcDlgDlg::OnInitDialog()
{
	int	i;

	CDialogEx::OnInitDialog();

	// IDM_ABOUTBOX は、システム コマンドの範囲内になければなりません。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// このダイアログのアイコンを設定します。アプリケーションのメイン ウィンドウがダイアログでない場合、
	//  Framework は、この設定を自動的に行います。
	SetIcon(m_hIcon, TRUE);			// 大きいアイコンの設定
	SetIcon(m_hIcon, FALSE);		// 小さいアイコンの設定

	m_Graph.initDlgItem(this, IDC_STCHARTCONTAINER1);

	// **** ステータスバー ****
	// ステータスバーを作成・付加
	m_StatusBar.Create(this);
	m_StatusBar.SetIndicators(indicators, sizeof(indicators) / sizeof(UINT));

	setStatusBar(*this);

	loadDlgSet();
	loadCsvSet(gCsvParam);

	GTS_CorrTest(m_Graph.dataSet());	//	LineDataSet


	matchGraph();		// 縮尺合わせ

#if 0	// 初期表示
	// リストコントロール 処理
	m_imglstList.Create(IDB_BITMAP_LIST, 20, 1, (COLORREF)(0x00000000));
	m_listctrl.SetImageList(&m_imglstList, LVSIL_SMALL);
	m_listctrl.InsertColumn(0, _T("Process"), LVCFMT_LEFT, 100);
	m_listctrl.InsertColumn(1, _T("InSignal"), LVCFMT_LEFT, 100);
	m_listctrl.InsertColumn(2, _T("OutSignal"), LVCFMT_LEFT, 100);
	m_listctrl.InsertColumn(3, _T("Info"), LVCFMT_LEFT, 250);
	m_listctrl.SetExtendedStyle( LVS_ICON | LVS_SHOWSELALWAYS | LVS_OWNERDATA | LVS_EX_HEADERDRAGDROP | LVS_EX_GRIDLINES);	// 追加！！ LVS_OWNERDATAを指定おかないとSetItemText()でエラーになる。
	for (int i = 0; i < 10; i++){
		CString strText;
		for (int j = 0; j < 3; j++){
			strText.Format(_T("Data[%d,%d]"), i + 1, j + 1);
			if (j == 0)
				m_listctrl.InsertItem(i, strText);
			else
				m_listctrl.SetItemText(i, j, strText);
		}
		m_listctrl.SetItem(i, 0, LVIF_IMAGE, NULL, i % 2, 0, 0, 0);	//
	}
#endif

	return TRUE;  // フォーカスをコントロールに設定した場合を除き、TRUE を返します。
}


void CSignalProcDlgDlg::OnDestroy()
{
	CDialogEx::OnDestroy();

	saveDlgSet();

}

void CSignalProcDlgDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}else{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// ダイアログに最小化ボタンを追加する場合、アイコンを描画するための
//  下のコードが必要です。ドキュメント/ビュー モデルを使う MFC アプリケーションの場合、
//  これは、Framework によって自動的に設定されます。
void CSignalProcDlgDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 描画のデバイス コンテキスト

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// クライアントの四角形領域内の中央
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// アイコンの描画
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}

	drawGraph();
}

// ユーザーが最小化したウィンドウをドラッグしているときに表示するカーソルを取得するために、
//  システムがこの関数を呼び出します。
HCURSOR CSignalProcDlgDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CSignalProcDlgDlg::OnBnClickedCheck1()
{
	// TODO: ここにコントロール通知ハンドラー コードを追加します。
}

// **********************************************************************
//  OK押された
// **********************************************************************
void CSignalProcDlgDlg::OnBnClickedOk()
{
	saveCsvSet(gCsvParam);

	if(::GetFocus() == ::GetDlgItem(m_hWnd ,IDOK)){
		CDialogEx::OnOK();	// Enterで閉じさせない。
	}
}

static BOOL WritePrivateProfileInt(const LPCTSTR lpAppName, const LPCTSTR lpKeyName, int Val, const LPCTSTR lpFileName)
{
	Nchar	str[32];

	Nswprintf_s(str,32 , N_T("%d"), Val);

	return ::WritePrivateProfileString(lpAppName, lpKeyName, str, lpFileName);
}

// **********************************************************************
//  CSVファイルの設定を読み込む
// **********************************************************************
int32_t CSignalProcDlgDlg::saveDlgSet()
{
	Nchar	filename[MAX_PATH];
	Nchar	sectionbuf[256];
	int32_t	ack;

	ack = GnrlFilepath::getModuleAttachmentFilePath(filename, MAX_PATH ,N_T("SignalProc.ini"));
	if(ack <= 0){
		return -3;
	}

	UpdateData(TRUE);

	return 0;
}

int32_t saveCsvSet(st_CsvParam &CsvParam)
{
	Nchar	filename[MAX_PATH];
	Nchar	sectionbuf[256];
	Nchar	tmp[256];
	int32_t	i;
	int32_t	ack;

	ack = GnrlFilepath::getModuleAttachmentFilePath(filename, MAX_PATH ,N_T("CsvParam.ini"));
	if(ack <= 0){
		return -3;
	}
	Nstrcpy_s(sectionbuf ,256 ,N_T("common"));

	WritePrivateProfileInt(sectionbuf, N_T("DataDirection")	, CsvParam.DataDirection, filename);
	WritePrivateProfileInt(sectionbuf, N_T("StartLine")		, CsvParam.StartLine	, filename);
	WritePrivateProfileInt(sectionbuf, N_T("OutputPoint")		, CsvParam.OutputPoint	, filename);

	WritePrivateProfileInt(sectionbuf, N_T("SeparateChar")	, CsvParam.getSeparateChar(), filename);
	WritePrivateProfileInt(sectionbuf, N_T("Length")		, CsvParam.Size			, filename);

	for(i=0;i<MAX_CSV_ELEM;i++){
		
		Nsprintf(sectionbuf ,N_T("series%02d") ,i);

		WritePrivateProfileInt(sectionbuf, N_T("Enable"), CsvParam.Enable[i]			, filename);
		WritePrivateProfileInt(sectionbuf, N_T("SeparatePos"), CsvParam.SeparatePos[i]	, filename);
		WritePrivateProfileInt(sectionbuf, N_T("NumEncType"), CsvParam.NumEncType[i]	, filename);
	}
	return 0;
}
int32_t CSignalProcDlgDlg::loadDlgSet()
{
	Nchar	filename[MAX_PATH];
	Nchar	sectionbuf[256];
	int32_t	ack;

	ack = GnrlFilepath::getModuleAttachmentFilePath(filename, MAX_PATH ,N_T("SignalProc.ini"));
	if(ack <= 0){
		return -3;
	}

//	m_ChkInput = ::GetPrivateProfileInt(sectionbuf, N_T("ChkInput")	,0 ,filename);
//	m_ChkOutput = ::GetPrivateProfileInt(sectionbuf, N_T("ChkOutput")	,0 ,filename);

	UpdateData(FALSE);

	return 0;
}

int32_t loadCsvSet(st_CsvParam &CsvParam)
{
	Nchar	filename[MAX_PATH];
	Nchar	sectionbuf[256];
	int32_t	i;
	int32_t	ack;

	memset(&CsvParam ,0 ,sizeof(CsvParam));

	ack = GnrlFilepath::getModuleAttachmentFilePath(filename, MAX_PATH ,N_T("CsvParam.ini"));
	if(ack <= 0){
		return -3;
	}

	Nstrcpy_s(sectionbuf ,256 ,N_T("common"));

	CsvParam.DataDirection	= ::GetPrivateProfileInt(sectionbuf, N_T("DataDirection")	,0 ,filename);
	CsvParam.StartLine		= ::GetPrivateProfileInt(sectionbuf, N_T("StartLine")		,1 ,filename);
	CsvParam.OutputPoint	= ::GetPrivateProfileInt(sectionbuf, N_T("OutputPoint")		,256, filename);
	CsvParam.setSeparateChar(::GetPrivateProfileInt(sectionbuf , N_T("SeparateChar")	,1 ,filename));
	CsvParam.Size			= ::GetPrivateProfileInt(sectionbuf, N_T("Length")			,0 ,filename);	// エレメント個数

	for(i=0;i<MAX_CSV_ELEM;i++){

		Nsprintf(sectionbuf ,N_T("series%02d") ,i);

		CsvParam.Enable[i]		= ::GetPrivateProfileInt(sectionbuf, N_T("Enable")		, 0, filename);
		CsvParam.SeparatePos[i] = ::GetPrivateProfileInt(sectionbuf, N_T("SeparatePos")	, 1, filename);
		CsvParam.NumEncType[i]	= ::GetPrivateProfileInt(sectionbuf, N_T("NumEncType")	, 0, filename);
	}

	return 0;
}
#if 0
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// GUIの取得と表示行う
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t CSignalProcDlgDlg::getGuiCsvSet(st_CsvParam &CsvParam)
{
	UpdateData(TRUE);

	CsvParam.DataDirection	= m_DataDirection;
	CsvParam.StartLine		= max(1 ,m_DataStartLine)-1;
	CsvParam.OutputPoint	= max(1, m_CodeStepN) - 1;
	CsvParam.setSeparateChar(m_Separator);
	CsvParam.Size			= 2;

	CsvParam.Enable[0]		= m_Use1;
	CsvParam.Enable[1]		= m_Use2;

	CsvParam.SeparatePos[0] = max(1 ,m_Segm1)-1;
	CsvParam.SeparatePos[1] = max(1 ,m_Segm2)-1;

	CsvParam.NumEncType[0]	= m_Dec1;
	CsvParam.NumEncType[1]	= m_Dec2;

	return 0;
}
int32_t CSignalProcDlgDlg::setGuiCsvSet(const st_CsvParam &CsvParam)
{
	m_DataDirection		= CsvParam.DataDirection;
	m_DataStartLine		= CsvParam.StartLine+1;
	m_CodeStepN		= CsvParam.OutputPoint + 1;
	m_Separator			= CsvParam.getSeparateChar();

	m_Use1				= CsvParam.Enable[0];
	m_Use2				= CsvParam.Enable[1];

	m_Segm1				= CsvParam.SeparatePos[0]+1;
	m_Segm2				= CsvParam.SeparatePos[1]+1;

	m_Dec1				= CsvParam.NumEncType[0];
	m_Dec2				= CsvParam.NumEncType[1];

	UpdateData(FALSE);

	return 0;
}
#endif

// **********************************************************************
//  グラフを描画する。(一面)
// **********************************************************************
void CSignalProcDlgDlg::drawGraph()
{
#if 0
	SeriesBase *ser = gGraphCsv.getElement(0);

	if(ser){
//--		m_Graph.drawLine(*ser);
	}else{
		m_Graph.drawGrid();
	}
#else
	m_Graph.onPaint();
#endif
}

int CSignalProcDlgDlg::matchGraph()
{
	SeriesBase *entry = gGraphCsv.getElement(0);

	if (entry){
		m_Graph.setViewAreaX(0.0f, m_CodeStepN);
		m_Graph.setViewAreaY();
		m_Graph.autoXGridSpacing();
		m_Graph.autoYGridSpacing();
	}

	return 0;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// 他スレッドからデータ受けた場合
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
LRESULT CSignalProcDlgDlg::OnRecvCom(WPARAM wParam, LPARAM lParam)
{
	static int32_t mabiki_co = 0;
	int32_t	SeriesLen;

	return 0; // メッセージ固有の戻り値を返す
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  ダイアログにファイルをD&Dされたときのハンドラー
//  ダイアログのAccept FilesをTrueに設定
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void CSignalProcDlgDlg::OnDropFiles(HDROP hDropInfo)
{
    //ドロップされたファイルの個数を取得
    //DragQueryFile の詳細についてはmsdn参照
    //第2引数に -1 を指定すると、DragQueryFile はドロップされたファイルの総数を返します
    //unsigned int型の 0 を反転させると -1(0xFFFFFFFF) です
    UINT iCnt = DragQueryFile(hDropInfo, ~0u, NULL, 0);

    for (UINT i = 0; i<iCnt; i++)
    {
        //ファイル名の長さを取得
        //第3引数にNULLを指定すると、DragQueryFile は必要なバッファのサイズを文字単位で返します
        UINT iLen = DragQueryFile(hDropInfo, i, NULL, 0);
        //ファイル名を取得
        //第2引数に0～ドロップされたファイルの総数未満のいずれかの値を指定すると、その値に対応するファイル（フォルダ）名を格納します
        CString csfile;
        DragQueryFile(hDropInfo, i, csfile.GetBuffer(iLen + 1), iLen + 1);
        csfile.ReleaseBuffer();

        //ファイル（フォルダ）名を保持
		AfxMessageBox(csfile);
        //エディットボックスにパスを表示
        //複数ファイルドロップした場合は結果として最後に処理したパスが表示される）
    }

	CDialogEx::OnDropFiles(hDropInfo);
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  信号生成ボタン押された
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void CSignalProcDlgDlg::OnBnClickedButtonGen()
{
}

void CSignalProcDlgDlg::OnBnClickedButtonCudaInfo()
{
	CCudaInfoDlg dlg;

	dlg.DoModal();
}

void CSignalProcDlgDlg::OnBnClickedButton2()
{
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  マウスボタンの操作
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void CSignalProcDlgDlg::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: ここにメッセージ ハンドラー コードを追加するか、既定の処理を呼び出します。
	// マウスのダイアログのクライアント座標をスクリーン座標に変換します。
	ClientToScreen(&point);

	CDialogEx::OnLButtonDown(nFlags, point);
}

void CSignalProcDlgDlg::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: ここにメッセージ ハンドラー コードを追加するか、既定の処理を呼び出します。
	CDialogEx::OnMouseMove(nFlags, point);
}

BOOL CSignalProcDlgDlg::PreTranslateMessage(MSG* pMsg)
{
	int		ack;
	CWnd*	pWnd = WindowFromPoint(pMsg->pt);

	ack = m_Graph.PreTranslateMessageSol(*this, pMsg);

	return CDialogEx::PreTranslateMessage(pMsg);
}

void CSignalProcDlgDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialogEx::OnSize(nType, cx, cy);

	setStatusBar(*this);
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// ComFormat 設定ダイアログ
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void CSignalProcDlgDlg::OnComFormatDlg()
{
	gComFormatDlg.m_CsvParam	= gCsvParam;

	if(gComFormatDlg.DoModal() == IDOK){
		gCsvParam = gComFormatDlg.m_CsvParam;
	}
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// プロセスファイルをロード/セーブ
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void CSignalProcDlgDlg::OnBnClickedButtonProcListOpen()
{
	CFileDialog dlgFile(TRUE);
	OPENFILENAME &ofn = dlgFile.GetOFN();
	ofn.lpstrTitle = _T("処理ファイルのを開く");
	ofn.lpstrFilter = _T("All Files\0*.*\0Process Files\0*.prc\0Log Files\0*.log\0");
	ofn.Flags |= OFN_SHOWHELP;

	if(dlgFile.DoModal()==IDOK){
		try{
#if 0
			loadProcessParam(gProcessList ,N_T("D:\\tmp\\Proc_Param.txt"));
#else
///--			loadProcessParam(gProcessList ,dlgFile.GetPathName());
#endif
		}catch(std::exception e){
			MessageBox(CString(e.what()));
			return;
		}

//		m_listctrl.setGui(gProcessList);
	}

}
void CSignalProcDlgDlg::OnBnClickedButtonProcListSave()
{
	CFileDialog dlgFile(FALSE);
	OPENFILENAME &ofn = dlgFile.GetOFN();
	ofn.lpstrTitle = _T("処理ファイルを保存");
	ofn.lpstrFilter = _T("All Files\0*.*\0Process Files\0*.prc\0Log Files\0*.log\0");
	ofn.Flags |= OFN_SHOWHELP; 

	if(dlgFile.DoModal()==IDOK){
		try{
#if 0
			saveProcessParam(gProcessList ,N_T("D:\\tmp\\Proc_Param.txt"));
#else
//--			saveProcessParam(gProcessList ,dlgFile.GetPathName());
#endif
//			saveProcessParam(gProcessList ,N_T("D:\\tmp\\Proc_ParamW.txt"));
		}catch(std::exception e){
			MessageBox(CString(e.what()));
			return;
		}
	}
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Open GL ボタンクリック
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void CSignalProcDlgDlg::OnBnClickedButtonGl()
{
	gGLThread.start();
}



void CSignalProcDlgDlg::OnEnChangeEditIfdumpFilepath()
{
	// TODO: これが RICHEDIT コントロールの場合、このコントロールが
	// この通知を送信するには、CDialogEx::OnInitDialog() 関数をオーバーライドし、
	// CRichEditCtrl().SetEventMask() を
	// OR 状態の ENM_CHANGE フラグをマスクに入れて呼び出す必要があります。

	// TODO: ここにコントロール通知ハンドラー コードを追加してください。
}

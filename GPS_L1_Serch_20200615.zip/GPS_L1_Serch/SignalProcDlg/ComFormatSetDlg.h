// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// ComFormatDlg.h �_�C�A���O
//
//
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

#pragma 

//--#include "ComboInListCtrl.h"
//--#include "ListCtrlComFormat.h"


class st_CsvParam;

class CComFormatDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CComFormatDlg)

public:
	CComFormatDlg(CWnd* pParent = NULL);   // �W���R���X�g���N�^�[
	virtual ~CComFormatDlg();

// �_�C�A���O �f�[�^
	enum { IDD = IDD_COM_FORMAT_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �T�|�[�g

	DECLARE_MESSAGE_MAP()

	CImageList			m_imglstList;

public:
	afx_msg void OnBnClickedOk();
	virtual BOOL OnInitDialog();

	int32_t getGuiCsvSet(st_CsvParam &CsvParam);
	int32_t setGuiCsvSet(const st_CsvParam &CsvParam);
	void showRecvData(const CString &RecvLine);
	LineDataSet m_DataSet;

	st_CsvParam			m_CsvParam;

	CListCtrlComFormat m_listctrl;

	afx_msg void OnBnClickedButton1();
	afx_msg void OnDestroy();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	int m_DataStartLine;
	BOOL m_Separator;
};

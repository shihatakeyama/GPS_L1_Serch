// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// ComFormatSet.cpp
//
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

#include "stdafx.h"

#include "ComboInListCtrl.h"
#include "ListCtrlComFormat.h"


#include "ComFormatSetDlg.h"
#include "afxdialogex.h"


// CComFormatDlg �_�C�A���O

IMPLEMENT_DYNAMIC(CComFormatDlg, CDialogEx)

CComFormatDlg::CComFormatDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CComFormatDlg::IDD, pParent)
	, m_DataStartLine(0)
	, m_Separator(FALSE)
{
}

CComFormatDlg::~CComFormatDlg()
{
}

void CComFormatDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_COM_FORMAT, m_listctrl);
	DDX_Text(pDX, IDC_EDIT_DATA_START_LINE, m_DataStartLine);
	DDX_Radio(pDX, IDC_RADIO_TAB, m_Separator);
}


BEGIN_MESSAGE_MAP(CComFormatDlg, CDialogEx)
	ON_BN_CLICKED(IDOK, &CComFormatDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDC_BUTTON1, &CComFormatDlg::OnBnClickedButton1)
	ON_WM_DESTROY()
END_MESSAGE_MAP()


BOOL CComFormatDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// �A�C�R������
//--	m_imglstList.Create(IDB_BITMAP_LIST, 20, 1, (COLORREF)(0x00000000));
	InitCommonControls();


 //   HWND hList = m_listctrl.m_hWnd;//GetDlgItem(IDC_LIST_COM_FORMAT)->m_hWnd;

	// �J�����Z�b�g
//--	m_listctrl.SetImageList(&m_imglstList, LVSIL_SMALL);
	m_listctrl.InsertColumn(0, _T("Ch"), LVCFMT_LEFT, 60);
	m_listctrl.InsertColumn(1, _T("Segment"), LVCFMT_LEFT, 80);
	m_listctrl.InsertColumn(2, _T("Type"), LVCFMT_LEFT, 80);
	m_listctrl.InsertColumn(3, _T("Signal"), LVCFMT_LEFT, 100);
	m_listctrl.InsertColumn(4, _T("Conv Data"),LVCFMT_LEFT, 80);
	m_listctrl.SetExtendedStyle( LVS_EX_CHECKBOXES |  LVS_OWNERDATA );	// �ǉ��I�I LVS_OWNERDATA���w�肨���Ȃ���SetItemText()�ŃG���[�ɂȂ�B		// LVS_ICON
	// ListView_GetExtendedListViewStyle()��				// LVS_SHOWSELALWAYS | LVS_EX_FULLROWSELECT |  | LVS_EX_GRIDLINES | LVS_EX_HEADERDRAGDROP
	// ListView_SetExtendedListViewStyle(hList, dwStyle);

#if 0
	for (int i = 0; i < 8; i++){
		CString strText;

		strText.Format(_T("CH%d"), i);
		m_listctrl.InsertItem(i, strText);

		strText.Format(_T("Segment"));
		m_listctrl.SetItemText(i, 1 ,strText);

		strText.Format(_T("Type"), i);
		m_listctrl.SetItemText(i, 2 ,strText);

		strText.Format(_T("INPUT_%d"), i);
		m_listctrl.SetItemText(i, 3 ,strText);

	//--	m_listctrl.SetItem(i, 0, 0, 0, i & 0x01, 0, 0, 0);	//
	}
#endif

	setGuiCsvSet(m_CsvParam);

	return TRUE;  // return TRUE unless you set the focus to a control
	// ��O : OCX �v���p�e�B �y�[�W�͕K�� FALSE ��Ԃ��܂��B
}
void CComFormatDlg::OnDestroy()
{
	CDialogEx::OnDestroy();

	getGuiCsvSet(m_CsvParam);
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// PreTranslateMessage()
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
BOOL CComFormatDlg::PreTranslateMessage(MSG* pMsg)
{

	switch (pMsg->message){
		case WM_KEYDOWN:
			switch( pMsg->wParam )
			{
				case VK_RETURN:
					if(::GetFocus() == ::GetDlgItem(m_hWnd ,IDOK)){
//--						return FALSE;	// Enter,Escape�ŃE�C���h�E�������Ȃ�

					}
//--					m_listctrl.SetItemState(0 , LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED);

//					m_listctrl.m_Edit.OnKillFocus(this);
					break;
				case VK_ESCAPE:
					return FALSE;
				default:
					break;
			}
			break;

		case WM_COMMAND:
	
		if (pMsg->wParam == EN_SETFOCUS){	//
			int aa = 1;
		}else if (pMsg->wParam == EN_KILLFOCUS){
			int aa = 1;
		}else if(pMsg->wParam == 1756){
			int aa = 1;
		}

		break;
	}

	return CDialogEx::PreTranslateMessage(pMsg);
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// GUI�̎擾�ƕ\���s��
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t CComFormatDlg::getGuiCsvSet(st_CsvParam &CsvParam)
{
	int32_t i,end = m_listctrl.GetItemCount();
	int32_t ival;
	int32_t index;

	UpdateData(TRUE);

	CsvParam.StartLine = m_DataStartLine;
	CsvParam.setSeparateChar(m_Separator);
	CsvParam.Size	= end;

	for (i = 0; i < end; i++){
		CString str;

		// �`�F�b�N
		CsvParam.Enable[i] = m_listctrl.GetCheck(i);

		// �Z�O�����gNo.
		str = m_listctrl.GetItemText(i, 1);
		ival = _ttoi(str);			// CString��int�ϊ�
		ival--;
		if(ival < 0)	ival = 0;
		CsvParam.SeparatePos[i] = ival;
		
		// ���l�^�C�v
		str = m_listctrl.GetItemText(i, 2);
		ival = findStringListId(str ,g_ValTypeList);
		CsvParam.NumEncType[i] = ival;

	}

	return 0;
}
int32_t CComFormatDlg::setGuiCsvSet(const st_CsvParam &CsvParam)
{
	int32_t tmp;
	int32_t i;

	m_listctrl.RemoveAllGroups();

	for (i = 0; i < MAX_CSV_ELEM; i++){	// CsvParam.Size
		CString strText;

		strText.Format(_T("CH%d"), i);
		m_listctrl.InsertItem(i, strText);

		m_listctrl.SetCheck(i ,CsvParam.Enable[i]);

		strText.Format(_T("%d") ,CsvParam.SeparatePos[i]+1);
		m_listctrl.SetItemText(i, 1 ,strText);

		tmp = CsvParam.NumEncType[i];
		if(tmp<0 || tmp>=3)	tmp = 0;
		m_listctrl.SetItemText(i, 2 ,g_ValTypeList[tmp]);

		strText.Format(_T("INPUT_%d"), i);
		m_listctrl.SetItemText(i, 3 ,strText);

	}

	m_DataStartLine = CsvParam.StartLine;
	m_Separator = CsvParam.getSeparateChar();

	UpdateData(FALSE);

	return 0;
}

void CComFormatDlg::showRecvData(const CString &RecvLine)
{

	m_DataSet.clear();

	getGuiCsvSet(m_CsvParam);

	insertCsv(m_DataSet ,RecvLine, m_CsvParam);

	int32_t tmp;
	int32_t i,end,co=0;

	m_listctrl.RemoveAllGroups();

	end = m_listctrl.GetItemCount();
	for (i = 0; i < end; i++){	// CsvParam.Size
		CString str;

		if(m_CsvParam.Enable[i]){
			if(co < m_DataSet.size()){
				str = m_DataSet[co].toString(0);
//--				m_listctrl.SetItemText(i, 4 ,str);

				co++;
			}
		}
		m_listctrl.SetItemText(i, 4 ,str);
	}

}

void CComFormatDlg::OnBnClickedOk()
{

	if(::GetFocus() == ::GetDlgItem(m_hWnd ,IDOK)){
		CDialogEx::OnOK();
	}
}


void CComFormatDlg::OnBnClickedButton1()
{
//	::SetFocus(m_listctrl.m_hWnd);
//	this->
	//	::SendMessage(m_hWnd ,WM_COMMAND ,EN_KILLFOCUS ,0);
//	SendMessage(WM_COMMAND,1756 , 1756);		//MAKEWPARAM(0, BN_CLICKED)
//	showRecvData(); 
}


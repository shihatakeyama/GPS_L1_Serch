// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// ListCtrlComFormat.h
//
// List Control COM Format
//
//
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

#pragma once


class CComboInListCtrl;


class CListCtrlComFormat 
: public CListCtrl
{
	DECLARE_DYNAMIC(CListCtrlComFormat)

public:
	CListCtrlComFormat();
	virtual ~CListCtrlComFormat();

	enum{
		IDC_EDIT_SUB_ITEM = 1235
	};

protected:
	DECLARE_MESSAGE_MAP()
public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnNMDblclk(NMHDR *pNMHDR, LRESULT *pResult);

	CEditInListCtrl			m_Edit;		// �Z���ҏW �Z�O�����g�ʒu
	CComboInListCtrl		m_Combo;	// �Z���ҏW ���l�^�C�v
	int m_StatiN;

	void BeginEdit(int iItem, int iSubItem);
	void BeginCombo(int iItem, int iSubItem);

	afx_msg void OnNMClick(NMHDR *pNMHDR, LRESULT *pResult);
	virtual void DoDataExchange(CDataExchange* pDX);
};



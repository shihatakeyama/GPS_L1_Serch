// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// numpy.h
// 
// TAP�v�Z�̈��p �F http://www7b.biglobe.ne.jp/~dfd_house/
//
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *


//#include "stdafx.h"


namespace numpy{

	// ��
	const Float64 m2pi				= M_PI * 2;
	const Float64 m4pi				= M_PI * 4;
	// 0�ɋ߂�
	const Float64 mLimit0			= 0.00001;

	// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	// ���[�p�X�^�b�v
	// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	//**	LPF�v�Z���F
	//**  1) �d�l�F�J�b�g�I�t���g�� fc = 2.0Hz
	//**  2) �\���F���ԕ�   t=-1.0�b ���� +1.0�b�܂�
	//**         �i���_���-������+���܂ő����܂����j
	//**  3) �v�Z���FTd = 0.025�b���݁BM =1.0/0.025=40 
	//**  4) �v�Z���F x(n) = 2*PI()*fc*n*Td, 
	//**              y(n) = sin(x(n))/x(n),      n = -M ~ +M�@
	//**  5) �\���F�܂���O���t�@
	//**		����=����t�A�c��=��=sin(x)/x
	//		Td = 
	template<typename X>
	int32_t lopassTap00(X *Data, size_t Len ,X Fclk ,X Fc){
		X yn,*fb=Data;
		uint16_t i;
		X hlen = (X)Len / 2;
		//td = 1.0f / hlen;
		X R	= Fc / Fclk;

		X n = -hlen +0.5f;
		for (i=0; i<Len; i++){
			X temp = m2pi * n * R;
			if (fabs(temp) < mLimit0){
				yn = 1.0f;
			}
			else{
				yn = sin(temp) / temp;
			}

			*fb	= yn;
			fb++;
			n++;
		}
		return 0;
	}

	// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	// �o���h�p�X�^�b�v
	// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	//**	BPF�v�Z���F
	//**   1) y(n) = SIN(2*��*n*R)/(2*��*n*R),
	//**   2) w(n) = 0.50 + 0.50*COS(2*��*n/(N-1))�@	// �E�C���h�E
	//**   3) cr(n)= COS( 2*��*r*n ) 
	//**   4) h(n) = y(n)*w(n)*cr(n)
	//**      n  = 0, 1, 2, ...., M

	//**   4) BPF���S���g��      �@fc  =  2.0 MHz
	//**�@�@  BPF�ш敝          �@fb  =  2.0 MHz
	//**      ���g���䗦�@R=  fb/2/fck =  0.10        == ��LPF�݌v�ł̃C���p���X���������߂�䗦
	//**      ���g���䗦�@r=  fc/fck   =  0.20�@�@    == ���g���V�t�g�̃L�����A�[���g���䗦
	template<typename X>
	int32_t bandpassTap00(X *Data, size_t Len, X Fclk, X Fc, X Fb)
	{
		X yn,*fb=Data;
		X R = Fb / 2.0f / Fclk;
		X fcl = Fclk / 2 - Fc;
		X r = Fc / Fclk;
		uint16_t i;
		X hlen = (X)Len / 2;

		X n = -hlen + 0.5f;
		for (i = 0; i < Len; i++){
			X temp = m2pi * n * R;
			if (fabs(temp) < mLimit0){
				yn = 1.0f;
			}
			else{
				yn = sinf(temp) / (temp);		// 1) y(n) = SIN(2*��*n*R)/(2*��*n*R),
			}

			X crn = cosf(m2pi * r * n);

			X hn = yn * crn;

			*fb = hn;
			fb++;
			n++;
		}

		return 0;
	}

	// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	// ���[�p�X�^�b�v
	// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	//**	HPF�v�Z���F
	//**   1) y(n) = SIN(2*��*n*R)/(2*��*n*R),
	//**   2) w(n) = 0.50 + 0.50*COS(2*��*n/(N-1))�@
	//**   3) cr(n)= (-1)^n ; �L�����A�[�g�`�̎�            �}3-2-1 3-1��LPF����̃Q�C���f���g�������i�g���j
	//**   4) h(n) = y(n)*w(n)*cr(n)
	//**      n  = 0, 1, 2, ...., M
	template<typename X>
	int32_t hipassTap00(X *Data, size_t Len, X Fclk, X Fc)	// , X Fb	
	{
		uint16_t i;
		X hlen = (X)Len / 2;
		X n = -hlen + 0.5f;

		X yn,*fb=Data;
		X fcl = Fclk / 2 - Fc;
		X r = fcl / Fclk;

		for (i = 0; i < Len; i++){
			X temp = m2pi * n * r;
			if (fabs(temp) < mLimit0){
				yn = 1.0f;
			}
			else{
				yn = sinf(temp) / (temp);
			}

			X crn = (X)pow(-1, n);

			X hn = yn * crn;

			*fb = hn;
			fb++;
			n++;
		}

		return 0;
	}

	template<typename X>
	int32_t numset(X *Data, uint16_t Len ,X Val)
	{
		uint16_t i;

		for (i = 0; i < Len; i++){
			Data[i]	= Val;
		}

		return 0;
	}

	template<typename X,typename Y>
	int32_t leveladjustment(Y *Out, X *In ,size_t Len ,Y AveVal)
	{
		X *itr;
		X *end = In+Len;
		Y accum = static_cast<Y>(0);
		Y k;

		itr = In;
		while(itr != end){
			accum += fabs(*itr);
			itr++;
		}

		k = accum /	AveVal;
	
		itr = In;
		Y *itrb=Out;
		while(itr != end){
			*itrb = *itr / k;
			itr++;
			itrb++;
		}

		return 0;
	}

	// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	// �n�j���O����
	// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	template<typename X>
	int32_t hanningTap00(X *Data, size_t Len){
		if ((Len < 3) || !(Len & 0x01))	return -1;
		X wn,*fb=Data;
		int32_t i;
		int32_t n;
		int32_t hlen = (int32_t)(Len >> 1);

		n = -hlen +0.5f;
		for (i=0; i < Len; i++){

			wn = 0.50f + 0.50f * cosf((m2pi * n) / (Len-1));

			*fb	= wn;

			fb++;
			n++;
		}

		return 0;
	}
	// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	// Data�Ƀn�j���O���|����
	// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	template<typename X>
	int32_t hanningMulti(X *Data, size_t Len){
		if ((Len < 3) || !(Len & 0x01))	return -1;
		X wn,*fb=Data;
		size_t i;
		int32_t n;
		int32_t hlen = (int32_t)(Len >> 1);

		n = -hlen;// +0.5f;
		for (i=0; i < Len; i++){

			wn = 0.50f + 0.50f * cosf((m2pi * n) / (Len-1));

			*fb	*= wn;

			fb++;
			n++;
		}

		return 0;
	}

	// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	// �n�~���O����
	// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	template<typename X>
	int32_t hamming(X *Data, size_t Len){
		if ((Len < 3) || !(Len & 0x01))	return -1;
		X wn,*fb=Data;
		int32_t i;
		int32_t n;
		int32_t hlen = (int32_t)(Len >> 1);

		n = -hlen;// +0.5f;
		for (i = 0; i < Len; i++){

			wn = 0.54f + 0.46f * cos((m2pi * n) / (Len-1));

			*fb	= wn;

			fb++;
			n++;
		}
		return 0;
	}
	// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	// Data�Ƀn�~���O���|����
	// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	template<typename X>
	int32_t hammingMulti(X *Data, size_t Len){
		if ((Len < 3) || !(Len & 0x01))	return -1;
		X wn,*fb=Data;
		int32_t i;
		int32_t n;
		int32_t hlen = (int32_t)(Len >> 1);

		n = -hlen;
		for (i=0; i<Len; i++){

			wn = static_cast<X>(0.54f + 0.46f * cos((m2pi * n) / (Len-1)));

			*fb	*= wn;

			fb++;
			n++;
		}
		return 0;
	}

	// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	// �u���b�N�}������
	// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	template<typename X>
	int32_t blackman(X *Data, size_t Len){
		if ((Len < 3) || !(Len & 0x01))	return -1;
		X wn, *fb = Data;
		int32_t i;
		int32_t n;
		int32_t hlen = (int32_t)(Len >> 1);

		n = -hlen;
		for (i=0; i < Len; i++){

			wn = 0.42f + 0.5f * cos((m2pi * n) / (Len - 1)) + 0.08f * cos((m4pi * n) / (Len - 1));

			*fb = wn;

			fb++;
			n++;
		}
		return 0;
	}
	// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	// Data�Ƀu���b�N�}�����|����
	// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	template<typename X>
	int32_t blackmanMulti(X *Data, size_t Len){
		if ((Len < 3) || !(Len & 0x01))	return -1;
		X wn, *fb = Data;
		int32_t i;
		int32_t n;
		int32_t hlen = (int32_t)(Len >> 1);

		n = -hlen;
		for (i = 0; i < Len; i++){

			wn = 0.42f + 0.5f * cos((m2pi * n) / (Len - 1)) + 0.08f * cos((m4pi * n) / (Len - 1));

			*fb *= wn;

			fb++;
			n++;
		}
		return 0;
	}


}


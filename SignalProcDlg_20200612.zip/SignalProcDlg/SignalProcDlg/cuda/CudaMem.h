// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// CudaMen.h
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *


#include "stdint.h"

// System includes
#include <stdio.h>
#include <assert.h>

// CUDA runtime
#include <cuda_runtime.h>

// helper functions and utilities to work with CUDA
#include <helper_functions.h>
#include <helper_cuda.h>




// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
///template<typename X>
struct CudaMenInt8{

	CudaMenInt8()
	:m_Data(nullptr),m_Len(0)
	{}

	~CudaMenInt8()
	{
		if(m_Data!=nullptr)	cudaFree(m_Data);
	}

	cudaError_t malloc(size_t Len){
	    cudaError_t cudaStatus;
	 	cudaStatus = cudaMalloc((void**)&m_Data, Len * sizeof(uint8_t));
		m_Len = Len;
		return cudaStatus;
	}

	int8_t	*m_Data;
	size_t	m_Len;
};


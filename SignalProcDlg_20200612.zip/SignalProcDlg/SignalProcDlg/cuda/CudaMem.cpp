// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  CudaMem.cpp
//
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

// System includes
#include <stdio.h>
#include <assert.h>

// CUDA runtime
#include <cuda_runtime.h>

// helper functions and utilities to work with CUDA
#include <helper_functions.h>
#include <helper_cuda.h>

#include <stdint.h>

#include "stdafx.h"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//#include "CudaMem.h"
//__align__(4) 
int8_t *gIfDump = nullptr;
size_t gIfDumpLen = 0;

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
__host__ int loadIfDump(const CString &FilePath)
{
    cudaError_t cudaStatus;
	int	ack=0;

	//*Data	= nullptr;

	std::ifstream ifs(FilePath, ios::in | ios::binary );	// �o�C�i�����[�h�łɂ��Ȃ��ƁA�ǂݍ��񂾃t�@�C���T�C�Y������Ȃ��Ȃ�B
    if (ifs.fail()){
        return -3;
    }
    int begin = static_cast<int>(ifs.tellg());
    ifs.seekg(0, ifs.end);
    // �ꉞ�͈̓`�F�b�N���ׂ������ǁc�c
    int end = static_cast<int>(ifs.tellg());
    int size = end - begin;
    ifs.clear();		 // ������clear����EOF�t���O������
    ifs.seekg(0, ifs.beg);
    char *str = new char[size];	// +1
    ifs.read(str, size);
//    str[size] = '\0';	 // �O�̂��ߖ�����NULL������

	if(gIfDump!=nullptr)	cudaFree(gIfDump);

	cudaStatus = cudaMalloc((void**)&gIfDump, size * sizeof(uint8_t));
	if (cudaStatus != cudaSuccess) {
		ack = -4;
		goto Error;
	}

	// �f�[�^�R�s�[
	cudaStatus = cudaMemcpy((void*)gIfDump ,(void*)str ,size * sizeof(uint8_t) ,cudaMemcpyHostToDevice);
	if (cudaStatus != cudaSuccess) {
		ack = -5;
		goto Error;
	}

	gIfDumpLen = size;

Error:
	delete str;

	return ack;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
__host__ void freeIfDump()
{
	if(gIfDump != nullptr)	cudaFree(gIfDump);
	gIfDump = nullptr;
	gIfDumpLen = 0;
}


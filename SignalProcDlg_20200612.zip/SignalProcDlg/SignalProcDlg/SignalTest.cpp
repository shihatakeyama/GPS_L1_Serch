// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// SignalTest.cpp
//
// �M��������H�̃e�X�g
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *


#include "stdafx.h"

#include "math.h"
#include <vector>

#include "GnrlDefine.h"
#include "GnrlInt.h"

#include "SP_define.h"

#include "GPU_Fir.h"


Float32 gSignal[256];
SignWaveGenf<Float32> singen_Test;
FirFilterf<Float32,Float64> gFirf(31);
GPU_FirFloat32 gf;

int GPU_call_Firf(float *OutData ,const float *InData ,size_t DataLen ,const float *Tap ,size_t TapLen);

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// ����
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t SignalTest(LineDataSet &Data ,int32_t Len)
{
	const Float32 clk = 20000.0f;
	const size_t onelen = 1024;//1024*16;
///	int32_t i;

	// FIR�t�B���^ ����
	LineDataSet ldsb;
	ldsb.addSeries(SeriesBase::ENE_float32);
	ldsb[0].resize(onelen);

	FirFilterfTap<Float32> &firtap = gFirf.getTap();
//	numpy::lopassTap00<Float32>(&firtap.m_h[0], firtap.m_h.size(), clk, 1000.0f);
	numpy::hipassTap00<Float32>(&firtap.m_h[0], firtap.m_h.size(), clk, 1000.0f);
//dd	numpy::bandpassTap00<Float32>(&firtap.m_h[0], firtap.m_h.size(), clk, 1000.0f, 1000.0f);
//dd	numpy::hanningMulti(&firtap.m_h[0] ,firtap.m_h.size());
	numpy::hanningMulti(&firtap.m_h[0] ,firtap.m_h.size());

	// ���͐M������
	LineDataSet ldsa;
	ldsa.addSeries(SeriesBase::ENE_float32);
	ldsa[0].resize(onelen);

#if 0
	for(i=0;i<Len;i++){
		singen_Test.putFreq1Clk(freq1Clk(1000.0f-900.0f+(5.0f*i) ,clk));
		singen_Test.putLevel(20.0f);

		singen_Test.gen(ldsa[0].getSeriesFloat32Arrow() ,ldsa[0].getSeriesFloat32Arrow(),ldsa[0].size());		//  ,0.8f

		// �t�B���^����
//--		gFirf.gen(ldsb[0].getSeriesFloat32Arrow() ,ldsa[0].getSeriesFloat32Arrow() ,ldsa[0].size());	// CPU
		GPU_call_Firf(ldsb[0].getSeriesFloat32Arrow()  ,ldsa[0].getSeriesFloat32Arrow() ,ldsa[0].size() ,&gFirf.getTap().m_h[0] ,gFirf.getTap().m_h.size());	// GPU

		Float32 rms = rmsf<Float32,Float32>(ldsb[0].getSeriesFloat32Arrow()+firtap.m_h.size() ,ldsb[0].size()-firtap.m_h.size());

		Data[0].getSeriesFloat32Arrow()[i] = rms;
	}
#endif

#if 0	// GPU FF����
	{
		singen_Test.putFreq1Clk(freq1Clk(1000.0f-900.0f+(10.0f*0) ,clk));
		singen_Test.putLevel(20.0f);

		singen_Test.gen(ldsa[0].getSeriesFloat32Arrow() ,ldsa[0].getSeriesFloat32Arrow(),ldsa[0].size());		//  ,0.8f

			// �t�B���^����
//		gFirf.gen(Data[0].getSeriesFloat32Arrow() ,ldsa[0].getSeriesFloat32Arrow() ,ldsa[0].size());	// CPU
		GPU_call_Firf(Data[0].getSeriesFloat32Arrow()  ,ldsa[0].getSeriesFloat32Arrow() ,ldsa[0].size() ,&gFirf.getTap().m_h[0] ,gFirf.getTap().m_h.size());	// GPU
//		Data[0] = ldsa[0];

	}

#endif

#if 1	// GPU FF�L��
	{

		gf.putTap(&firtap.m_h[0] ,firtap.m_h.size());

		singen_Test.putFreq1Clk(freq1Clk(1000.0f-900.0f+(10.0f*0) ,clk));
		singen_Test.putLevel(20.0f);

		singen_Test.gen(ldsa[0].getSeriesFloat32Arrow() ,ldsa[0].getSeriesFloat32Arrow(),ldsa[0].size());		//  ,0.8f

		gf.gen(Data[0].getSeriesFloat32Arrow() ,ldsa[0].getSeriesFloat32Arrow() ,ldsa[0].size());
//--		Data[0] = ldsa[0];
	}

#endif

	return 0;
}



// SinWaveGenDlg.cpp : �����t�@�C��
//

#include "stdafx.h"
#include "SignalProcDlg.h"
#include "SinWaveGenDlg.h"
#include "afxdialogex.h"


// SinWaveGenDlg �_�C�A���O

IMPLEMENT_DYNAMIC(SinWaveGenDlg, CDialogEx)

SinWaveGenDlg::SinWaveGenDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(SinWaveGenDlg::IDD, pParent)
	, m_OutputSignal_0(_T(""))
	, m_SampleClk(0)
	, m_Freq(0)
	, m_ChkAmp(FALSE)
	, m_ChkFreq(FALSE)
	, m_FreqS(0)
	, m_Phase(0)
	, m_ChkPhase(FALSE)
	, m_AmpS(0)
	, m_Amp(0)
	, m_PhaseS(0)
{
}

SinWaveGenDlg::~SinWaveGenDlg()
{
}

void SinWaveGenDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_INPUT, m_InputSignal_0);
	DDX_Text(pDX, IDC_EDIT_OUTPUT, m_OutputSignal_0);

	DDX_Text(pDX, IDC_EDIT_SAMPLE_FREQ, m_SampleClk);
	DDX_Text(pDX, IDC_EDIT_FREQ, m_Freq);
	DDX_Text(pDX, IDC_EDIT_PHASE, m_Phase);
	DDX_Text(pDX, IDC_EDIT_AMP, m_Amp);

	DDX_Text(pDX, IDC_EDIT_AMP_S, m_AmpS);
	DDX_Text(pDX, IDC_EDIT_FREQ_S, m_FreqS);
	DDX_Text(pDX, IDC_EDIT_PHASE_S, m_PhaseS);

	DDX_Check(pDX, IDC_CHECK_FREQ, m_ChkFreq);
	DDX_Check(pDX, IDC_CHECK_PHASE, m_ChkPhase);
	DDX_Check(pDX, IDC_CHECK_AMP, m_ChkAmp);


}


BEGIN_MESSAGE_MAP(SinWaveGenDlg, CDialogEx)
END_MESSAGE_MAP()


// SinWaveGenDlg ���b�Z�[�W �n���h���[


BOOL SinWaveGenDlg::PreTranslateMessage(MSG* pMsg)
{
	// TODO: �����ɓ���ȃR�[�h��ǉ����邩�A�������͊��N���X���Ăяo���Ă��������B

	return CDialogEx::PreTranslateMessage(pMsg);
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//
//
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

#pragma once


// SinWaveGenDlg �_�C�A���O

class SinWaveGenDlg : public CDialogEx
{
	DECLARE_DYNAMIC(SinWaveGenDlg)

public:
	SinWaveGenDlg(CWnd* pParent = NULL);   // �W���R���X�g���N�^�[
	virtual ~SinWaveGenDlg();

// �_�C�A���O �f�[�^
	enum { IDD = IDD_SIN_GEN_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �T�|�[�g

	DECLARE_MESSAGE_MAP()
public:
	CString m_InputSignal_0;
	CString m_OutputSignal_0;

	int m_SampleClk;

	int m_Freq;
	int m_Phase;
	int m_Amp;

	int m_FreqS;
	int m_PhaseS;
	int m_AmpS;

	BOOL m_ChkFreq;
	BOOL m_ChkPhase;
	BOOL m_ChkAmp;

	virtual BOOL PreTranslateMessage(MSG* pMsg);



};

// **********************************************************************
// COM ����̃f�[�^��҂��󂯂�X���b�h
//
// ComRecvThread.h
// 
// 2013/06/31  Createed
// 2019/12/22  J�C��
// **********************************************************************

#ifndef COMRECVTHREAD_H
#define COMRECVTHREAD_H

#include "stdafx.h"
#include "Resource.h"

#include "GnrlDefine.h"
#include "GnrlThread.h"

#include "SignalProcDlgDlg.h"

//--#include "SP_Global.h"

class ComRecvThread :
	public GnrlThread{

public:

	ComRecvThread();

	void setWnd(CWnd *Wnd);


	// Com��M���[�`��
	virtual int32_t run();

	const CString &getReadLine()	{ return m_ReadLine;	 }

private:
	CWnd	*m_Wnd;
	CString m_ReadLine;
};


#endif // #ifndef COMRECVTHREAD_H
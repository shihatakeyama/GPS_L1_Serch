// NoiseGenDlg.cpp : �����t�@�C��
//

#include "stdafx.h"
#include "SignalProcDlg.h"
#include "NoiseGenDlg.h"
#include "afxdialogex.h"


// CNoiseGenDlg �_�C�A���O

IMPLEMENT_DYNAMIC(CNoiseGenDlg, CDialogEx)

CNoiseGenDlg::CNoiseGenDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CNoiseGenDlg::IDD, pParent)
{

}

CNoiseGenDlg::~CNoiseGenDlg()
{
}

void CNoiseGenDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CNoiseGenDlg, CDialogEx)
END_MESSAGE_MAP()


// CNoiseGenDlg ���b�Z�[�W �n���h���[

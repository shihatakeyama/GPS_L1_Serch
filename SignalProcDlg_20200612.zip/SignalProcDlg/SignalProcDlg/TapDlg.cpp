// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// TapDlg.cpp : �����t�@�C��
//  
// TAP�v�Z�̈��p �F http://www7b.biglobe.ne.jp/~dfd_house/
//
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *


#include "stdafx.h"
#include "SignalProcDlg.h"
#include "TapDlg.h"
#include "afxdialogex.h"

#include "GnrlCharset.h"

#define _USE_MATH_DEFINES
#include <math.h>

// CTapDlg �_�C�A���O

IMPLEMENT_DYNAMIC(CTapDlg, CDialogEx)


// 
const CString CTapDlg::mKindListStr[]	= { N_T("Low Pass"), N_T("Band Pass"), N_T("Hi Pass") ,N_T("Fix1") ,N_T("Sum1") };		// CTapDlg::ETK_num
const CString CTapDlg::mWindowListStr[] = { N_T("Hanning"), N_T("Hamming"), N_T("Blackman"), N_T("Rectangle"), N_T("    ") };	// Kaiser
const Float32 CTapDlg::m2pi				= static_cast<Float32>(M_PI * 2);
const Float32 CTapDlg::m4pi				= static_cast<Float32>(M_PI * 4);

CTapDlg::CTapDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CTapDlg::IDD, pParent)
	, m_Fc(4000)
	, m_Fb(2000)
	, m_Fck(10000)
	, m_TapN(31)
	, m_Coeffi(_T(""))
{}

CTapDlg::~CTapDlg()
{}

void CTapDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO_LBH, m_Lbh);
	DDX_Text(pDX, IDC_EDIT_FC, m_Fc);
	DDX_Text(pDX, IDC_EDIT_SAMPLE_FREQ, m_Fck);
	DDX_Text(pDX, IDC_EDIT_TAP_N, m_TapN);
	DDX_Control(pDX, IDC_COMBO_WINDOW, m_ComboWindow);
	DDX_Text(pDX, IDC_EDIT_FB, m_Fb);
	DDX_Text(pDX, IDC_EDIT_TAP_VAL, m_Coeffi);
}


BEGIN_MESSAGE_MAP(CTapDlg, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON_CALC, &CTapDlg::OnBnClickedButtonCalc)
	ON_WM_PAINT()
END_MESSAGE_MAP()


// CTapDlg ���b�Z�[�W �n���h���[


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// ��ʃC�j�V�����C�Y
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
BOOL CTapDlg::OnInitDialog()
{
	int32_t i;

	CDialogEx::OnInitDialog();

	// TODO: �����ɏ�������ǉ����Ă�������
	m_Graph.initDlgItem(this, IDC_TAP_GRAPH);

	// �t�B���^���
//--	m_Lbh.InsertString(0 ,mKindListStr[ETK_low]);
//--	m_Lbh.InsertString(1, mKindListStr[ETK_band]);
//--	m_Lbh.InsertString(2, mKindListStr[ETK_high]);
	for (i = 0; i<ETK_num; i++){
		m_Lbh.InsertString(i, mKindListStr[i]);
	}

	m_Lbh.SetCurSel(0);

	// �E�C���h�E���
	for (i = 0; i<ETW_num; i++){
		m_ComboWindow.InsertString(i, mWindowListStr[i]);
	}
	m_ComboWindow.SetCurSel(ETK_hanning);

	return TRUE;  // return TRUE unless you set the focus to a control
	// ��O : OCX �v���p�e�B �y�[�W�͕K�� FALSE ��Ԃ��܂��B
}

void CTapDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	m_Graph.onPaint();
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  �O���t��`�悷��B(���)
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void CTapDlg::drawGraph()
{
	m_Graph.dataSet() = m_Tap;

	m_Graph.setViewAreaXEntrySize();
	m_Graph.setViewAreaY();
	m_Graph.autoXGridSpacing();
	m_Graph.autoYGridSpacing();

	m_Graph.onPaint();
#if 0
	SeriesBase *ser = m_Tap.getElement(0);

	if (ser){
		m_Graph.setViewAreaXEntrySize();
		m_Graph.setViewAreaY();
		m_Graph.autoXGridSpacing();
		m_Graph.autoYGridSpacing();
		m_Graph.onPaint();
	}
	else{
		m_Graph.drawGrid();
	}
#endif
}

// **********************************************************************
//  
// **********************************************************************
int CTapDlg::outputText()
{
	SeriesBase *tap = m_Tap.getElement(0);
	CString	str;
	int i,end;

	m_Coeffi.Empty();

	if (tap->empty())	return ERC_empty;

	end = tap->size();
#if 0
	if (tap->getValTypeId() == SeriesBase::ENE_int32_t){
		int32_t *sval = tap->getSeriesInt32Arrow();
		for (i = 0; i < end; i++){
			str.Format(N_T("a%d = %d\x0d\x0a"), i+1, sval[i]);
			m_Coeffi += str;
		}
	}else if (tap->getValTypeId() == SeriesBase::ENE_float32){
		Float32 *faval = tap->getSeriesFloat32Arrow();
		for (i = 0; i < end; i++){
			str.Format(N_T("a%d = %f\x0d\x0a"), i+1, faval[i]);
			m_Coeffi += str;
		}
	}
#else
	for (i = 0; i < end; i++){
		str.Format(N_T("a%02d = %s\x0d\x0a"), i+1, tap->toString(i));
		m_Coeffi += str;
	}
#endif
	return ERC_ok;
}

void CTapDlg::OnBnClickedButtonCalc()
{
	int32_t	n,end;		// -1 �` +1
	Float32	td;
	Float32 temp;
	Float32 x,y,yn;
	Float32 wn;			// �E�C���h�E��
	Float32 hn;
	Float32 fcs;
	Float32 r,R;
	Float32 fcl;
	Float32 *fb;
	Float32 crn;

	UpdateData(TRUE);

	m_Tap.clear();

	if (m_TapN <= 0)	return;
	
	SeriesBase::SeriesFloat32 *tap = m_Tap.addSeriesFloat32();
	if (tap == NULL)	return;

	tap->resize(m_TapN);
	fb = tap->getSeriesFloat32Arrow();

//return;

	// **** LBH ****
	if(m_Lbh.GetCurSel() == ETK_low){
#if 0
//**	LPF�v�Z���F
//**  1) �d�l�F�J�b�g�I�t���g�� fc = 2.0Hz
//**  2) �\���F���ԕ�   t=-1.0�b ���� +1.0�b�܂�
//**         �i���_���-������+���܂ő����܂����j
//**  3) �v�Z���FTd = 0.025�b���݁BM =1.0/0.025=40 
//**  4) �v�Z���F x = 2*PI()*fc*n*Td, 
//**              y = sin(x)/x,      n = -M ~ +M�@
//**  5) �\���F�܂���O���t�@
//**		����=����t�A�c��=��=sin(x)/x

		end = m_TapN / 2;
		//td = 1.0f / end;
		R	= (Float32)m_Fc / (Float32)m_Fck;
		for (n = -end; n<=end; n++){
			temp = m2pi * n * R;
			if (fabs(temp) < 0.0001f){
				yn = 1.0f;
			}
			else{
				yn = sin(temp) / temp;
			}

			hn	= yn ;

			*fb	= hn;
			fb++;
		}
#else
		numpy::lopassTap00<Float32>(fb, m_TapN ,m_Fck ,m_Fc);
		numpy::leveladjustment(fb, fb , m_TapN ,0.5f);
#endif
	}else if(m_Lbh.GetCurSel() == ETK_band){
#if 0
//**	BPF�v�Z���F
//**   1) y(n) = SIN(2*��*n*R)/(2*��*n*R),
//**   2) w(n) = 0.50 + 0.50*COS(2*��*n/(N-1))�@
//**   3) cr(n)= COS( 2*��*r*n ) 
//**   4) h(n) = y(n)*w(n)*cr(n)
//**      n  = 0, 1, 2, ...., M

//**   4) BPF���S���g��      �@fc  =  2.0 MHz
//**�@�@  BPF�ш敝          �@fb  =  2.0 MHz
//**      ���g���䗦�@R=  fb/2/fck =  0.10        == ��LPF�݌v�ł̃C���p���X���������߂�䗦
//**      ���g���䗦�@r=  fc/fck   =  0.20�@�@    == ���g���V�t�g�̃L�����A�[���g���䗦

		end = m_TapN / 2;
		td = 1.0f / end;
		R	= (Float32)m_Fb/2.0f/(Float32)m_Fck;
		fcl	= (Float32)m_Fck / 2 - (Float32)m_Fc;
		r	= (Float32)m_Fc / (Float32)m_Fck;		/// fcl /
		for (n = -end; n<=end; n++){
			temp = m2pi * n * R;
			if (fabs(temp) < 0.0001f){
				yn = 1.0f;
			}
			else{
				yn = sinf(temp) / (temp);		// 1) y(n) = SIN(2*��*n*R)/(2*��*n*R),
			}

			crn = cosf(m2pi * r * n);

			hn	 = yn * crn;

			*fb	= hn;
			fb++;
		}
#else
		numpy::bandpassTap00<Float32>(fb, m_TapN, m_Fck, m_Fc, m_Fb);
		numpy::leveladjustment(fb, fb , m_TapN ,0.5f);
#endif
	}else if(m_Lbh.GetCurSel() == ETK_high){
#if 0
//**	HPF�v�Z���F
//**   1) y(n) = SIN(2*��*n*R)/(2*��*n*R),
//**   2) w(n) = 0.50 + 0.50*COS(2*��*n/(N-1))�@
//**   3) cr(n)= (-1)^n ; �L�����A�[�g�`�̎�            �}3-2-1 3-1��LPF����̃Q�C���f���g�������i�g���j
//**   4) h(n) = y(n)*w(n)*cr(n)
//**      n  = 0, 1, 2, ...., M
		end = m_TapN / 2;
		fcl = (Float32)m_Fck / 2 - (Float32)m_Fc;
		r	= (Float32)fcl / (Float32)m_Fck;
		for (n = -end; n <= end; n++){
			temp = m2pi * n * r;
			if (fabs(temp) < 0.0001f){
				yn = 1.0f;
			}
			else{
				yn = sinf(temp) / (temp);
			}

			crn = pow(-1, n);

			hn	 = yn * crn;

			*fb	= hn;
			fb++;
		}
#else
		numpy::hipassTap00<Float32>(fb, m_TapN, m_Fck, m_Fc);
		numpy::leveladjustment(fb, fb , m_TapN ,0.5f);
#endif
	}
	else if (m_Lbh.GetCurSel() == ETK_1){
#if 0
		end = m_TapN / 2;
		for (n = -end; n <= end; n++){
			hn	= 1.0f;
			*fb	= hn;
			fb++;
		}
#else
		numpy::numset<Float32>(fb, m_TapN ,1.0f);
#endif
	}else if(m_Lbh.GetCurSel() == ETK_accum1){
		end = m_TapN / 2;
		hn	= 1.0f / m_TapN;
		for (n = -end; n <= end; n++){
			*fb	= hn;
			fb++;
		}
	}else{
		return;
	}

#if 1

	// **** ���֐� ****

	fb	= tap->getSeriesFloat32Arrow();

	if(m_ComboWindow.GetCurSel() == ETK_hanning){
		numpy::hanningMulti(fb, m_TapN);
	}else if (m_ComboWindow.GetCurSel() == ETW_hamming){
		numpy::hammingMulti(fb, m_TapN);
	}else if (m_ComboWindow.GetCurSel() == ETW_blackman){
		numpy::blackmanMulti(fb, m_TapN);
	}else if (m_ComboWindow.GetCurSel() == ETW_rectangle){
		;
	}else if (m_ComboWindow.GetCurSel() == ETW_kaiser){
		// ���Ή�
	}


#endif

	drawGraph();	
	outputText();

	UpdateData(FALSE);
}

BOOL CTapDlg::PreTranslateMessage(MSG* pMsg)
{

	m_Graph.PreTranslateMessageSol(*this, pMsg);

	return CDialogEx::PreTranslateMessage(pMsg);
}

/*
Sample  100000 Hz
CutOff  10000 Hz

a01 = -7.1249948844288E-5
a02 = -0.00031681917284752
a03 = 0.0004964043979538
a04 = 0.0033169166508133
a05 = 0.0068827696764662
a06 = 0.0075140098941429
a07 = 0.0013343577888286
a08 = -0.012130446216004
a09 = -0.027386386655702
a10 = -0.033693873006959
a11 = -0.019579684184035
a12 = 0.02075552114264
a13 = 0.082581251172928
a14 = 0.15041563381475
a15 = 0.20326869142006
a16 = 0.23322580645161
a17 = 0.20326869142006
a18 = 0.15041563381475
a19 = 0.082581251172928
a20 = 0.02075552114264
a21 = -0.019579684184035
a22 = -0.033693873006959
a23 = -0.027386386655702
a24 = -0.012130446216004
a25 = 0.0013343577888286
a26 = 0.0075140098941429
a27 = 0.0068827696764662
a28 = 0.0033169166508133
a29 = 0.0004964043979538
a30 = -0.00031681917284752
a31 = -7.1249948844288E-5

*/




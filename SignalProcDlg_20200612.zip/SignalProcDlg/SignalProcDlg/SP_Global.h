// **********************************************************************
// SP_Global.h
//
//
// **********************************************************************

#ifndef SP_GLOBAL_H
#define SP_GLOBAL_H


#include "stdafx.h"

#include <vector>

#include "GnrlDefine.h"
#include "GnrlCharset.h"

//#include "Random.h"
//#include "SP_define.h"


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
extern std::vector<Float32>		gSignalFloat[8];
extern std::vector<int32_t>		gSignalInt[8];
extern GLThread					gGLThread;

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �ʐM�֘A
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
extern LineDataSet				gGraphCsv;
extern GnrlCom					gCom;
extern ComRecvThread			gComRecvThread;

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �v���Z�X�֘A�f�[�^
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
extern st_CsvParam				gCsvParam;
extern std::string				gComment;
extern std::vector<ProcessBase*>	gProcessList;


const char *gFourArithmetic[];
const char *gFilterTypeText[];

// SP_sub.h
int32_t findStringListId(const CString &PurposeName ,const LPCTSTR NameList[]);


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �t�@�C�����o��
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t readMalloc(char **Data ,const Nchar *FilePath);

#endif // SP_GLOBAL_H


// **********************************************************************
//  ProcessNoise.cpp
//  
//  �����_��
// **********************************************************************

#include "stdafx.h"

#define _USE_MATH_DEFINES
#include <math.h>

#include <vector>

#include "NoiseGenDlg.h"
#include "GnrlDefine.h"

//--#include "Random.h"


ProcessNoise::ProcessNoise()
 :ProcessBase(EPT_noise)
{}

ProcessNoise::~ProcessNoise()
{}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t ProcessNoise::showSetDlg()
{
	CNoiseGenDlg dlg;

	dlg.DoModal();

	return 0;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// XML����I�u�W�F�N�g���\�z
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t ProcessNoise::loadXml(const rapidxml::xml_node<>* Child)
{

	return 0;
}

int32_t ProcessNoise::saveXml(rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* Child) const
{

	return 0;
}


// **********************************************************************
//  ProcessNoise.h
// 
//  �����_��
// **********************************************************************

#pragma once

#include "stdafx.h"

// **********************************************************************
// �m�C�Y�𐶐�
// **********************************************************************
class ProcessNoise
:public ProcessBase{

public:

	ProcessNoise();
	virtual ~ProcessNoise();


	virtual int32_t gen(LineDataSet &Out, LineDataSet &In)
	{
		return 0;
	}

	virtual RstrFraction fluctuationRate() const
	{
		return RstrFraction();
	}

	// 
	virtual int32_t showSetDlg();

	// XML����I�u�W�F�N�g���\�z
	virtual int32_t loadXml(const rapidxml::xml_node<>* Child);
	virtual int32_t saveXml(rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* Child) const;
};

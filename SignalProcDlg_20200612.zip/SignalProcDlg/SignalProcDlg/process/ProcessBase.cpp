// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  ProcessBase.cpp
//  
//  �e�폈���̉��n
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *



#include "stdafx.h"



// XML �t�@�C���ȂǂŎg�p���鏈���^�C�v
const char *ProcessBase::m_ProcNameList[]	= {"noise","sin_wave","iir_filter","fir_filter","mixer",nullptr};


ProcessBase::ProcessBase()
{}
ProcessBase::ProcessBase(enum E_ProcessType	ProcType)
:m_ProcType(ProcType)
{}
ProcessBase::~ProcessBase()
{}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// ���X�g�ɕ\�����镶����
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
CString ProcessBase::getCellText(int32_t Colum) const
{
	CString str;

	str.Format(_T("%d") ,Colum);

	return str;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �ݒ�_�C�A���O�\��
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t ProcessBase::showSetDlg()
{

	return 0;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  ProcessBase����̔h���v���Z�X��new
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
ProcessBase *ProcessBase::newProcess(enum E_ProcessType ValTypeId){

	ProcessBase *pbase = NULL;

	switch (ValTypeId){
		case EPT_noise:
			pbase = new ProcessNoise();
			break;
		case EPT_sin_wave:
			pbase = new ProcessSinWave();
			break;
		case EPT_iir_filter:
//++			pbase = new ProcessIirFilter();
			break;
		case EPT_fir_filter:
//++			pbase = new ProcessFirFilter();
			break;
		default:
			ASSERT(0);
			break;
	}

	return pbase;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  �v���Z�X���X�g�N���A
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void ProcessBase::clearProcessList(std::vector<ProcessBase*> &List)
{
	for (const auto &itr : List){
		delete itr;
	}

	List.clear();
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �v���Z�X���X�g��XML����ǂݍ���
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t ProcessBase::loadProcessList(std::vector<ProcessBase*>	&List ,const rapidxml::xml_node<>* ProcessXml)
{
#if 1
	int32_t id;
	ProcessBase *plist;


	ProcessBase::clearProcessList(List);

	if(strcmp(ProcessXml->name() ,"processlist") != 0){
		ASSERT(0);
		return -1;
	}


//--		rapidxml::attribute_iterator<char>();

//--	const rapidxml::xml_node<>* node = ProcessXml;
//--	for (rapidxml::xml_node<>* child = node->first_node(); 
//--		child != nullptr; 
//--		child = child->next_sibling() ) {

//--		rx::attribute_iterator<char> att_itr(child);
//--		const rx::xml_attribute<char> *attr(rx::attribute_iterator<char>(child));
//--		const rx::xml_attribute<char> type = attr->next_attribute("type");
//--        for (const rapidxml::xml_attribute<>& attr : rapidxml::attribute_iterator<char>(child)) {
//--            cout << attr.name() << "=" << attr.value() << " "; 
//--        }


//--	rapidxml::node_iterator<char>  aat(ProcessXml);	
//--	rapidxml::node_iterator<char>  aau = begin(aat);
	
	for (auto &itr : rapidxml::node_iterator<char>(ProcessXml)) {

		id = findStringListId(itr.name() ,m_ProcNameList);
		if(id < 0){
			std::string str = "An indeterminable process tag was found in the XML file. \n";
			str += itr.name();
			throw std::runtime_error(str);
		}
		plist = newProcess((enum E_ProcessType)id);
		if(plist == nullptr){
			std::string str; 
			str = "Process not support:";
			str += itr.name();
			throw std::runtime_error(str);
		}
		List.push_back(plist);

		plist->loadXml(&itr);
		
	}	// "processlist" ���|���I��

	#endif

	return 0;
}
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �v���Z�X���X�g�̓��e��XML�֕ϊ�
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t ProcessBase::saveProcessList(const std::vector<ProcessBase*> &List ,rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* ProcessXml)
{
	rapidxml::xml_node<>* proc;

	for(const auto &itr : List){
			itr->saveXml(Doc ,ProcessXml);
	}
	
	return 0;
}
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �e�v���Z�X�̓��e��XML�I�u�W�F�N�g�֓ǂݏ���
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t ProcessBase::loadXml(const rapidxml::xml_node<>* Child)
{
	return 0;
}
int32_t ProcessBase::saveXml(rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* Child) const
{
	return 0;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  XML���烏�C�������擾����B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t ProcessBase::loadXmlInputAndOutputWire(const rapidxml::xml_node<>* BaseNode ,std::vector<std::string> &InWire ,std::vector<std::string> &OutWire)
{
	rapidxml::xml_node<>* child;

	InWire.clear();
	OutWire.clear();

#if 1
	child = BaseNode->first_node("input_wire");
	if(child == nullptr)	return -1;
	for (rapidxml::xml_node<>& elem : rapidxml::node_iterator<char>(child)) {
		InWire.push_back(elem.value());
    }

	child = BaseNode->first_node("output_wire");
	if(child == nullptr)	return -1;
	for (rapidxml::xml_node<>& elem : rapidxml::node_iterator<char>(child)) {
		OutWire.push_back(elem.value());
    }
#else
	for (rapidxml::xml_node<>& elem : rapidxml::node_iterator<char>(child)) {
    }
#endif

	return 0;
}
int32_t ProcessBase::saveXmlInputAndOutputWire(rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* BaseNode ,const std::vector<std::string> &InWire ,const std::vector<std::string> &OutWire) const
{
	rapidxml::xml_node<>* wires;
	rapidxml::xml_node<>* wire;
	rapidxml::xml_attribute<>* attr;
	int32_t ord = 1;

	// Input
	wires = BaseNode->first_node("input_wire");
	if(wires == nullptr){
		wires = Doc.allocate_node(rapidxml::node_element, "input_wire");	// , "LOL"
		BaseNode->append_node(wires);
	}

	wire = wires->first_node("wire");
	for (auto const &elem : InWire) {
		if(wire == nullptr){
			wire = Doc.allocate_node(rapidxml::node_element, "wire");	// 
			wires->append_node(wire);
		}

		attr = wire->first_attribute("value");
		if(attr == nullptr){
			attr = Doc.allocate_attribute("value" ,std::to_string(ord).c_str());
			wire->append_attribute(attr);
		}

		wire->value(elem.c_str());

		ord++;
    }


	// Output
	wires = BaseNode->first_node("output_wire");
	if(wires == nullptr){
		wires = Doc.allocate_node(rapidxml::node_element, "output_wire");
		BaseNode->append_node(wires);
	}

	wire = wires->first_node("wire");
	for (auto const &elem : OutWire) {
		if(wire == nullptr){
			wire = Doc.allocate_node(rapidxml::node_element, "wire");
			wires->append_node(wire);
		}

		attr = wire->first_attribute("value");
		if(attr == nullptr){
			attr = Doc.allocate_attribute("value" ,std::to_string(ord).c_str());
			wire->append_attribute(attr);
		}

		wire->value(elem.c_str());

		ord++;
    }

	return 0;
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �l���擾
// proc_node �̒�����AName�m�[�h��T���AVal��Step���擾���܂��B
// Step�͑����ł���B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t ProcessBase::readVal(const rapidxml::xml_node<>* BaseNode ,const char *Name ,int32_t &Val)
{
	const rapidxml::xml_node<>* node_tmp;

	node_tmp = BaseNode->first_node(Name);
	if(node_tmp == nullptr){
		Val	 = 0;
		return -5;
	}

	Val = atoi(node_tmp->value());

	return 0;
}

int32_t ProcessBase::readVal(const rapidxml::xml_node<>* BaseNode ,const char *Name ,Float32 &Val)
{
	const rapidxml::xml_node<>* node_tmp;

	node_tmp = BaseNode->first_node(Name);
	if(node_tmp == nullptr){
		Val	 = 0;
		return -5;
	}

	Val	= atof(node_tmp->value());

	return	0;
}

int32_t ProcessBase::writeVal(rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* BaseNode ,const char *Name ,const int32_t &Val)
{
	std::string str = std::to_string(Val);
	rapidxml::xml_node<>* node = Doc.allocate_node(rapidxml::node_element, Name ,str.c_str());
	BaseNode->append_node(node);

	return 0;
}
int32_t ProcessBase::writeVal(rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* BaseNode ,const char *Name ,const Float32 &Val)
{
	std::string str = std::to_string(Val);
	rapidxml::xml_node<>* node = Doc.allocate_node(rapidxml::node_element, Name ,str.c_str());
	BaseNode->append_node(node);

	return 0;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �l��step���擾
// proc_node �̒�����AName�m�[�h��T���AVal��Step���擾���܂��B
// Step�͑����ł���B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t ProcessBase::readValAndStep(const rapidxml::xml_node<>* BaseNode ,const char *Name ,int32_t &Val ,int32_t &Step ,bool &Enable)
{

	const rapidxml::xml_node<>* ojt_node;
	const rapidxml::xml_attribute<>* ojt_attr;

	ojt_node = BaseNode->first_node(Name);
	if(ojt_node == nullptr){
		Val		= 0;
		Step	= 0;
		Enable	= FALSE;
		return -5;
	}
	Val = atoi(ojt_node->value());

	ojt_attr = ojt_node->first_attribute("enable");
	if(ojt_attr == nullptr){
		Step	= 0;
		Enable	= FALSE;
		return -4;
	}
	if(_stricmp(ojt_attr->value(),"TRUE")==0){
		Enable = TRUE;
	}else{
		Enable = FALSE;	
	}

	ojt_attr = ojt_node->first_attribute("step");
	if(ojt_attr == nullptr){
		Step	= 0;
		return -3;
	}
	Step = atoi(ojt_attr->value());

	return	0;
}
int32_t ProcessBase::readValAndStep(const rapidxml::xml_node<>* BaseNode ,const char *Name ,Float32 &Val ,Float32 &Step ,bool &Enable)
{
	const rapidxml::xml_node<>* ojt_node;
	const rapidxml::xml_attribute<>* ojt_attr;

	ojt_node = BaseNode->first_node(Name);
	if(ojt_node == nullptr){
		Val		= 0.0f;
		Step	= 0.0f;
		return -5;
	}
	Val = atof(ojt_node->value());

	ojt_attr = ojt_node->first_attribute("enable");
	if(ojt_attr == nullptr){
		Step	= 0;
		Enable	= FALSE;
		return -4;
	}
	if(_stricmp(ojt_attr->value(),"TRUE")==0){
		Enable = TRUE;
	}else{
		Enable = FALSE;	
	}

	ojt_attr = ojt_node->first_attribute("step");
	if(ojt_attr == nullptr){
		Step	= 0.0f;
		return -3;
	}
	Step = atof(ojt_attr->value());

	return	0;
}

int32_t ProcessBase::writeValAndStep(rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* BaseNode ,const char *Name ,const int32_t &Val ,const int32_t &Step ,const bool &Enable)
{
	rapidxml::xml_node<>* ojt_node;
	rapidxml::xml_attribute<>* ojt_attr;
	std::string str;

	str = std::to_string(Val);
	ojt_node = Doc.allocate_node(rapidxml::node_element, Name ,str.c_str());
	BaseNode->append_node(ojt_node);

	str = std::to_string(Step);
	ojt_attr = Doc.allocate_attribute("step",str.c_str());
	ojt_node->append_attribute(ojt_attr);

	if(Enable){
		ojt_attr = Doc.allocate_attribute("enable","true");		
	}else{
		ojt_attr = Doc.allocate_attribute("enable","false");
	}
	ojt_node->append_attribute(ojt_attr);

	return	0;
}

int32_t ProcessBase::writeValAndStep(rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* BaseNode ,const char *Name ,const Float32 &Val ,const Float32 &Step ,const bool &Enable)
{
	rapidxml::xml_node<>* ojt_node;
	rapidxml::xml_attribute<>* ojt_attr;
	std::string str;

	str = std::to_string(Val);
	ojt_node = Doc.allocate_node(rapidxml::node_element, Name ,str.c_str());
	BaseNode->append_node(ojt_node);

	str = std::to_string(Step);
	ojt_attr = Doc.allocate_attribute("step",str.c_str());
	ojt_node->append_attribute(ojt_attr);

	if(Enable){
		ojt_attr = Doc.allocate_attribute("enable","true");		
	}else{
		ojt_attr = Doc.allocate_attribute("enable","false");
	}
	ojt_node->append_attribute(ojt_attr);

	return	0;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// rapidxml::xml_node ����^�b�v��ǂ�/����
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t ProcessBase::readTap(const rapidxml::xml_node<>* BaseNode ,const char *Name ,std::vector<int32_t> &Tap)
{
	const rapidxml::xml_node<>* ojt_node;
	const rapidxml::xml_node<>* child;
	const rapidxml::xml_attribute<>* ojt_attr;
	int32_t tapsize,i;

	Tap.clear();

	ojt_node = BaseNode->first_node(Name);
	if(ojt_node == nullptr){
		return -5;
	}

	ojt_attr = ojt_node->first_attribute("size");
	tapsize = atoi(ojt_attr->value());
	Tap.reserve(tapsize);

	child = ojt_node->first_node("tap");
	if(ojt_node == nullptr)	return -6;

	i = 1;
	while(1){
		// ���ԃ`�F�b�N�͍s��Ȃ��Ă悢�H
		Tap.push_back(atoi(child->value()));
		i++;

		child = child->next_sibling("tap");
		if(child == nullptr)	break;
	}

	return 0;
}
int32_t ProcessBase::readTap(const rapidxml::xml_node<>* BaseNode ,const char *Name ,std::vector<Float32> &Tap)
{
	const rapidxml::xml_node<>* ojt_node;
	const rapidxml::xml_node<>* child;
	const rapidxml::xml_attribute<>* ojt_attr;
	int32_t tapsize,i;

	Tap.clear();

	ojt_node = BaseNode->first_node(Name);
	if(ojt_node == nullptr){
		return -5;
	}

	ojt_attr = ojt_node->first_attribute("size");
	tapsize = atoi(ojt_attr->value());
	Tap.reserve(tapsize);

	child = ojt_node->first_node("tap");
	if(ojt_node == nullptr)	return -6;

	i = 1;
	while(1){
		// ���ԃ`�F�b�N�͍s��Ȃ��Ă悢�H
		Tap.push_back(atof(child->value()));
		i++;

		child = child->next_sibling("tap");
		if(child == nullptr)	break;
	}

	return 0;
}
int32_t ProcessBase::writeTap(rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* BaseNode ,const char *Name ,const std::vector<int32_t> &Tap)
{
	rapidxml::xml_node<> *ojt_node,*child;
	rapidxml::xml_attribute<>* ojt_attr,*attr;
	std::string str;
	int32_t tapsize = Tap.size(),i;

	ojt_node = Doc.allocate_node(rapidxml::node_element, Name);
	BaseNode->append_node(ojt_node);
	str = std::to_string(tapsize);
	ojt_attr = Doc.allocate_attribute("size",str.c_str());
	ojt_node->append_attribute(ojt_attr);

	i = 1;
	for(auto const &itr:Tap){
		str = std::to_string(itr);
		child = Doc.allocate_node(rapidxml::node_element, "tap" ,str.c_str());
		ojt_node->append_node(child);
		str = std::to_string(i);
		attr = Doc.allocate_attribute("value" ,str.c_str());
		child->append_attribute(attr);

		i++;
	}

	return 0;
}
int32_t ProcessBase::writeTap(rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* BaseNode ,const char *Name ,const std::vector<Float32> &Tap)
{
	rapidxml::xml_node<> *ojt_node,*child;
	rapidxml::xml_attribute<>* ojt_attr,*attr;
	std::string str;
	int32_t tapsize = Tap.size(),i;

	ojt_node = Doc.allocate_node(rapidxml::node_element, Name);
	BaseNode->append_node(ojt_node);
	str = std::to_string(tapsize);
	ojt_attr = Doc.allocate_attribute("size",str.c_str());
	ojt_node->append_attribute(ojt_attr);

	i = 1;
	for(auto const &itr:Tap){
		str = std::to_string(itr);
		child = Doc.allocate_node(rapidxml::node_element, "tap" ,str.c_str());
		ojt_node->append_node(child);
		str = std::to_string(i);
		attr = Doc.allocate_attribute("value" ,str.c_str());
		child->append_attribute(attr);

		i++;
	}

	return 0;
}

// **********************************************************************
//  ProcessFir.cpp
// 
//  FIR�t�B���^
// **********************************************************************


#include "stdafx.h"

#include "IIR_Filter.h"

#include "ProcessFir.h"



ProcessFir::ProcessFir() 
 :ProcessBase(EPT_iir_filter)
{}

ProcessFir::~ProcessFir()
{}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t ProcessFir::showSetDlg()
{
	return 0;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// XML����I�u�W�F�N�g���\�z
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t ProcessFir::loadXml(const rapidxml::xml_node<>* proc_node)
{
	int32_t ack;
	const rapidxml::xml_node<> *node_logic,*child;
	FirFilterfTap<int32_t>	tap;

	// �v���Z�X���`�F�b�N
	if(strcmp(proc_node->name() ,m_ProcNameList[EPT_fir_filter]) != 0)	return -1;

	node_logic = proc_node->first_node("logical_value");
	if(node_logic == nullptr){
		
	}else{
		child = node_logic->first_node("type");
		if(child == nullptr){
			
		}else{

		}
	}

	// XML���烏�C�������擾���āB	// ���C�����͈����ɕK�v�����H
	loadXmlInputAndOutputWire(proc_node ,m_InSignalName ,m_OutSignalName);

	// �_���l


	ack = readTap(proc_node ,"tap_h" ,tap.m_h);
	if(ack == 0){
		m_Filter.putTap(tap);
	}

	return 0;
}
int32_t ProcessFir::saveXml(rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* Child) const
{
	return 0;
}


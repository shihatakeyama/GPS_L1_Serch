// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  dft.cpp
//
//
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *


#include "stdafx.h"

#include "GnrlInt.h"


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// DFT�s��  double
// 
// �Q�l�Fhttps://algorithm.joho.info/signal/c-fourier-transform-power-spectrum/
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t dftf(const float32_t *InData ,float32_t *ReData ,float32_t *ImData ,size_t Len)
{
	size_t n,N = Len;
	size_t k,sumco,sumsum;
	double n2pi,theta,oldtheta; 

    //���������Ƌ��������ɕ����ăt�[���G�ϊ�
    for(n=0; n<N; n++) {
        double re = 0.0;
        double im = 0.0;
		n2pi = 2*M_PI*n/N / 4;
		theta = 0.0;
		oldtheta = 0.0;
		sumco = 0;
		sumsum = 0;
        for(k=0; k<N; k++) {
			theta += n2pi;
            re += InData[k]*cos(n2pi*k);
            im += -InData[k]*sin(n2pi*k);
			sumco++;
/*			if(theta >= 2*M_PI){
				theta -= 2*M_PI;
				ReData[n] += re;
				ImData[n] += im;

				re = 0.0;
				im = 0.0;

				sumsum += sumco;
				sumco = 0;
			}
			*/
			oldtheta = theta;

        }

//		if(sumsum == 0.0)	sumsum = 1.0;

//		ReData[n] *= N/(double)sumsum;
//		ImData[n] *= N/(double)sumsum;

		ReData[n] = re;
		ImData[n] = im;
    }

	return 0;
}

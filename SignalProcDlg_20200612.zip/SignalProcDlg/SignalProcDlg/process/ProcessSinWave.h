// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// ProcessSignWave.h
//
//  Sin�g�𐶐�����B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *


#ifndef	SIGNWAVE_GEN_H
#define	SIGNWAVE_GEN_H

#pragma once

#include "stdafx.h"

#define _USE_MATH_DEFINES
#include "math.h"
#include <vector>

#include "GnrlDefine.h"

#include "SP_define.h"

#include "sin_wave.h"


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �ݒ�l
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
struct SignWaveParam{	// SignWaveGenf �Ŏg�p����B

	int32_t m_Freq;
	int32_t m_Phase;
	int32_t m_Amp;
	int32_t m_FourArithmeticType;
};

struct SignWaveParamStep{

	int32_t m_Freq;
	int32_t m_Phase;
	int32_t m_Amp;
};

struct SignWaveParamEna{

	bool m_Freq;
	bool m_Phase;
	bool m_Amp;
};





#if 0
// Sin�g�p�����[�^�[  ���������� ���u��
struct SignWaveParam{

	int32_t	SampleClk;	// �T���v�����O�N���b�N(���g��)
	int32_t	SignalFreq;	// Sin�g���g��
	CString	InSignalName;
	CString	OutSignalName;
};
#endif


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Sin�g
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
class ProcessSinWave
:public ProcessBase{

public:

	ProcessSinWave();
	virtual ~ProcessSinWave();


	virtual int32_t gen(LineDataSet &Out, LineDataSet &In)
	{
		m_SinGen.gen(Out[0].getSeriesFloat32Arrow() ,In[0].getSeriesFloat32Arrow() ,Out[0].size() );

		return 0;
	}

	virtual RstrFraction fluctuationRate() const
	{
		return RstrFraction();
	}

	// 
	virtual int32_t showSetDlg();


	// XML����I�u�W�F�N�g���\�z
	virtual int32_t loadXml(const rapidxml::xml_node<>* Child);
	virtual int32_t saveXml(rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* ProcList) const;


	int32_t m_Clk;
	SignWaveParam			m_SinParam;
	SignWaveParamStep		m_SinParamStep;
	SignWaveParamEna		m_SinParamEna;
	SignWaveGenf<Float32>	m_SinGen;	
};


#endif // #ifdef  SIGNWAVE_GEN_H


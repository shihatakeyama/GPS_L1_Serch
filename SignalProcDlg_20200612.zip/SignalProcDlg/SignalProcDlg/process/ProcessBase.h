// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  ProcessBase.h
//  
//  �e�폈���̉��n
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *


#ifndef PROCESSBASE_H
#define PROCESSBASE_H


//--#include "stdafx.h"




int32_t findStringListId(const char *PurposeName ,const char *NameList[] ,bool case_sensitive = true);

class ProcessNoise;
class ProcessSinWave;

class ProcessBase{

public:

	// �������
	enum E_ProcessType{
//--		  EPT_none			= -1
		  EPT_noise			= 0
		, EPT_sin_wave		= 1
		, EPT_iir_filter	= 2
		, EPT_fir_filter	= 3
		, EPT_mixer			= 4
		, EPT_num			= 5
	};


	// �v���Z�X�����X�g
	const static char *m_ProcNameList[];

	ProcessBase(enum E_ProcessType ProcType);
	virtual ~ProcessBase() = 0;


	// �M������
	// gen()�R�}���h�́A����������̂ŁA�K�X�I��Ŏg�p
	// 
	virtual int32_t gen(LineDataSet &Out, LineDataSet &In) = 0;
///---	virtual int32_t gen(WireClk &Out, WireClk &In) = 0;


	// �������擾
	virtual RstrFraction fluctuationRate() const = 0;

	// �N���b�N�x���擾
//++	virtual RstrFraction delayRate() const = 0;


	int32_t getTypeId() const		{ return m_ProcType;	}

	// ���X�g�ɕ\�����镶����
	virtual CString getCellText(int32_t Colum) const;


	// �ݒ�_�C�A���O�\��
	virtual int32_t showSetDlg();

	// �����I�u�W�F�N�g�𐶐�
	static ProcessBase *newProcess(enum E_ProcessType ValTypeId);

	// �v���Z�X���X�g�̓��e��GUI�ɔ��f
///---	static int32_t setGui(const std::vector<ProcessBase*>	&List);


	// **** XML�t�@�C���A�N�Z�X�́AProcessBase�N���X�Ŗ����Ă��悢�C������B�B�B ****

	static void clearProcessList(std::vector<ProcessBase*>	&List);

	// �v���Z�X���X�g��XML����ǂݍ���
	static int32_t loadProcessList(std::vector<ProcessBase*>	&List ,const rapidxml::xml_node<>* ProcessXml);
	static int32_t saveProcessList(const std::vector<ProcessBase*> &List ,rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* ProcessXml);
	
	// �e�v���Z�X�̓��e��XML�I�u�W�F�N�g�֓ǂݏ���
	virtual int32_t loadXml(const rapidxml::xml_node<>* Child);
	virtual int32_t saveXml(rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* Child) const;

	int32_t loadXmlInputAndOutputWire(const rapidxml::xml_node<>* BaseNode ,std::vector<std::string> &InWire ,std::vector<std::string> &OutWire);
	int32_t saveXmlInputAndOutputWire(rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* BaseNode ,const std::vector<std::string> &InWire ,const std::vector<std::string> &OutWire) const;

	// rapidxml::xml_node ����l���擾����
	static int32_t readVal(const rapidxml::xml_node<>* BaseNode ,const char *Name ,int32_t &Val);
	static int32_t readVal(const rapidxml::xml_node<>* BaseNode ,const char *Name ,Float32 &Val);

	static int32_t writeVal(rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* BaseNode ,const char *Name ,const int32_t &Val);
	static int32_t writeVal(rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* BaseNode ,const char *Name ,const Float32 &Val);

	static int32_t readValAndStep(const rapidxml::xml_node<>* BaseNode ,const char *Name ,int32_t &Val ,int32_t &Step ,bool &Enable);
	static int32_t readValAndStep(const rapidxml::xml_node<>* BaseNode ,const char *Name ,Float32 &Val ,Float32 &Step ,bool &Enable);
	
	static int32_t writeValAndStep(rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* BaseNode ,const char *Name ,const int32_t &Val ,const int32_t &Step ,const bool &Enable);
	static int32_t writeValAndStep(rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* BaseNode ,const char *Name ,const Float32 &Val ,const Float32 &Step ,const bool &Enable);

	// rapidxml::xml_node ����^�b�v���擾����
	static int32_t readTap(const rapidxml::xml_node<>* BaseNode ,const char *Name ,std::vector<int32_t> &Tap);
	static int32_t readTap(const rapidxml::xml_node<>* BaseNode ,const char *Name ,std::vector<Float32> &Tap);

	static int32_t writeTap(rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* BaseNode ,const char *Name ,const std::vector<int32_t> &Tap);
	static int32_t writeTap(rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* BaseNode ,const char *Name ,const std::vector<Float32> &Tap);

protected:

	enum E_ProcessType	m_ProcType;

		std::vector<std::string>	m_InSignalName;
		std::vector<std::string>	m_OutSignalName;

private:
	ProcessBase();
};


#endif // PROCESSBASE_H


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  random.h
// 
//  �����_��
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

#pragma once

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  �����_���̎퐶��
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
inline void Randm_init()
{
	srand((unsigned)time(NULL));
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  ��l���z
//  �Q�l�F
// http://sdlabo.org/%E4%B8%80%E6%A7%98%E5%88%86%E5%B8%83%E3%81%A8%E6%AD%A3%E8%A6%8F%E5%88%86%E5%B8%83%28%E3%82%AC%E3%82%A6%E3%82%B9%E5%88%86%E5%B8%83%29%E3%81%AE%E3%83%8E%E3%82%A4%E3%82%BA%E3%82%92%E5%87%BA%E5%8A%9B%E3%81%99%E3%82%8BC%2B%2B%E3%81%AE%E3%82%BD%E3%83%BC%E3%82%B9%E3%82%B3%E3%83%BC%E3%83%89.html
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
inline Float64 Randm_uniform()
{
	Float64 ret = (static_cast<Float64>(rand()) + 1.0) / (static_cast<Float64>(RAND_MAX)+2.0);
	return ret;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  ���K���z(�K�E�X���z)
//  Buf
//  Len
//  mu
//  sigma
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
template<typename X>
void Randm_normal(X *Buf ,int32_t Len ,X mu, X sigma)
{
	int32_t i;
	Float64  z;

	for (i = 0; i<Len ; i++){

		z = sqrt(-2.0f * log(Randm_uniform())) * sin(M_PI * 2.0 * Randm_uniform());

		Buf[i] = static_cast<X>(mu + sigma * z);
	}
}
template<typename X>
void Randm_normal(X *OutBuf ,const X *InBuf ,int32_t Len ,X mu, X sigma)
{
	int32_t i;
	Float64  z;

	for (i = 0; i<Len ; i++){

		z = sqrt(-2.0f * log(Randm_uniform())) * sin(M_PI * 2.0 * Randm_uniform());

		Buf[i] = static_cast<X>(mu + sigma * z) + InBuf[i];
	}
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  ProcessFir.h
// 
//  FIR�t�B���^
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

#pragma once

#include "stdafx.h"


class ProcessFir
:public ProcessBase{


	ProcessFir();
	virtual ~ProcessFir();


	virtual int32_t gen(LineDataSet &Out, LineDataSet &In)
	{
		return 0;
	}

	virtual RstrFraction fluctuationRate() const
	{
		return RstrFraction();
	}

	// 
	virtual int32_t showSetDlg();

	// XML����I�u�W�F�N�g���\�z
	virtual int32_t loadXml(const rapidxml::xml_node<>* Child);
	virtual int32_t saveXml(rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* Child) const;

private:

	FirFilterf<int32_t,int64_t>		m_Filter;
};
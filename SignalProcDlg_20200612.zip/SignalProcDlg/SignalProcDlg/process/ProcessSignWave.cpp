// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  ProcessSignWave.cpp
//  
//  Sin�g�𐶐�����B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

#include "stdafx.h"

#include "sin_wave.h"
#include "SinWaveGenDlg.h"


const static Float32 gcircle = static_cast<Float32>((M_PI*2)/4294967296.0f);

ProcessSinWave::ProcessSinWave()
:ProcessBase(EPT_sin_wave)
{}

ProcessSinWave::~ProcessSinWave()
{}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t ProcessSinWave::showSetDlg()
{
	SinWaveGenDlg dlg;

	dlg.m_SampleClk = m_Clk;

	dlg.m_Freq	= m_SinParam.m_Freq;
	dlg.m_Phase	= m_SinParam.m_Phase;
	dlg.m_Amp	= m_SinParam.m_Amp;

	dlg.m_FreqS	= m_SinParamStep.m_Freq;
	dlg.m_PhaseS= m_SinParamStep.m_Phase;
	dlg.m_AmpS	= m_SinParamStep.m_Amp;

	dlg.m_ChkFreq = m_SinParamEna.m_Freq;
	dlg.m_ChkPhase = m_SinParamEna.m_Phase;
	dlg.m_ChkAmp = m_SinParamEna.m_Amp;

	if(!m_InSignalName.empty() && !m_InSignalName[0].empty()){
		dlg.m_InputSignal_0 = m_InSignalName[0].c_str();
	}
	if(!m_OutSignalName.empty() && !m_OutSignalName[0].empty()){
		dlg.m_OutputSignal_0= m_OutSignalName[0].c_str();
	}

	if(dlg.DoModal() == IDOK){

		m_SinParamStep.m_Freq	= dlg.m_FreqS;
		m_SinParamStep.m_Phase	= dlg.m_PhaseS;
		m_SinParamStep.m_Amp	= dlg.m_AmpS;

		m_SinParamEna.m_Freq	= dlg.m_ChkFreq;
		m_SinParamEna.m_Phase	= dlg.m_ChkPhase;
		m_SinParamEna.m_Amp		= dlg.m_ChkAmp;
		{
			CT2A ascii(dlg.m_InputSignal_0);
			m_InSignalName[0]	= ascii.m_psz;
		}
		{
			CT2A ascii(dlg.m_OutputSignal_0);
			m_OutSignalName[0]	= ascii.m_psz;
		}
	}

	return 0;
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// XML����I�u�W�F�N�g���\�z
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t ProcessSinWave::loadXml(const rapidxml::xml_node<>* proc_node)
{
	int32_t index;
	const rapidxml::xml_node<>* node_tmp;
	rapidxml::valconv<> xvc(proc_node);

	if(strcmp(proc_node->name() ,m_ProcNameList[EPT_sin_wave]) != 0)	return -1;

	rapidxml::xml_attribute<> *atitr = proc_node->first_attribute("calculation");//first_attribute();
	
	// �l�����Z
//--	atitr = atitr->next_attribute("calculation");
	if(atitr == nullptr){
		index = EFAT_new;
	}else{
		index	= findStringListId(atitr->name() ,gFourArithmetic);
		if(index < 0)	index = EFAT_new;
	}

	m_SinParam.m_FourArithmeticType	=index;

	// XML���烏�C�������擾���āB	// ���C�����͈����ɕK�v�����H
	loadXmlInputAndOutputWire(proc_node ,m_InSignalName ,m_OutSignalName);

	// �����v���Z�X�ԂŃ��C�����֘A�t����B	
	readVal(proc_node ,"clk" ,m_Clk);

	readValAndStep(proc_node ,"freq" ,m_SinParam.m_Freq ,m_SinParamStep.m_Freq ,m_SinParamEna.m_Freq);

	readValAndStep(proc_node ,"phase" ,m_SinParam.m_Phase ,m_SinParamStep.m_Phase ,m_SinParamEna.m_Phase);

	readValAndStep(proc_node ,"amp" ,m_SinParam.m_Amp ,m_SinParamStep.m_Amp ,m_SinParamEna.m_Amp);

	return 0;
}

int32_t ProcessSinWave::saveXml(rapidxml::xml_document<> &Doc ,rapidxml::xml_node<>* ProcList) const
{
	rapidxml::xml_node<> *proc = Doc.allocate_node(rapidxml::node_element ,"sin_wave");
	rapidxml::xml_attribute<>* attr_calc;

	ProcList->append_node(proc);

	attr_calc = Doc.allocate_attribute("calculation" ,gFourArithmetic[m_SinParam.m_FourArithmeticType]);
	proc->append_attribute(attr_calc);

	// XML���烏�C�������擾���āB	// ���C�����͈����ɕK�v�����H
	saveXmlInputAndOutputWire(Doc ,proc ,m_InSignalName ,m_OutSignalName);

	// �����v���Z�X�ԂŃ��C�����֘A�t����B	
	writeVal(Doc ,proc ,"clk" ,m_Clk);

	writeValAndStep(Doc ,proc ,"freq" ,m_SinParam.m_Freq ,m_SinParamStep.m_Freq ,m_SinParamEna.m_Freq);

//	for(const auto &itr : List){
//		proc = Doc.allocate_node(rapidxml::node_element);

//		itr->write
//			wires = Doc.allocate_node(rapidxml::node_element, "input_wire");	// , "LOL"
//	}

	return 0;
}

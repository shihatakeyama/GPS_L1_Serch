// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// rms.h
//
// 2�敽�ς��v�Z���܂��B
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

#pragma once



// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
template<typename X ,typename ACCUM>
ACCUM rmsf(const X *Buf ,int32_t Len)
{
	ACCUM acum = 0;
	int32_t i;
	const X *end = Buf + Len;

	while(Buf != end){
		acum += *Buf * *Buf;

		Buf++;
	}

	acum /= Len;

	return sqrt(acum);
}


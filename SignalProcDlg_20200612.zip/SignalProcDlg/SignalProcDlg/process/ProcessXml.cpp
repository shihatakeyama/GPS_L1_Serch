// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// ProcessXml.cpp
//
//
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

#include <fstream>
#include <iostream>
#include <string>
#include <cstring>

#include "stdafx.h"

#include <vector>

#include "GnrlDefine.h"
#include "GnrlCharset.h"
#include "SP_define.h"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// XML�t�@�C������ǂ��܂��B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t parseProcessXml(std::vector<ProcessBase*> &List ,rapidxml::xml_document<> &Doc)
{
	rapidxml::xml_node<> *node = Doc.first_node("circit");
	rapidxml::xml_node<> *child,*gran;
	const char *pp;

	if(node == nullptr)		throw std::exception("circit does not exist in xml tag");

	child = node->first_node("title");
	if(child == nullptr)	throw std::exception("title does not exist in xml tag");
	gComment = child->value();

	
	child	= node->first_node("common");
	if(child == nullptr)	throw std::exception("common does not exist in xml tag");

	{
		gran	= child->first_node("variabletype");
		if(gran == nullptr)	throw std::exception("variabletype does not exist in xml tag");
	
		gran	= child->first_node("timeunit");
		if(gran == nullptr)	throw std::exception("timeunit does not exist in xml tag");
	}

	child = node->first_node("processlist");
	if(child == nullptr)	throw std::exception("processlist does not exist in xml tag");

	ProcessBase::loadProcessList(List ,child);

	return 0;
}

int32_t combinationProcessXml(std::vector<ProcessBase*> &List ,rapidxml::xml_document<> &Doc)
{
	rapidxml::xml_node<> *node = Doc.allocate_node(rapidxml::node_element ,"circit");
	rapidxml::xml_node<> *common,*child,*gran;

	Doc.append_node(node);

	child = Doc.allocate_node(rapidxml::node_element ,"title",gComment.c_str());
	node->append_node(child);

	child = Doc.allocate_node(rapidxml::node_element ,"common");
	node->append_node(child);

	{
	
	
	}

	child = Doc.allocate_node(rapidxml::node_element ,"processlist");
	node->append_node(child);

	ProcessBase::saveProcessList(List ,Doc ,child);

	return 0;
}

#include "rapidxml_print.hpp"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  �����p�����[�^��ǂݍ��݂܂��B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t loadProcessParam(std::vector<ProcessBase*> &List ,const Nchar *FilePath)
{
//--	string xml = R"(<function include="<cstdio>"><return type="int"/>printf</function>)" "\0"; // '\0'�I�[��ۏ؂���
	rapidxml::xml_document<> doc;
    char *str;

#if 0
	std::ifstream ifs(FilePath, ios::in | ios::binary );	// �o�C�i�����[�h�łɂ��Ȃ��ƁA�ǂݍ��񂾃t�@�C���T�C�Y������Ȃ��Ȃ�B
    if (ifs.fail()){
        std::cerr << "���s" << std::endl;
        return -1;
    }
    int begin = static_cast<int>(ifs.tellg());
    ifs.seekg(0, ifs.end);
    // �ꉞ�͈̓`�F�b�N���ׂ������ǁc�c
    int end = static_cast<int>(ifs.tellg());
    int size = end - begin;
    ifs.clear();		 // ������clear����EOF�t���O������
    ifs.seekg(0, ifs.beg);
    str = new char[size + 1];
    str[size] = '\0';	 // �O�̂��ߖ�����NULL������
    ifs.read(str, size);
#else
	::readMalloc(&str ,FilePath);
	if(str==nullptr){
		return -3;
	}
#endif
	doc.parse<0>(str);

	parseProcessXml(List ,doc);

    delete[] str;

	return 0;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  �����p�����[�^���������݂܂��B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t saveProcessParam(std::vector<ProcessBase*> &List ,const Nchar *FilePath)
{
	rapidxml::xml_document<> doc;

	combinationProcessXml(List ,doc);

	std::ofstream outFile(FilePath);
	if(outFile.fail()){
		std::string str = "file not open ";
//--		str += FilePath;
		throw std::runtime_error(str);
	}

    outFile << doc;

	return 0;
}


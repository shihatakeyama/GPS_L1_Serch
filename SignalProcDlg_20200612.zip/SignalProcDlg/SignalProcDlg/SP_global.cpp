// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// SP_Global.cpp
//
//
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

#include "stdafx.h"

#include <vector>

#include "GnrlDefine.h"
#include "GnrlCharset.h"

//--#include "Random.h"
//--#include "SP_define.h"


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
std::vector<Float32>	gSignalFloat[8];
std::vector<int32_t>	gSignalInt[8];
LineDataSet				gGraphTest01;
GLThread				gGLThread;

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �ʐM�֘A
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
LineDataSet				gGraphCsv;
GnrlCom					gCom;
ComRecvThread			gComRecvThread;

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �v���Z�X�֘A�f�[�^
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
st_CsvParam					gCsvParam;
std::string					gComment;
std::vector<ProcessBase*>	gProcessList;	// �����ꗗ

const char *gFourArithmetic[]	= {"addition","subtraction","multiplication","division",nullptr};	// ,"none"	�~�L�T�[�Ŏg�p
const char *gFilterTypeText[]	= {"lo_pass" ,"band_pass" ,"hi_pass" ,nullptr};

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// PurposeName�ƈ�v���镶����� NameList[]�̒�����T���܂��B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t findStringListId(const char *PurposeName ,const char *NameList[] ,bool case_sensitive)
{
	int32_t itr = 0;
	std::size_t	purname_size = rapidxml::internal::measure(PurposeName);
	std::size_t	listname_size;

	while(*NameList){
		listname_size	= rapidxml::internal::measure(*NameList);
		if(rapidxml::internal::compare(*NameList, listname_size, PurposeName, purname_size, case_sensitive)){
			return itr;
		}

		NameList++;
		itr++;
	}

	return -1;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �f�[�^�C�j�V�����C�Y
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t initData()
{
	SeriesI1	i1;
	int32_t		val;
	Float32		maxv;
	SignWaveGenf<Float32> swg;
	swg.putFreq1Clk(freq1Clk(20,1000));

	gGraphCsv.addSeries(SeriesBase::ENE_int32_t);
	gGraphTest01.addSeries(SeriesBase::ENE_int32_t);

	SeriesBase::Seriesint32_t *sg1 = gGraphCsv.getSeriesInt32(0);
	sg1->resize(1024);

	SeriesBase::Seriesint32_t *st1 = gGraphTest01.getSeriesInt32(0);
	st1->resize(1024);

	Randm_normal<int32_t>(&(*sg1)[0], sg1->size(), 10, 20);

	//swg.gen(&(*st1)[0], &(*sg1)[0] ,st1->size());


//	s1->minAndMaxFloat32( min,max);
//	gGraphCsv.minAndMaxFloat32(minv ,maxv);

/*	gGraphDataI1.push_back(SeriesI1());

	SeriesI1	&i12 = gGraphDataI1[0];

	std::vector<SeriesI1>::iterator minIt = *std::min_element(i12.begin(), i12.end());
	*/

//	auto i = std::minmax_element(v.begin(), v.end());

//	numpy::hanning(buf1 ,31);


	return 0;
}

#if 0

	s1->push_back(5);
	s1->push_back(2);
	s1->push_back(8);

	s1->push_back(15);
	s1->push_back(12);
	s1->push_back(18);

	s1->push_back(5);
	s1->push_back(2);
	s1->push_back(8);

	s1->push_back(15);
	s1->push_back(12);
	s1->push_back(18);
	
#endif


﻿// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//
// SignalProcDlgDlg.cpp : 実装ファイル
//
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

#include "stdafx.h"

#include <stdint.h>
#include "afxdialogex.h"
#include "SignalProcDlg.h"
#include "CudaInfoDlg.h"
#include "ComboInListCtrl.h"
#include "ListCtrlComFormat.h"
#include "ComFormatSetDlg.h"

#include "GnrlDefine.h"
#include "GnrlCharset.h"
#include "GnrlFilePath.h"

#include "SignalProcDlgDlg.h"
#include "TapDlg.h"
#include ".\com\ComSet.h"

#include "SP_Define.h"

#include "L1CaCode.h"
#include "GTS_Global.h"


CComFormatDlg gComFormatDlg;

using namespace Gdiplus;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

int32_t initData();

int32_t Unt32_xxTest();
int32_t Float32_xxTest();

int32_t saveCsvSet(st_CsvParam &CsvParam);
int32_t loadCsvSet(st_CsvParam &CsvParam);
static BOOL WritePrivateProfileInt(const LPCTSTR lpAppName, const LPCTSTR lpKeyName, int Val, const LPCTSTR lpFileName);
void insertProcess(CListCtrlProc &ListCtrl ,const ProcessBase &Process ,int32_t nItem);

int32_t GTS_CorrTest(LineDataSet &Lds);
int32_t GTS_FFT_Test(LineDataSet &Lds);
void L1makeCaCodelist();

const CString CSignalProcDlgDlg::mInputSelStr[CSignalProcDlgDlg::EIS_num] = {N_T("外部入力") ,N_T("内部生成") };

// アプリケーションのバージョン情報に使われる CAboutDlg ダイアログ

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// ダイアログ データ
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV サポート

// 実装
protected:
	DECLARE_MESSAGE_MAP()
public:
//	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
//	afx_msg void OnKillFocus(CWnd* pNewWnd);
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
//	ON_WM_MOUSEMOVE()
//	ON_WM_KILLFOCUS()
END_MESSAGE_MAP()


// CSignalProcDlgDlg ダイアログ



CSignalProcDlgDlg::CSignalProcDlgDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CSignalProcDlgDlg::IDD, pParent)
	, m_hIcon(AfxGetApp()->LoadIcon(IDR_MAINFRAME))
	, m_DataStartLine(1)
	, m_Graph()
	, m_DataDirection(0)
	, mCaptureMode(FALSE)
	, m_InputFreq(1000)
	, m_OutputPoint(1000)
	, m_ChkInput(FALSE)
	, m_ChkOutput(FALSE)
	, m_StatiBegin(-100)
	, m_StatiN(200)
{
//	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSignalProcDlgDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	//  DDV_MinMaxInt(pDX, m_LineOffset, 1, 100000);
	/*	DDX_Text(pDX, IDC_EDIT_SEGM1, m_Segm1);
		DDV_MinMaxInt(pDX, m_Segm1, 1, 100000);
		DDX_Text(pDX, IDC_EDIT_SEGM2, m_Segm2);
		DDV_MinMaxInt(pDX, m_Segm2, 1, 100000);
		DDX_Check(pDX, IDC_CHECK_USE1, m_Use1);
		DDX_Radio(pDX, IDC_RADIO_DEC1, m_Dec1);
		DDV_MinMaxInt(pDX, m_Dec1, 0, 2);
		DDX_Radio(pDX, IDC_RADIO_DEC2, m_Dec2);
		DDV_MinMaxInt(pDX, m_Dec2, 0, 2);
		//--	DDX_Check(pDX, IDC_CHECK_USE2, m_Use2);
		DDX_Text(pDX, IDC_EDIT_DATA_START_LINE, m_DataStartLine);
		DDV_MinMaxInt(pDX, m_DataStartLine, 1, 100000);
		DDX_Radio(pDX, IDC_RADIO_TATE, m_DataDirection);
		DDV_MinMaxInt(pDX, m_DataDirection, 0, 1);
		DDX_Radio(pDX, IDC_RADIO_TAB, m_Separator);
		DDV_MinMaxInt(pDX, m_Separator, 0, 2);
		*/
	DDX_Control(pDX, IDC_LIST2, m_listctrl);
	DDX_Control(pDX, IDC_COMBO_COMPORT_SEL, m_PortNo);
	DDX_Control(pDX, IDC_BUTTON_OPENCOM, m_ButtonComOpen);
	DDX_Control(pDX, IDC_BUTTON_COMSET, m_ButtonComSet);
	DDX_Control(pDX, IDC_COMBO_INPUT_SELECT, m_ImputSelect);
	DDX_Text(pDX, IDC_EDIT_INPUT_FREQ, m_InputFreq);
	DDX_Text(pDX, IDC_EDIT_OUTPUT_N, m_OutputPoint);
	DDX_Check(pDX, IDC_CHECK_INPUT, m_ChkInput);
	DDX_Check(pDX, IDC_CHECK_STATISTICS, m_ChkOutput);
	DDX_Text(pDX, IDC_EDIT_STATI_BEGIN, m_StatiBegin);
	DDV_MinMaxInt(pDX, m_StatiBegin, -1000000, 1000000);
	DDX_Text(pDX, IDC_EDIT_STATI_N, m_StatiN);
	DDV_MinMaxInt(pDX, m_StatiN, 1, 2000000);
}

BEGIN_MESSAGE_MAP(CSignalProcDlgDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_CHECK1, &CSignalProcDlgDlg::OnBnClickedCheck1)
	ON_BN_CLICKED(IDC_BUTTON_FOPEN, &CSignalProcDlgDlg::OnBnClickedButtonFopen)
	ON_BN_CLICKED(IDC_BUTTON_GEN, &CSignalProcDlgDlg::OnBnClickedButtonGen)
	ON_BN_CLICKED(IDC_BUTTON_CUDA_INFO, &CSignalProcDlgDlg::OnBnClickedButtonCudaInfo)
	ON_WM_DROPFILES()
	ON_BN_CLICKED(IDC_BUTTON2, &CSignalProcDlgDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDOK, &CSignalProcDlgDlg::OnBnClickedOk)
	ON_WM_LBUTTONDOWN()

	// 独自のメッセージ送信 追加
	ON_MESSAGE(WM_COM_RECV_DATA, OnRecvCom)

	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDBLCLK()
	ON_BN_CLICKED(IDC_BUTTON_OPENCOM, &CSignalProcDlgDlg::OnBnClickedButtoncomopen)
	ON_WM_DESTROY()
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_BUTTON_COMSET, &CSignalProcDlgDlg::OnBnClickedButtonComset)
	ON_BN_CLICKED(IDC_BUTTON_PROCESS_ADD, &CSignalProcDlgDlg::OnBnClickedButtonProcessAdd)

	// 各種設定ダイアログ
	ON_COMMAND(ID_COM_FORMAT,			&CSignalProcDlgDlg::OnComFormatDlg)
	ON_COMMAND(ID_ADD_PROCESS_NOISE,	&CSignalProcDlgDlg::OnAddProcessNoise)
	ON_COMMAND(ID_ADD_PROCESS_SINWAVE,	&CSignalProcDlgDlg::OnAddProcessSinwave)
	ON_COMMAND(ID_ADD_PROCESS_FIR,		&CSignalProcDlgDlg::OnAddProcessFir)
	ON_COMMAND(ID_ADD_PROCESS_IIR,		&CSignalProcDlgDlg::OnAddProcessIir)
	ON_COMMAND(ID_ADD_PROCESS_AVE,		&CSignalProcDlgDlg::OnAddProcessAve)
	ON_COMMAND(ID_PROCESS_FFT,			&CSignalProcDlgDlg::OnAddProcessFft)

	ON_BN_CLICKED(IDC_BUTTON_PROC_LIST_OPEN, &CSignalProcDlgDlg::OnBnClickedButtonProcListOpen)
	ON_BN_CLICKED(IDC_CHECK_INPUT,		&CSignalProcDlgDlg::OnBnClickedCheckInput)
	ON_BN_CLICKED(IDC_BUTTON_PROC_LIST_SAVE, &CSignalProcDlgDlg::OnBnClickedButtonProcListSave)
	ON_BN_CLICKED(IDC_BUTTON_PROCESS_UP, &CSignalProcDlgDlg::OnBnClickedButtonProcessUp)
	ON_BN_CLICKED(IDC_BUTTON_PROCESS_DOWN, &CSignalProcDlgDlg::OnBnClickedButtonProcessDown)
	ON_BN_CLICKED(IDC_BUTTON_GL, &CSignalProcDlgDlg::OnBnClickedButtonGl)
END_MESSAGE_MAP()


// CSignalProcDlgDlg メッセージ ハンドラー

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// ステータスバー
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
static UINT indicators[] =
{
	ID_SEPARATOR,           // ステータス ライン インジケータ
	ID_INDICATOR_KANA,
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
	ID_INDICATOR_ORG,	//Stringリソースで作成したID
};
void setStatusBar(CSignalProcDlgDlg &Window)
{
	int nHeight = 19;
	CRect rectClient;
	// ステータスバー

	int nStatusHeight = 0;
	if (Window.m_StatusBar.GetSafeHwnd()){// コントロールの有効性をチェックします。

		CRect rectSt;
		Window.m_StatusBar.GetWindowRect(rectSt);
		// 現在のクライアントウィンドウのサイズを取得
		Window.GetClientRect(&rectClient);
		// 高さを維持しながらサイズを変更する
		int nBtm = nHeight;	//	rectSt.bottom - rectSt.top;
		rectSt.top = rectClient.bottom - nBtm;
		rectSt.bottom = rectSt.top + nBtm;
		rectSt.left = rectClient.left;
		rectSt.right = rectClient.right;
		Window.m_StatusBar.MoveWindow(rectSt);
		nStatusHeight = rectSt.Height();
	}
}

BOOL CSignalProcDlgDlg::OnInitDialog()
{
	int	i;

	CDialogEx::OnInitDialog();

	// "バージョン情報..." メニューをシステム メニューに追加します。

	// IDM_ABOUTBOX は、システム コマンドの範囲内になければなりません。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// このダイアログのアイコンを設定します。アプリケーションのメイン ウィンドウがダイアログでない場合、
	//  Framework は、この設定を自動的に行います。
	SetIcon(m_hIcon, TRUE);			// 大きいアイコンの設定
	SetIcon(m_hIcon, FALSE);		// 小さいアイコンの設定


	// **** 入力選択 ****
	for (i = 0; i<EIS_num; i++){
		m_ImputSelect.InsertString(i, mInputSelStr[i]);
	}
	m_ImputSelect.SetCurSel(EIS_internal);

	m_Graph.initDlgItem(this, IDC_STCHARTCONTAINER1);

	// **** ステータスバー ****
	// ステータスバーを作成・付加
	m_StatusBar.Create(this);
	m_StatusBar.SetIndicators(indicators, sizeof(indicators) / sizeof(UINT));

	setStatusBar(*this);

	gComRecvThread.setWnd(this);

	gCom.loadParameter();
	GnrlComList::initComList();
	GnrlComList::searchComList();
	GnrlComList::setGuiComList(m_PortNo, gCom.getPortNo());

	loadDlgSet();
	loadCsvSet(gCsvParam);
//	setGuiCsvSet(gCsvParam);

#if 0
  CPaintDC dc(this);                              // Device context for painting
  Graphics gr(dc.m_hDC);                          // Graphics to paint

  Rect rGdi;
  gr.GetVisibleClipBounds(&rGdi);                 // The same as the clip rect

  Bitmap clBmp(rGdi.Width, rGdi.Height);          // Mem bitmap
  Graphics* grPtr = Graphics::FromImage(&clBmp);  // As memDC
#endif

  	Randm_init();
	initData();

	GTS_CorrTest(m_Graph.dataSet());	//	LineDataSet
//	GTS_FFT_Test(m_Graph.dataSet());
	CStringArray &serneme = m_Graph.seriesName();
	serneme.Add(N_T("vector"));

///	gGLThread.start();

	matchGraph();		// 縮尺合わせ

#if 1	// 初期表示
	// リストコントロール 処理
	m_imglstList.Create(IDB_BITMAP_LIST, 20, 1, (COLORREF)(0x00000000));
	m_listctrl.SetImageList(&m_imglstList, LVSIL_SMALL);
	m_listctrl.InsertColumn(0, _T("Process"), LVCFMT_LEFT, 100);
	m_listctrl.InsertColumn(1, _T("InSignal"), LVCFMT_LEFT, 100);
	m_listctrl.InsertColumn(2, _T("OutSignal"), LVCFMT_LEFT, 100);
	m_listctrl.InsertColumn(3, _T("Info"), LVCFMT_LEFT, 250);
	m_listctrl.SetExtendedStyle( LVS_ICON | LVS_SHOWSELALWAYS | LVS_OWNERDATA | LVS_EX_HEADERDRAGDROP | LVS_EX_GRIDLINES);	// 追加！！ LVS_OWNERDATAを指定おかないとSetItemText()でエラーになる。
	for (int i = 0; i < 10; i++){
		CString strText;
		for (int j = 0; j < 3; j++){
			strText.Format(_T("Data[%d,%d]"), i + 1, j + 1);
			if (j == 0)
				m_listctrl.InsertItem(i, strText);
			else
				m_listctrl.SetItemText(i, j, strText);
		}
		m_listctrl.SetItem(i, 0, LVIF_IMAGE, NULL, i % 2, 0, 0, 0);	//
	}
#endif

	return TRUE;  // フォーカスをコントロールに設定した場合を除き、TRUE を返します。
}


void CSignalProcDlgDlg::OnDestroy()
{
	CDialogEx::OnDestroy();

	saveDlgSet();
	GnrlComList::clearComList();	// やらないとメモリリークする。
	m_PortNo.Clear();

	ProcessBase::clearProcessList(gProcessList);

}

void CSignalProcDlgDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// ダイアログに最小化ボタンを追加する場合、アイコンを描画するための
//  下のコードが必要です。ドキュメント/ビュー モデルを使う MFC アプリケーションの場合、
//  これは、Framework によって自動的に設定されます。

void CSignalProcDlgDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 描画のデバイス コンテキスト

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// クライアントの四角形領域内の中央
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// アイコンの描画
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}

	drawGraph();
}

// ユーザーが最小化したウィンドウをドラッグしているときに表示するカーソルを取得するために、
//  システムがこの関数を呼び出します。
HCURSOR CSignalProcDlgDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CSignalProcDlgDlg::OnBnClickedCheck1()
{
	// TODO: ここにコントロール通知ハンドラー コードを追加します。
}

// **********************************************************************
//  OK押された
// **********************************************************************
void CSignalProcDlgDlg::OnBnClickedOk()
{
//	getGuiCsvSet(gCsvParam);
	saveCsvSet(gCsvParam);

	if(::GetFocus() == ::GetDlgItem(m_hWnd ,IDOK)){
		CDialogEx::OnOK();	// Enterで閉じさせない。
	}
}



static BOOL WritePrivateProfileInt(const LPCTSTR lpAppName, const LPCTSTR lpKeyName, int Val, const LPCTSTR lpFileName)
{
	Nchar	str[32];

	Nswprintf_s(str,32 , N_T("%d"), Val);

	return ::WritePrivateProfileString(lpAppName, lpKeyName, str, lpFileName);
}

// **********************************************************************
//  CSVファイルの設定を読み込む
// **********************************************************************
int32_t CSignalProcDlgDlg::saveDlgSet()
{
	Nchar	filename[MAX_PATH];
	Nchar	sectionbuf[256];
	int32_t	ack;

	ack = GnrlFilepath::getModuleAttachmentFilePath(filename, MAX_PATH ,N_T("SignalProc.ini"));
	if(ack <= 0){
		return -3;
	}

	UpdateData(TRUE);

	WritePrivateProfileInt(sectionbuf, N_T("ChkInput")	, m_ChkInput, filename);
	WritePrivateProfileInt(sectionbuf, N_T("ChkOutput")	, m_ChkOutput, filename);


	return 0;
}

int32_t saveCsvSet(st_CsvParam &CsvParam)
{
	Nchar	filename[MAX_PATH];
	Nchar	sectionbuf[256];
	Nchar	tmp[256];
	int32_t	i;
	int32_t	ack;

	ack = GnrlFilepath::getModuleAttachmentFilePath(filename, MAX_PATH ,N_T("CsvParam.ini"));
	if(ack <= 0){
		return -3;
	}
	Nstrcpy_s(sectionbuf ,256 ,N_T("common"));

	WritePrivateProfileInt(sectionbuf, N_T("DataDirection")	, CsvParam.DataDirection, filename);
	WritePrivateProfileInt(sectionbuf, N_T("StartLine")		, CsvParam.StartLine	, filename);
	WritePrivateProfileInt(sectionbuf, N_T("OutputPoint")		, CsvParam.OutputPoint	, filename);

	WritePrivateProfileInt(sectionbuf, N_T("SeparateChar")	, CsvParam.getSeparateChar(), filename);
	WritePrivateProfileInt(sectionbuf, N_T("Length")		, CsvParam.Size			, filename);

	for(i=0;i<MAX_CSV_ELEM;i++){
		
		Nsprintf(sectionbuf ,N_T("series%02d") ,i);

		WritePrivateProfileInt(sectionbuf, N_T("Enable"), CsvParam.Enable[i]			, filename);
		WritePrivateProfileInt(sectionbuf, N_T("SeparatePos"), CsvParam.SeparatePos[i]	, filename);
		WritePrivateProfileInt(sectionbuf, N_T("NumEncType"), CsvParam.NumEncType[i]	, filename);
	}
	return 0;
}
int32_t CSignalProcDlgDlg::loadDlgSet()
{
	Nchar	filename[MAX_PATH];
	Nchar	sectionbuf[256];
	int32_t	ack;

	ack = GnrlFilepath::getModuleAttachmentFilePath(filename, MAX_PATH ,N_T("SignalProc.ini"));
	if(ack <= 0){
		return -3;
	}

	m_ChkInput = ::GetPrivateProfileInt(sectionbuf, N_T("ChkInput")	,0 ,filename);
	m_ChkOutput = ::GetPrivateProfileInt(sectionbuf, N_T("ChkOutput")	,0 ,filename);

	UpdateData(FALSE);

	return 0;
}

int32_t loadCsvSet(st_CsvParam &CsvParam)
{
	Nchar	filename[MAX_PATH];
	Nchar	sectionbuf[256];
	int32_t	i;
	int32_t	ack;

	memset(&CsvParam ,0 ,sizeof(CsvParam));

	ack = GnrlFilepath::getModuleAttachmentFilePath(filename, MAX_PATH ,N_T("CsvParam.ini"));
	if(ack <= 0){
		return -3;
	}

	Nstrcpy_s(sectionbuf ,256 ,N_T("common"));

	CsvParam.DataDirection	= ::GetPrivateProfileInt(sectionbuf, N_T("DataDirection")	,0 ,filename);
	CsvParam.StartLine		= ::GetPrivateProfileInt(sectionbuf, N_T("StartLine")		,1 ,filename);
	CsvParam.OutputPoint	= ::GetPrivateProfileInt(sectionbuf, N_T("OutputPoint")		,256, filename);
	CsvParam.setSeparateChar(::GetPrivateProfileInt(sectionbuf , N_T("SeparateChar")	,1 ,filename));
	CsvParam.Size			= ::GetPrivateProfileInt(sectionbuf, N_T("Length")			,0 ,filename);	// エレメント個数

	for(i=0;i<MAX_CSV_ELEM;i++){

		Nsprintf(sectionbuf ,N_T("series%02d") ,i);

		CsvParam.Enable[i]		= ::GetPrivateProfileInt(sectionbuf, N_T("Enable")		, 0, filename);
		CsvParam.SeparatePos[i] = ::GetPrivateProfileInt(sectionbuf, N_T("SeparatePos")	, 1, filename);
		CsvParam.NumEncType[i]	= ::GetPrivateProfileInt(sectionbuf, N_T("NumEncType")	, 0, filename);
	}

	return 0;
}
#if 0
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// GUIの取得と表示行う
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t CSignalProcDlgDlg::getGuiCsvSet(st_CsvParam &CsvParam)
{
	UpdateData(TRUE);

	CsvParam.DataDirection	= m_DataDirection;
	CsvParam.StartLine		= max(1 ,m_DataStartLine)-1;
	CsvParam.OutputPoint	= max(1, m_OutputPoint) - 1;
	CsvParam.setSeparateChar(m_Separator);
	CsvParam.Size			= 2;

	CsvParam.Enable[0]		= m_Use1;
	CsvParam.Enable[1]		= m_Use2;

	CsvParam.SeparatePos[0] = max(1 ,m_Segm1)-1;
	CsvParam.SeparatePos[1] = max(1 ,m_Segm2)-1;

	CsvParam.NumEncType[0]	= m_Dec1;
	CsvParam.NumEncType[1]	= m_Dec2;

	return 0;
}
int32_t CSignalProcDlgDlg::setGuiCsvSet(const st_CsvParam &CsvParam)
{
	m_DataDirection		= CsvParam.DataDirection;
	m_DataStartLine		= CsvParam.StartLine+1;
	m_OutputPoint		= CsvParam.OutputPoint + 1;
	m_Separator			= CsvParam.getSeparateChar();

	m_Use1				= CsvParam.Enable[0];
	m_Use2				= CsvParam.Enable[1];

	m_Segm1				= CsvParam.SeparatePos[0]+1;
	m_Segm2				= CsvParam.SeparatePos[1]+1;

	m_Dec1				= CsvParam.NumEncType[0];
	m_Dec2				= CsvParam.NumEncType[1];

	UpdateData(FALSE);

	return 0;
}
#endif

#include "IIR_Filter.h"
IirFilter<Float32,Float64> gIirFilter;

// **********************************************************************
//  グラフを描画する。(一面)
// **********************************************************************
void CSignalProcDlgDlg::drawGraph()
{
#if 0
	SeriesBase *ser = gGraphCsv.getElement(0);

	if(ser){
//--		m_Graph.drawLine(*ser);
	}else{
		m_Graph.drawGrid();
	}
#else
	m_Graph.onPaint();
#endif
}

int CSignalProcDlgDlg::matchGraph()
{
	SeriesBase *entry = gGraphCsv.getElement(0);

	if (entry){
		m_Graph.setViewAreaX(0.0f, m_OutputPoint);
		m_Graph.setViewAreaY();	// *entry
		m_Graph.autoXGridSpacing();
		m_Graph.autoYGridSpacing();
	}

	return 0;
}


// **********************************************************************
//  ファイルオープンボタン押された。
// **********************************************************************
void CSignalProcDlgDlg::OnBnClickedButtonFopen()
{
	CFileDialog dlgFile(TRUE);
	CString fname_line,filepath;
	const int c_cMaxFiles = 100;
	const int c_cbBuffSize = (c_cMaxFiles * (MAX_PATH + 1)) + 1;

//	getGuiCsvSet(gCsvParam);
//	saveCsvSet(gCsvParam);

	OPENFILENAME &ofn = dlgFile.GetOFN();
	ofn.lpstrTitle = _T("ファイルの選択");
	ofn.lpstrFile = fname_line.GetBuffer(c_cbBuffSize);
	ofn.nMaxFile = c_cMaxFiles;
	ofn.lpstrFilter = _T("All Files\0*.*\0CSV Files\0*.csv\0Log Files\0*.log\0");
	ofn.Flags |= OFN_ALLOWMULTISELECT | OFN_SHOWHELP; 

	if(dlgFile.DoModal()==IDOK){

		POSITION pos = dlgFile.GetStartPosition();
		while(pos)
		{
			filepath	= dlgFile.GetNextPathName(pos);

			readCsv(gGraphCsv ,filepath ,gCsvParam);

			SeriesBase *ser = gGraphCsv.getElement(0);

			if(ser){
				m_Graph.setViewAreaY(*ser);
				m_Graph.setYGridNum(8);
				m_Graph.setViewAreaXEntrySize(*ser);
				m_Graph.setXGridNum(8);

				m_Graph.draw1Series(*ser);
			}
			else{
				m_Graph.drawGrid();
			}
		}
	}

///	fname_line.ReleaseBuffer();
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// COM ポート設定
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void CSignalProcDlgDlg::OnBnClickedButtonComset()
{
	CButton		&btnopen = m_ButtonComOpen;
	CComboBox	&combosel = m_PortNo;
	ComSet		dlg;
	int			comno;

//	gCom.loadParameter();

	dlg.m_Com = gCom;
	comno = GnrlComList::fromGuiPortNo(combosel);
	if (comno > 0){
		dlg.m_Com.putPortNo(comno);
	}
	if (dlg.DoModal() == IDOK){
		gCom = dlg.m_Com;
		gCom.saveParameter();

		// 既にOpenしていたらClose
		if (gCom.isOpened()){
			gCom.close();
			btnopen.SetWindowText(N_T("Open"));
			combosel.EnableWindow(TRUE);

			gComRecvThread.quit();
			return;
		}

		GnrlComList::setGuiComList(m_PortNo, gCom.getPortNo());
	}
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  COMポートオープン / クローズ
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void CSignalProcDlgDlg::OnBnClickedButtoncomopen()
{
	CButton		&btnopen = m_ButtonComOpen;
	CComboBox	&combosel = m_PortNo;
	int32_t comno;

	UpdateData(TRUE);

//	getGuiCsvSet(gCsvParam);
//	saveCsvSet(gCsvParam);

	// 既にOpenしていたらClose
	if (gCom.isOpened()){
		comclose();
		return;
	}

	comno = GnrlComList::fromGuiPortNo(combosel);
	if (comno < 0) return;
	gCom.putPortNo(comno);
///--	gCom.putParameter(comno, 115200, 400, GnrlCom::ESTOPBIT_1, GnrlCom::EPARITY_no);
	gCom.saveParameter();

//--	btnopen.SetWindowText(L"OpenStart");
//--	UpdateData(FALSE);

//--	btnopen.SetWindowText(L"Open終了");
//--	UpdateData(FALSE);

//--	if (gCom.isOpened()){
		comopen();
//--	}

//--	UpdateData(FALSE);

}
int CSignalProcDlgDlg::comopen()
{
	CButton		&btnopen = m_ButtonComOpen;
	CButton		&btnset = m_ButtonComSet;
	CComboBox	&combosel = m_PortNo;

	gCom.open();
	if (!gCom.isOpened()){
		btnopen.SetWindowText(L"Fail");
		return -3;
	}
	btnopen.SetWindowText(L"Close");
	combosel.EnableWindow(FALSE);
	btnset.EnableWindow(FALSE);

	gGraphCsv.clear();

	gComRecvThread.start();

	return 0;
}
int CSignalProcDlgDlg::comclose()
{
	CButton		&btnopen = m_ButtonComOpen;
	CButton		&btnset = m_ButtonComSet;
	CComboBox	&combosel = m_PortNo;

	gCom.close();
	btnopen.SetWindowText(N_T("Open"));
	combosel.EnableWindow(TRUE);
	btnset.EnableWindow(TRUE);

	gComRecvThread.quit();

	return 0;
}
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// 他スレッドからデータ受けた場合
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
LRESULT CSignalProcDlgDlg::OnRecvCom(WPARAM wParam, LPARAM lParam)
{
	static int32_t mabiki_co = 0;
	int32_t	SeriesLen;

	{
		SeriesLen = gGraphCsv.getSeriesLen();
		if (SeriesLen >= m_OutputPoint){
		
			gGraphCsv.deleteOldEntry(SeriesLen / 8);
		}

		m_ComRecvLine = gComRecvThread.getReadLine();
		if(gComFormatDlg.m_hWnd){
			gComFormatDlg.showRecvData(gComRecvThread.getReadLine());
		}
		insertCsv(gGraphCsv, gComRecvThread.getReadLine(), gCsvParam);

		if (mabiki_co >= 4){
			mabiki_co = 0;
			matchGraph();		// グラフの最大最小
		}
		else{
			mabiki_co++;
		}

		if(m_ChkInput){
			m_Graph.draw(gGraphCsv);
		}

		m_StatusBar.SetPaneText(0, gComRecvThread.getReadLine());
	}

	return 0; // メッセージ固有の戻り値を返す
}



// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  ダイアログにファイルをD&Dされたときのハンドラー
//  ダイアログのAccept FilesをTrueに設定
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void CSignalProcDlgDlg::OnDropFiles(HDROP hDropInfo)
{
    //ドロップされたファイルの個数を取得
    //DragQueryFile の詳細についてはmsdn参照
    //第2引数に -1 を指定すると、DragQueryFile はドロップされたファイルの総数を返します
    //unsigned int型の 0 を反転させると -1(0xFFFFFFFF) です
    UINT iCnt = DragQueryFile(hDropInfo, ~0u, NULL, 0);

    //複数ファイル（フォルダ）格納された時のバッファを初期化
//--    csdrop.RemoveAll();

    for (UINT i = 0; i<iCnt; i++)
    {
        //ファイル名の長さを取得
        //第3引数にNULLを指定すると、DragQueryFile は必要なバッファのサイズを文字単位で返します
        UINT iLen = DragQueryFile(hDropInfo, i, NULL, 0);
        //ファイル名を取得
        //第2引数に0～ドロップされたファイルの総数未満のいずれかの値を指定すると、その値に対応するファイル（フォルダ）名を格納します
        CString csfile;
        DragQueryFile(hDropInfo, i, csfile.GetBuffer(iLen + 1), iLen + 1);
        csfile.ReleaseBuffer();

        //ファイル（フォルダ）名を保持
//--    csdrop.Add(csfile);
		AfxMessageBox(csfile);
        //エディットボックスにパスを表示
        //複数ファイルドロップした場合は結果として最後に処理したパスが表示される）
//--        this->SetWindowText(csfile);
    }

	CDialogEx::OnDropFiles(hDropInfo);
}


int32_t SP_fft(CFft<Float32> &fft ,const LineDataSet &InData ,LineDataSet &OutData);
int GPU_FFT_Test(const float32_t *SrcRe ,const float32_t *SrcIm ,float32_t *DstRe ,float32_t *DstIm ,size_t DataLen);

int32_t SignalTest(LineDataSet &Data ,int32_t Len);
extern SignWaveGenf<Float32> singen_Test;
void fft_test();
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  信号生成ボタン押された
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void CSignalProcDlgDlg::OnBnClickedButtonGen()
{
	LineDataSet ld;	//	= m_Graph.dataSet();

	size_t n = 1024;
#if 0	// FIR Test
	ld.addSeriesFloat32();
	ld[0].resize(1024);

	SignalTest(ld ,ld[0].size());

	m_Graph.draw(ld);
#endif

#if 1	// CPU_FFT Test

	ld.addFloat32(n);
	ld.addFloat32(n);

	LineDataSet	lineans;//	= m_Graph.dataSet();

	lineans.addFloat32(n);
	lineans.addFloat32(n);

	{
		singen_Test.putFreq1Clk(freq1Clk(1000 ,20000));
		singen_Test.putLevel(20.0f);

		singen_Test.gen(lineans[0].getSeriesFloat32Arrow() ,nullptr ,lineans[0].size());		//  ,0.8f
	}

	numpy::hammingMulti(lineans[0].getSeriesFloat32Arrow() ,lineans[0].size());

	CFft<Float32>	fft(n);
//	fft.fft(lineans[0].getSeriesFloat32Arrow() ,lineans[1].getSeriesFloat32Arrow() ,ld[0].getSeriesFloat32Arrow() ,ld[1].getSeriesFloat32Arrow());
	GPU_FFT_Test(lineans[0].getSeriesFloat32Arrow() ,lineans[1].getSeriesFloat32Arrow() ,ld[0].getSeriesFloat32Arrow() ,ld[1].getSeriesFloat32Arrow() ,n);

	m_Graph.dataSet()	= ld.vector();	//.

	m_Graph.setViewAreaXEntrySize();

	m_Graph.autoXGridSpacing();
	m_Graph.autoYGridSpacing();
	m_Graph.onPaint();
#endif

}


void CSignalProcDlgDlg::OnBnClickedButtonCudaInfo()
{
	CCudaInfoDlg dlg;

	dlg.DoModal();
}

void CSignalProcDlgDlg::OnBnClickedButton2()
{
	CTapDlg dlg;

	dlg.DoModal();
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  マウスボタンの操作
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void CSignalProcDlgDlg::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: ここにメッセージ ハンドラー コードを追加するか、既定の処理を呼び出します。
	// マウスのダイアログのクライアント座標をスクリーン座標に変換します。
	ClientToScreen(&point);

	// ピクチャーコントロール上のクライアント座標に変換します。
//	HWND hWnd = m_pictureCtl.m_hWnd;
//	::ScreenToClient(hWnd, &point);

//	typedef wchar_t			Nchar;			// プロジェクトで設定する文字の扱いに合わせて下さい。Unicode,マルチバイト
	//#define Nstrlen(a)		wcslen(a)
	//#define Nitoa(v,b,l)	_itow(v,b,l);

	CDialogEx::OnLButtonDown(nFlags, point);
}

void CSignalProcDlgDlg::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: ここにメッセージ ハンドラー コードを追加するか、既定の処理を呼び出します。

	//	CString str;
	CEdit* pEdit1 = (CEdit*)GetDlgItem(IDC_EDIT3);
	CString str;

	//	str.Format(_T("x= %4d y= %4d"), point.x, point.y);
	//	pEdit1->SetWindowTextW(str);

	CDialogEx::OnMouseMove(nFlags, point);
}


BOOL CSignalProcDlgDlg::PreTranslateMessage(MSG* pMsg)
{

	int		ack;
	CString str;
	CEdit*	pEdit1 = (CEdit*)GetDlgItem(IDC_EDIT3);
	CWnd*	pWnd = WindowFromPoint(pMsg->pt);
	CRect	rect,crect;
	CPoint	point;

#if 0
	ack = m_Graph.PreTranslateMessage(*this, pMsg, gGraphCsv);	// 0:
	switch (ack){
		case CLineGraph::EGR_clk_left:
			break;
		case CLineGraph::EGR_clk_bottom:
			break;
		case CLineGraph::EGR_dclk_center:
			matchGraph();
			drawGraph();
			break;
		case CLineGraph::EGR_redraw:
			drawGraph();
			break;
	}
#else
	ack = m_Graph.PreTranslateMessageSol(*this, pMsg);


#endif

	// 
	switch (pMsg->message){
		case WM_KEYDOWN:
			switch( pMsg->wParam )
			{
///				case VK_RETURN:
///					return FALSE;	// Enter,Escapeでウインドウ閉じさせない
				case VK_ESCAPE:
					return FALSE;
				default:
					break;
			}

			break;

		case WM_NOTIFY:
			//// 通知メッセージ
			LV_DISPINFO	*lvInfo = (LV_DISPINFO *)pMsg->lParam;
//--			switch ( pMsg->wParam ) {
//--			}
			break;
	}

	return CDialogEx::PreTranslateMessage(pMsg);
}


void CSignalProcDlgDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialogEx::OnSize(nType, cx, cy);

	setStatusBar(*this);
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  リスト操作 ADD
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void CSignalProcDlgDlg::OnBnClickedButtonProcessAdd()
{
	RECT rect;

	// ボタン位置を取得
	CButton* pEdit1 = (CButton*)GetDlgItem(IDC_BUTTON_PROCESS_ADD);

	pEdit1->GetWindowRect(&rect);

	CMenu menu;
	menu.LoadMenu(IDR_MENU_PROCESSTYPE);
	CMenu *pMenu=menu.GetSubMenu(0);	//「popup1」メニューを取得

	pMenu->TrackPopupMenu(
		TPM_LEFTALIGN  |	//クリック時のx座標をメニューの左辺にする
		TPM_RIGHTBUTTON,	//右クリックでメニュー選択可能とする
		rect.right ,rect.bottom,	//メニューの表示位置
		this            	//このメニューを所有するウィンドウ
	);
	menu.DestroyMenu();
}
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  リスト操作 ↑
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void CSignalProcDlgDlg::OnBnClickedButtonProcessUp()
{
	// 選択されているアイテムの行番号取得
	int32_t iSelected = m_listctrl.GetNextItem( -1, LVNI_SELECTED );

#if 1
	if(iSelected <= 0 || iSelected > gProcessList.size() )	return;
	int32_t iSelectNew = iSelected-1;

	// プロセスリスト↑
	ProcessBase *pb = gProcessList[iSelectNew];
	gProcessList[iSelectNew]	= gProcessList[iSelected];
	gProcessList[iSelected]		= pb;

	m_listctrl.DeleteItem(iSelected);
	insertProcess(m_listctrl ,*gProcessList[iSelectNew] ,iSelectNew);

#endif

#if 0
	// リストコントロール
//		m_listctrl.GetItem();
	int piOrderArray[] = {1, 0, 2};
	ListView_SetColumnOrderArray(m_listctrl.m_hWnd, 3, piOrderArray);
//	Bool ack = m_listctrl.SetColumnOrderArray(3, piOrderArray);
#endif

#if 0
	_TCHAR szBuff[MAX_PATH];

	LVITEMW lvi;
    lvi.iItem = 1;
    lvi.iSubItem = 0;
    lvi.mask = LVIF_TEXT | LVIF_IMAGE | LVIF_STATE;
	lvi.pszText = szBuff;
    lvi.cchTextMax = sizeof(szBuff);
    lvi.stateMask = 0xFFFF;

	m_listctrl.GetItem(&lvi);
	m_listctrl.DeleteItem(1);

	    lvi.iItem = 0;
	m_listctrl.InsertItem(&lvi);
#endif
}
void CSignalProcDlgDlg::OnBnClickedButtonProcessDown()
{
	// 選択されているアイテムの行番号取得
	int32_t iSelected = m_listctrl.GetNextItem( -1, LVNI_SELECTED );

#if 1
	if(iSelected < 0 || iSelected > gProcessList.size()-1 )	return;
	int32_t iSelectNew = iSelected+1;

	// プロセスリスト↓
	ProcessBase *pb = gProcessList[iSelectNew];
	gProcessList[iSelectNew]	= gProcessList[iSelected];
	gProcessList[iSelected]		= pb;

	m_listctrl.DeleteItem(iSelected);
	insertProcess(m_listctrl ,*gProcessList[iSelectNew] ,iSelectNew);

#endif
}

void insertProcess(CListCtrlProc &ListCtrl ,const ProcessBase &Process ,int32_t nItem)
{
	ProcessBase *pb = gProcessList[nItem];
	if(pb == nullptr)	return;

//--	ListCtrl.SetItemState(nItem , 0, LVIS_SELECTED|LVIS_FOCUSED);
	ListCtrl.InsertItem(nItem	,		pb->getCellText(0));
	ListCtrl.SetItemText(nItem	, 1,	pb->getCellText(1));
	ListCtrl.SetItemText(nItem	, 2,	pb->getCellText(2));

	ListCtrl.SetItem(nItem, 0, LVIF_IMAGE, NULL, pb->getTypeId(), 0, 0, 0);	//
	ListCtrl.SetItemState(nItem , LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED);
}
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// 信号処理の追加なので、クラス外に実装したほうがいいかも。
// 信号処理追加する
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
int32_t addProcess(CListCtrlProc &ListCtrl , ProcessBase::E_ProcessType Type)
{
	ProcessBase *pb = ProcessBase::newProcess(Type);

	// 選択されているアイテムの行番号取得
	int32_t nItem = ListCtrl.GetNextItem( -1, LVNI_SELECTED );

	if( nItem < 0 ){
			// 選択されていない
		nItem	 = 0;
	}else if(nItem > (int32_t)gProcessList.size()){
		nItem	= gProcessList.size();
	}
	
	gProcessList.insert(gProcessList.begin() + nItem, pb);

#if 0
	ListCtrl.SetItemState(nItem , 0, LVIS_SELECTED|LVIS_FOCUSED);
	ListCtrl.InsertItem(nItem,		pb->getCellText(0));
	ListCtrl.SetItemText(nItem, 1,	pb->getCellText(1));
	ListCtrl.SetItemText(nItem, 2,	pb->getCellText(2));
	ListCtrl.SetItem(nItem,		0,	LVIF_IMAGE, NULL, Type, 0, 0, 0);

	ListCtrl.SetItemState(nItem , LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED);
#else
	insertProcess(ListCtrl ,*gProcessList[nItem] ,nItem);
#endif

	return 0;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// ComFormat 設定ダイアログ
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void CSignalProcDlgDlg::OnComFormatDlg()
{
	gComFormatDlg.m_CsvParam	= gCsvParam;

	if(gComFormatDlg.DoModal() == IDOK){
		gCsvParam = gComFormatDlg.m_CsvParam;
	}


}
void CSignalProcDlgDlg::OnAddProcessNoise()
{
	addProcess(m_listctrl , ProcessBase::EPT_noise);
}

void CSignalProcDlgDlg::OnAddProcessSinwave()
{
	addProcess(m_listctrl , ProcessBase::EPT_sin_wave);
}

void CSignalProcDlgDlg::OnAddProcessFir()
{
	addProcess(m_listctrl , ProcessBase::EPT_fir_filter);
}
void CSignalProcDlgDlg::OnAddProcessIir()
{
	addProcess(m_listctrl , ProcessBase::EPT_iir_filter);
}
void CSignalProcDlgDlg::OnAddProcessAve()
{
//++	addProcess(m_listctrl , ProcessBase::EPT_ave_filter);
}
void CSignalProcDlgDlg::OnAddProcessFft()
{
	addProcess(m_listctrl , ProcessBase::EPT_iir_filter);
}


int32_t loadProcessParam(std::vector<ProcessBase*> &List ,const Nchar *FilePath);
int32_t saveProcessParam(std::vector<ProcessBase*> &List ,const Nchar *FilePath);

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// プロセスファイルをロード/セーブ
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void CSignalProcDlgDlg::OnBnClickedButtonProcListOpen()
{
	CFileDialog dlgFile(TRUE);
	OPENFILENAME &ofn = dlgFile.GetOFN();
	ofn.lpstrTitle = _T("処理ファイルのを開く");
	ofn.lpstrFilter = _T("All Files\0*.*\0Process Files\0*.prc\0Log Files\0*.log\0");
	ofn.Flags |= OFN_SHOWHELP; 

	if(dlgFile.DoModal()==IDOK){
		try{
#if 0
			loadProcessParam(gProcessList ,N_T("D:\\tmp\\Proc_Param.txt"));
#else
			loadProcessParam(gProcessList ,dlgFile.GetPathName());
#endif
		}catch(std::exception e){
			MessageBox(CString(e.what()));
			return;
		}

		m_listctrl.setGui(gProcessList);
	}

}
void CSignalProcDlgDlg::OnBnClickedButtonProcListSave()
{
	CFileDialog dlgFile(FALSE);
	OPENFILENAME &ofn = dlgFile.GetOFN();
	ofn.lpstrTitle = _T("処理ファイルを保存");
	ofn.lpstrFilter = _T("All Files\0*.*\0Process Files\0*.prc\0Log Files\0*.log\0");
	ofn.Flags |= OFN_SHOWHELP; 

	if(dlgFile.DoModal()==IDOK){
		try{
#if 0
			saveProcessParam(gProcessList ,N_T("D:\\tmp\\Proc_Param.txt"));
#else
			saveProcessParam(gProcessList ,dlgFile.GetPathName());
#endif
			saveProcessParam(gProcessList ,N_T("D:\\tmp\\Proc_ParamW.txt"));
		}catch(std::exception e){
			MessageBox(CString(e.what()));
			return;
		}
	}
}


void CSignalProcDlgDlg::OnBnClickedCheckInput()
{
	UpdateData(TRUE);
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Open GL ボタンクリック
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
void CSignalProcDlgDlg::OnBnClickedButtonGl()
{
	gGLThread.start();
}

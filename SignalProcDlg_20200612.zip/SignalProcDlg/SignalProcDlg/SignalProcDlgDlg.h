// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// SignalProcDlgDlg.h : �w�b�_�[ �t�@�C��
//
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

#pragma once

#include "GnrlInt.h"
#include "SP_Define.h"
#include "afxcmn.h"
#include "ListCtrlProc.h"
#include "afxwin.h"
#include "afxvslistbox.h"

class CComFormatDlg;

// CSignalProcDlgDlg �_�C�A���O
class CSignalProcDlgDlg : public CDialogEx
{
public:
	enum E_InputSel{
		 EIS_external	= 0
		,EIS_internal	= 1
		,EIS_num		= 2
	};
	const static CString mInputSelStr[];


// �R���X�g���N�V����
public:
	CSignalProcDlgDlg(CWnd* pParent = NULL);	// �W���R���X�g���N�^�[

// �_�C�A���O �f�[�^
	enum { IDD = IDD_SIGNALPROCDLG_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV �T�|�[�g


// ����
protected:
	HICON m_hIcon;

	// �������ꂽ�A���b�Z�[�W���蓖�Ċ֐�
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedCheck1();
	afx_msg void OnBnClickedButtonFopen();
	afx_msg void OnBnClickedButtonGen();
	afx_msg void OnBnClickedButtonCudaInfo();
	afx_msg void OnDropFiles(HDROP hDropInfo);
	afx_msg void OnBnClickedButton2();


//--	int32_t getGuiCsvSet(st_CsvParam &CsvParam);
//--	int32_t setGuiCsvSet(const st_CsvParam &CsvParam);


	CString m_ComRecvLine;

	afx_msg void OnBnClickedOk();
	int m_DataStartLine;
	BOOL mCaptureMode;


//++	CChartContainer m_chartContainer;
	void drawGraph();

	CLineGraph m_Graph;		// �O���t

	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	int m_DataDirection;
	// �d�؂蕶���������ɂ�������
	int matchGraph();		// 

//	afx_msg UINT OnMenuDrag(UINT nPos, CMenu *pMenu);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	// ������	// ������

	// �Ǝ��̃��b�Z�[�W���M �ǉ�
	afx_msg LRESULT OnRecvCom(WPARAM wParam, LPARAM lParam);

	// ���X�g�R���g���[��
	CListCtrlProc		m_listctrl;
	CImageList			m_imglstList;
	CComboBox			m_PortNo;

	CStatusBar		    m_StatusBar;

	afx_msg void OnBnClickedButtoncomopen();
	afx_msg void OnBnClickedButtonComset();
	CButton m_ButtonComOpen;
	int comopen();
	int comclose();

	int32_t loadDlgSet();
	int32_t saveDlgSet();

	afx_msg void OnSize(UINT nType, int cx, int cy);

	CButton m_ButtonComSet;
	CComboBox m_ImputSelect;
	int m_InputFreq;
	int m_OutputPoint;
	afx_msg void OnBnClickedButtonProcessAdd();


	afx_msg void OnComFormatDlg();
	// ���X�g�ɏ�����ǉ�
	afx_msg void OnAddProcessNoise();
	afx_msg void OnAddProcessSinwave();
	afx_msg void OnAddProcessFir();
	afx_msg void OnAddProcessIir();
	afx_msg void OnAddProcessAve();
	afx_msg void OnAddProcessFft();
	afx_msg void OnBnClickedButtonProcListOpen();
	BOOL m_ChkInput;
	BOOL m_ChkOutput;
	afx_msg void OnBnClickedCheckInput();
	CListCtrl m_xcListCtrl;
	afx_msg void OnBnClickedButtonProcListSave();
	int m_StatiBegin;
	int m_StatiN;
	afx_msg void OnBnClickedButtonProcessUp();
	afx_msg void OnBnClickedButtonProcessDown();
	afx_msg void OnBnClickedButtonGl();
};

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// fft.h
//
// �Q�l �F http://csharpimage.blog60.fc2.com/blog-entry-12.html
//
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

#pragma once

#include <vector>
//#include "stdafx.h"


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �r�b�g�����E���]�����z��𐶐�
// �T�C�Y�̃r�b�g����Ԃ�
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
inline int FFT_bitScrollArray(int *pids ,int arraySize)	// std::vector< int >&
{
    int n_level;
    int i,j;

	for (i = 0; i < 64; ++i){
		if (arraySize >> i == 1) break;
	}
	n_level	= i;

//    vector< int >& ids = *pids;
    // ID ���ї�̌v�Z
//--    pids.resize( arraySize );

//    int[] reBitArray = new int[arraySize];
    auto arraySizeHarf = arraySize >> 1;

    pids[0] = 0;
    for (i = 1; i < arraySize; i <<= 1){
		for (j = 0; j < i; j++){
			pids[j + i] = pids[j] + arraySizeHarf;
		}
        arraySizeHarf >>= 1;
    }

    return n_level;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// 1����FFT
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *


template<typename X>
class CFft
{
public:

	CFft(int arraySize)
	{
		ids(arraySize);
	}

	// �{�֐����g��ID���ї���
	// arraySize�͂Q�ׂ̂��搔�ł��邱�Ƃ���O��
	int32_t ids(int arraySize)
	{
		int i, j;

		for (i = 0; i < 64; ++i){
			if (arraySize >> i == 1) break;
		}
		m_bitsize = i;

		ASSERT( arraySize == 1 << m_bitsize );

		auto arraySizeHarf = arraySize >> 1;

		m_ids.resize(arraySize);
		m_ids[0] = 0;
		for (i = 1; i < arraySize; i <<= 1){
			for (j = 0; j < i; j++){
				m_ids[j + i] = m_ids[j] + arraySizeHarf;
			}
			arraySizeHarf >>= 1;
		}

		return m_bitsize;
	}

	void fft(const X *inputRe,	const X *inputIm,  X *outputRe, X *outputIm)
	{
		int i,j;
		int stage,type;
		int dataSize = 1 << m_bitsize;

		const uint32_t *ids = &m_ids[0];

		// �o�^�t���C���Z�̂��߂̒u������
		for (i = 0; i < dataSize; i++){
			outputRe[i] = inputRe[ids[i]];
			outputIm[i] = inputIm[ids[i]];
		}

		// �o�^�t���C���Z
		for (stage = 1; stage <= m_bitsize; stage++){
			int butterflyDistance = 1 << stage;
			int numType = butterflyDistance >> 1;
			int butterflySize = butterflyDistance >> 1;

			X wRe = 1.0;
			X wIm = 0.0;
			X uRe = cos(M_PI / butterflySize);
			X uIm = -sin(M_PI / butterflySize);

			for (type = 0; type < numType; type++){
				for (j = type; j < dataSize; j += butterflyDistance){
					int jp = j + butterflySize;
					X tempRe = outputRe[jp] * wRe - outputIm[jp] * wIm;
					X tempIm = outputRe[jp] * wIm + outputIm[jp] * wRe;
					outputRe[jp] = outputRe[j] - tempRe;
					outputIm[jp] = outputIm[j] - tempIm;
					outputRe[j] += tempRe;
					outputIm[j] += tempIm;
				}
				X tempWRe = wRe * uRe - wIm * uIm;
				X tempWIm = wRe * uIm + wIm * uRe;
				wRe = tempWRe;
				wIm = tempWIm;
			}
		}
	}

	// 
	int32_t getDataSize() const { return m_ids.size();	}


	bool isGood() const			{ return m_bitsize > 0; }

	// ��������T�C�Y��ID���ї���T�C�Y�ȉ��ł��鎖���m�F����B
	bool isDataSizeOk(int32_t DataSize) const{
		return DataSize <= m_ids.size();
	}

private:

	std::vector<uint32_t> m_ids;		// ID���ї���
	int32_t				m_bitsize;
};
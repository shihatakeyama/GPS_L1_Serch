// **********************************************************************
// COM ����̃f�[�^��҂��󂯂�X���b�h
//
// ComRecvThread.cpp
// 
// 2013/06/31  Createed
// 2019/12/22  J�C��
// **********************************************************************

#include "stdafx.h"

#include "GnrlDefine.h"
#include "GnrlThread.h"

#include "ComRecvThread.h"


ComRecvThread::ComRecvThread()
: m_Wnd(NULL)
{};

void ComRecvThread::setWnd(CWnd *Wnd)
{
	m_Wnd = Wnd;
}

// Com��M���[�`��
int32_t ComRecvThread::run()
{
	uint8_t	lastdata[2];
	int		recvlen;
	time_t	lasttime, elaptime;

	ASSERT(m_Wnd);			// ���b�Z�[�W�ʒm��E�C���h�E��

	m_ReadLine.Empty();

	if (!gCom.isOpened()){
		return -1;
	}

	lasttime = time(NULL);	// �b�P��

	while (isLife()){

		recvlen = gCom.read(&lastdata[0], 1);
		if (recvlen > 0){
			time_t nowtime = time(NULL);

			elaptime = nowtime - lasttime;
			if (elaptime > 10){
				m_ReadLine.Empty();
			}

			recvlen = m_ReadLine.GetLength();
			if ((m_ReadLine.GetLength() > 2) && ((lastdata[0] == '\r') || (lastdata[0] == '\n'))){
				m_Wnd->SendMessage(WM_COM_RECV_DATA, 0, 0);
				m_ReadLine.Empty();
			}
			else{
				m_ReadLine += lastdata[0];
			}

			lasttime = nowtime;
		}
		else{
			Sleep(10);
		}

	}

	return 0;
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//
//
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

#pragma once
#include "afxwin.h"


// CTapDlg �_�C�A���O

class CTapDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CTapDlg)

public:
	CTapDlg(CWnd* pParent = NULL);   // �W���R���X�g���N�^�[
	virtual ~CTapDlg();

// �_�C�A���O �f�[�^
	enum { IDD = IDD_TAP_DIALOG };


public:
	static const CString		mKindListStr[ETK_num];
	static const CString		mWindowListStr[ETW_num];

	const static Float32		m2pi,m4pi; 

	void drawGraph();

	CLineGraph m_Graph;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �T�|�[�g

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	CComboBox m_Lbh;
	int m_Fc;
	int m_Fb;
	int m_Fck;
	int m_TapN;
	CComboBox m_ComboWindow;
	int outputText();

	afx_msg void OnBnClickedButtonCalc();

	LineDataSet	m_Tap;

	CString m_Coeffi;			// TAP �W�����X�g
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnPaint();
};

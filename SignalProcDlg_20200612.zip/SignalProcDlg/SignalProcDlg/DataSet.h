// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  DataSet.h
//
//
//  dependent : Win32,MFC
// 
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *


#pragma once

#include "stdafx.h"

using namespace std;


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// 1�V���[�Y(���C��)�̒l�i�[
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
template<typename X>
struct CLineDataSet{
	X	*Val;
	int ValLen;
};

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �����V���[�Y�̒l�i�[
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
template<typename X>
struct CILineDataSet{
	enum { MAX_Series = 8 };
	CLineDataSet<X>		*DataSet[MAX_Series];
	int					DataSetLen;
};


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
//  �G���g���[�^
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
template<typename X>
class Entry{
	X x;
	X y;
};

#if 0
//typedef Entry<Float32>	Point2D32f;
class Point2D32f{
	Float32		x;
	Float32		y;
};
#endif

typedef std::vector<int>			SeriesI1;
typedef std::vector<float>			SeriesF1;

typedef std::vector<Entry<int>>		SeriesI2;
typedef std::vector<Entry<float>>	SeriesF2;

//template<typename X>
//typedef std::vector<Entry<X>>		SeriesX2;


//typedef std::vector<SeriesI1>	ILineDataSetI1;	// int 1ch
typedef std::vector<SeriesF1>	ILineDataSetF1;	// Float 1ch

typedef std::vector<SeriesI2>	ILineDataSetI2;	// int 2ch
typedef std::vector<SeriesF2>	ILineDataSetF2;	// float 2ch


//class GraphSeries1Ch;
class SeriesBase;

template<typename X>
class GraphSeries1Ch;

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �����̃V���[�Y��vector�Ɋi�[���₷�����邽�߂̃N���X�B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
class SeriesBase{

public:
	enum E_ValType{
		ENE_int32_t = 0,
		ENE_sint64 = 1,
		ENE_uint32 = 2,
		ENE_uint64 = 3,
		ENE_float32 = 4,
		ENE_float64 = 5,
		ENE_other = 6
	};

	typedef GraphSeries1Ch<int32_t>	Seriesint32_t;	// �V���[�Y�^
	typedef GraphSeries1Ch<Float32> SeriesFloat32;
	typedef GraphSeries1Ch<Float64> SeriesFloat64;

//--	typedef GraphSeries1Ch<Point2D32f>	Series2D32f;

//	SeriesBase(SeriesBase &Arg);

	virtual ~SeriesBase() = 0		{						}

	virtual void clear()			{ ASSERT(0);			}
	virtual bool empty() const		{ return true;			}
	virtual size_t size()const		{ return 0;				}
	virtual void resize(size_t sz)	{ ASSERT(0);			}
	SeriesBase *clone() const;

//	template<typename X>
//	virtual const X & operator[](int32_t Ordinal) const	= 0;
	virtual const SeriesBase &operator = (const SeriesBase &Arg)			{ ASSERT(0);	return (const SeriesBase&)mErrint32_t;  } 
	virtual const SeriesBase &operator = (const std::vector<int32_t> &Arg)	{ ASSERT(0);	return (const SeriesBase&)mErrint32_t;  } // Seriesint32_t & ��������
	virtual const SeriesBase &operator = (const std::vector<Float32> &Arg)	{ ASSERT(0);	return (const SeriesBase&)mErrFloat32;  } // SeriesFloat32 & ��������

	const static Seriesint32_t  mErrint32_t;
	const static SeriesFloat32  mErrFloat32;

	int32_t getValTypeId() const		{ return m_ValType;		}

	virtual void push_back(int32_t Val) = 0;
	virtual void push_back(uint32_t Val) = 0;
	virtual void push_back(int16_t Val) = 0;
	virtual void push_back(uint16_t Val) = 0;
	virtual void push_back(Float32 Val) = 0;
	virtual void push_back(Float64 Val) = 0;

//	void push_back();	// �p����̃N���X�Œ�`���Ă��炤�B

	// �ŏ��A�ő���擾
	virtual bool minAndMaxFloat32(Float32 &Min, Float32 &Max) const{	return false;	}
	// �Â��G���g���[���폜
	virtual int32_t	deleteOldEntry(size_t Len) = 0;

	// �h���^��Ԃ��B
	virtual Seriesint32_t *getSeriesInt32() = 0;
	virtual SeriesFloat32 *getSeriesFloat32() = 0;

	virtual int32_t *getSeriesInt32Arrow()				{ return nullptr; }
	virtual const int32_t *getSeriesInt32Arrow() const	{ return nullptr; }
	virtual Float32 *getSeriesFloat32Arrow()			{ return nullptr; }
	virtual const Float32 *getSeriesFloat32Arrow() const{ return nullptr; }

	virtual Float32 getEntryFloat32(size_t Ordinal) const = 0;

	// ������ɕϊ����܂��B
	virtual CString toString(int32_t Ordinal/* ,const CString Format*/) const = 0;

	virtual bool isAppend(const SeriesBase &Arg) const	{ return nullptr; };

	// �V���[�Y���A���P�[�g���܂��B
	static Seriesint32_t *newSeriesSint32();
	static SeriesFloat32 *newSeriesFloat32();
	static SeriesBase *newSeries(enum E_ValType ValTypeId);

protected:
	enum E_ValType	m_ValType;	// m_ValTypeId;	�̕����������ȁH
};

// ----------------- SeriesBase / GraphSeries1Ch -------------------------------

template<typename X>
class GraphSeries1Ch
:public SeriesBase{

public:

//--	typedef GraphSeries1Ch<int32_t>		Seriesint32_t;	// �V���[�Y�^
//--	typedef GraphSeries1Ch<Float32>		SeriesFloat32;


	GraphSeries1Ch();	// int32_t ValTypeId
	GraphSeries1Ch(const GraphSeries1Ch<X> &Arg1);

	virtual ~GraphSeries1Ch();

	virtual void clear()						{		 m_Data.clear();		}
	virtual bool empty() const					{ return m_Data.empty();		}
	virtual size_t size() const					{ return m_Data.size();			}
	virtual void resize(size_t sz)				{		 m_Data.resize(sz);		}
	virtual GraphSeries1Ch<X> *clone() const	{ return new GraphSeries1Ch<X>(*this);  }

	X & operator[](int32_t Ordinal)				{ return m_Data[Ordinal];		}
	const X & operator[](int32_t Ordinal) const	{ return m_Data[Ordinal];		}

//--	template<typename Y>	// error C2898: : �����o�[�֐��e���v���[�g�����z�ɂ��邱�Ƃ͂ł��܂���B
//--	virtual void operator = (const Y &Arg){
//--		m_Data = Arg;
//--	}
	virtual const SeriesBase &operator = (const SeriesBase &Arg);
	virtual const SeriesBase &operator = (const std::vector<int32_t> &Arg); // SeriesFloat32 & ��������
	virtual const SeriesBase &operator = (const std::vector<Float32> &Arg); // SeriesFloat32 & ��������

	virtual void push_back(int32_t Val)			{ m_Data.push_back(static_cast<X>(Val)); }
	virtual void push_back(uint32_t Val)		{ m_Data.push_back(static_cast<X>(Val)); }
	virtual void push_back(int16_t Val)			{ m_Data.push_back(static_cast<X>(Val)); }
	virtual void push_back(uint16_t Val)		{ m_Data.push_back(static_cast<X>(Val)); }
	virtual void push_back(Float32 Val)			{ m_Data.push_back(static_cast<X>(Val)); }
	virtual void push_back(Float64 Val)			{ m_Data.push_back(static_cast<X>(Val)); }



	virtual bool minAndMaxFloat32(Float32 &Min, Float32 &Max) const;
	bool minAndMax(X &Min, X &Max) const;

	// �Â��G���g���[���폜
	virtual int32_t	deleteOldEntry(size_t Len);

	virtual Seriesint32_t *getSeriesInt32() 	{ return dynamic_cast<Seriesint32_t*>(this);	}
	virtual SeriesFloat32 *getSeriesFloat32() 	{ return dynamic_cast<SeriesFloat32*>(this);}

#if 1	// �C�ӂ̊i�[�N���X�ł����Ă��Afloat�^�ŕԂ��܂��B
	virtual Float32 getEntryFloat32(size_t Ordinal) const {
		ASSERT(!m_Data.empty());
		ASSERT((int32_t)m_Data.size() > Ordinal);

		return static_cast<Float32>(m_Data[Ordinal]);
	}
#endif
	virtual CString toString(int32_t Ordinal) const
	{
		CString str;

		if (getValTypeId() == ENE_int32_t){
			auto val = operator[](Ordinal);	//<int32_t>
			str.Format(N_T("%d") ,val);
		}else if(getValTypeId() == ENE_float32){
			auto val = operator[](Ordinal);	//<Float32>
			str.Format(N_T("%g") ,val);
		}
	
		return str;
	}

	virtual bool isAppend(const SeriesBase &Arg) const
	{
		size_t i,end;

		if(getValTypeId() != Arg.getValTypeId())	return FALSE;
		if(size() < Arg.size())	return FALSE;

		end = Arg.size();
		if (getValTypeId() == ENE_int32_t){
			const int32_t *itr0 = getSeriesInt32Arrow();
			const int32_t *itr1 = Arg.getSeriesInt32Arrow();
			for(i=0;i<end;i++){
				if(*itr0 != *itr1){
					return FALSE;
				}
				itr0++;
				itr1++;
			}
		}else if(getValTypeId() == ENE_float32){
			const Float32 *itr0 = getSeriesFloat32Arrow();
			const Float32 *itr1 = Arg.getSeriesFloat32Arrow();
			for(i=0;i<end;i++){
				if(*itr0 != *itr1){
					return FALSE;
				}
				itr0++;
				itr1++;
			}
		}

		return TRUE;
	}

	virtual int32_t *getSeriesInt32Arrow()		{ 
		ASSERT(m_ValType == ENE_int32_t);
		return reinterpret_cast<int32_t*>(&m_Data[0]);
	}
	virtual const int32_t *getSeriesInt32Arrow() const	{ 
		ASSERT(m_ValType == ENE_int32_t);
		return reinterpret_cast<const int32_t*>(&m_Data[0]);
	}
	virtual Float32 *getSeriesFloat32Arrow() 	{
		ASSERT(m_ValType == ENE_float32);
		return reinterpret_cast<Float32*>(&m_Data[0]);
	}
	virtual const Float32 *getSeriesFloat32Arrow() const {
		ASSERT(m_ValType == ENE_float32);
		return reinterpret_cast<const Float32*>(&m_Data[0]);
	}


private:
	std::vector<X>	m_Data;
};

// ----------------- GraphSeries1Ch /  -------------------------------


template<typename SB> 
SeriesBase *func1to1(SeriesBase *ret ,const SeriesBase *In )
{
	SB *pin = (SB*)In;
	SB *ret = (SB*)ret;

	int32_t i,end;

	for(i=0;i<end;i++){
	
	}
	

}

template<typename X> 
void vector1_func(X Out ,const X In)
{
	int32_t i;
	int32_t outsize = Out.size();
	int32_t insize = In.size();

	if(outsize != insize){
		Out.resize(insize);
	}

	for(i=0;i<insize;i++){
		Out[i]	= In[i];
	}
}
template<typename X> 
void vector2_func(X &Out ,const X &In1 ,const X &In2)
{
	int32_t i;
	int32_t outsize = Out.size();
	int32_t insize1 = In1.size();
	int32_t insize2 = In2.size();
	Float64 seg[2];

	ASSERT(insize1 == insize2);

	if(outsize != insize1){
		Out.resize(insize1);
	}

	for(i=0;i<insize1;i++){
		seg[0]	= In1[i]	,seg[1]	= In2[i];

		Out[i]	= (sqrt(seg[0]*seg[0] + seg[1]*seg[1]));
	}
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// �^�ϊ����Ċ֐��Ăяo���}�N��
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
#define TYPEFUNC_1TO1(out,in,f)		\
switch (in.getValTypeId()){			\
	case SeriesBase::ENE_int32_t:	\
	{								\
		SeriesBase::Seriesint32_t *out_c = dynamic_cast<SeriesBase::Seriesint32_t*>(&(out));			\
		const SeriesBase::Seriesint32_t *in_c = dynamic_cast<const SeriesBase::Seriesint32_t*>(&(in));		\
		f<SeriesBase::Seriesint32_t>(*out_c ,*in_c);								\
	   break;						\
	}								\
	case SeriesBase::ENE_float32:	\
	{								\
		SeriesBase::SeriesFloat32 *out_c = dynamic_cast<SeriesBase::SeriesFloat32*>(&(out));	\
		const SeriesBase::SeriesFloat32 *in_c = dynamic_cast<const SeriesBase::SeriesFloat32*>(&(in));		\
		f<SeriesBase::SeriesFloat32>(*out_c ,*in_c);							\
		break;						\
	}								\
}
#define TYPEFUNC_2TO1(out,in1,in2,f)		\
switch (in1.getValTypeId()){			\
	case SeriesBase::ENE_int32_t:	\
	{								\
		SeriesBase::Seriesint32_t *out_c = dynamic_cast<SeriesBase::Seriesint32_t*>(&(out));			\
		const SeriesBase::Seriesint32_t *in_c1 = dynamic_cast<const SeriesBase::Seriesint32_t*>(&(in1));		\
		const SeriesBase::Seriesint32_t *in_c2 = dynamic_cast<const SeriesBase::Seriesint32_t*>(&(in2));		\
		f<SeriesBase::Seriesint32_t>(*out_c ,*in_c1 ,*in_c2);								\
	   break;						\
	}								\
	case SeriesBase::ENE_float32:	\
	{								\
		SeriesBase::SeriesFloat32 *out_c = dynamic_cast<SeriesBase::SeriesFloat32*>(&(out));	\
		const SeriesBase::SeriesFloat32 *in_c1 = dynamic_cast<const SeriesBase::SeriesFloat32*>(&(in1));		\
		const SeriesBase::SeriesFloat32 *in_c2 = dynamic_cast<const SeriesBase::SeriesFloat32*>(&(in2));		\
		f<SeriesBase::SeriesFloat32>(*out_c ,*in_c1 ,*in_c2);								\
		break;						\
	}								\
}

#if 0
	// ���l�^�̈قȂ�z����z������B
	void typefunc1to1(SeriesBase *ret ,const SeriesBase *In ,func)
	{
			SeriesBase *pseri = NULL;

		switch (In->getValTypeId()){
		case SeriesBase::ENE_int32_t:
		{
			SeriesBase::Seriesint32_t *pin = (SeriesBase::Seriesint32_t*)In;
			SeriesBase::Seriesint32_t *ret = (SeriesBase::Seriesint32_t*)ret;


			break;
		}
/*		case SeriesBase::ENE_sint64:
			pseri = new GraphSeries1Ch<Sint64>(ValTypeId);
			break;
		case SeriesBase::ENE_uint32:
			pseri = new GraphSeries1Ch<Uint32>(ValTypeId);
			break;
		case SeriesBase::ENE_uint64:
			pseri = new GraphSeries1Ch<Uint64>(ValTypeId);
			break;
		case SeriesBase::ENE_float32:
			pseri = new GraphSeries1Ch<Float32>(ValTypeId);
			break;
		case SeriesBase::ENE_float64:
			pseri = new GraphSeries1Ch<Float64>(ValTypeId);
			break;
		}
		return pseri;
		*/
	}
#endif


template<class T, class U> void myfor_each(T &it, T &end, U &data) {
	while (it != end) {
		data(*it);
		++it;
	}
}
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// 
// �{�N���X��delete()�����̃V���[�Y��delete()���܂��B
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
class LineDataSet{

public:
	LineDataSet();
	LineDataSet(const LineDataSet &Arg);
	~LineDataSet();

	void	clear();
	bool	empty() const				{ return m_Data.empty();	}
	size_t	size() const				{ return m_Data.size();		}

	const LineDataSet &operator = (const LineDataSet &Arg);

	// �ŏ��l�ƍő�l���擾���܂��B
	bool minAndMaxFloat32(Float32 &Min, Float32 &Max) const;

	// �������̃V���[�Y�̒��̃G���g���[�����ł��傫���l��Ԃ��B
	int32_t getSeriesLen() const;

	// �e�G���g���[�̌Â��f�[�^���폜���܂��B
	int32_t deleteOldEntry(size_t Len);

	SeriesBase::Seriesint32_t *getSeriesInt32(int32_t Ordinal) const{
		SeriesBase *elem = getElement(Ordinal);
		if (elem == NULL){
			return NULL;
		}
		return  elem->getSeriesInt32();
	}
	SeriesBase::SeriesFloat32 *getSeriesFloat32(int32_t Ordinal) const{
		SeriesBase *elem = getElement(Ordinal);
		if (elem == NULL){
			return NULL;
		}
		return  elem->getSeriesFloat32();
	}


#if 0
	// �V���[�Y
	// �{�N���X���ŃV���[�Y��delete()���Ȃ��̂ŁA�O��delete()���Ă��������B
	SeriesBase *popSeries(int32_t Ordinal){
#ifdef _DEBUG
		ASSERT(!m_Data.empty());
		ASSERT(m_Data.size() > Ordinal);
#endif
		SeriesBase *ret = m_Data[Ordinal];

		return ret;
	}
#endif

	SeriesBase & operator[] (int32_t Ordinal){
#if 1
		ASSERT(!m_Data.empty());
		ASSERT((int32_t)m_Data.size() > Ordinal);
#else
//--		if (m_Data.empty() || ((int32_t)m_Data.size() <= Ordinal)){
//--			return NULL;
//--		}
#endif

		return *m_Data[Ordinal];
	}
	const SeriesBase & operator[] (int32_t Ordinal) const{

		ASSERT(!m_Data.empty());
		ASSERT((int32_t)m_Data.size() > Ordinal);

		return *m_Data[Ordinal];
	}


	// getSeries() �֕ύX
	SeriesBase *getElement(int32_t Ordinal) const{
#ifdef _DEBUG
//--		ASSERT(!m_Data.empty());
//--		ASSERT((int32_t)m_Data.size() > Ordinal);
#endif
		if (m_Data.empty() || ((int32_t)m_Data.size() <= Ordinal)){
			return NULL;
		}

		return m_Data[Ordinal];
	}

	// �G���g���[���ǉ�
	bool isAppend(const LineDataSet &Arg) const;


	// �G�������g���m��RMS���v�Z���܂��B
	// �e�G�������g�̃T�C�Y�͓����ł���K�v������܂��B
	LineDataSet vector() const;


	// �V���[�Y��ǉ����܂��B
	SeriesBase::Seriesint32_t *addSeriesSint32();
	SeriesBase::SeriesFloat32 *addSeriesFloat32();
	void addSint32(size_t SeriesDataSize);
	void addFloat32(size_t SeriesDataSize);
	void add(SeriesBase *Series);			// �����Ń������m�ۍs���܂���B�B�O��clone()���ĉ������B
	SeriesBase *addSeries(int32_t ValTypeId ,int32_t Num = 1);


private:
	std::vector<SeriesBase*>	m_Data;	// Series<X>	m_Data��m_Type�̗v�f���͓���
};

